<?php
/**
* The template for displaying posts in the Quote post format.
*
* @package WordPress
* @subpackage nt_landium_
* @since nt_landium_ 1.0
*/


$nt_landium_quote_text = rwmb_meta( 'nt_landium_quote_text' );
$nt_landium_quote_author = rwmb_meta( 'nt_landium_quote_author' );
$nt_landium_image_id = get_post_thumbnail_id();
$nt_landium_image_url = wp_get_attachment_image_src($nt_landium_image_id, true);
$nt_landium_color = rwmb_meta( 'nt_landium_quote_bg' );
$nt_landium_opacity = rwmb_meta( 'nt_landium_quote_bg_opacity' );
$nt_landium_opacity = $nt_landium_opacity / 100;

?>

<!-- Start .hentry -->
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="hentry-box">

        <?php if ( $nt_landium_quote_text !='' ) : ?>
            <div class="post-thumb">
                <div class="content-quote-format-wrapper">
                    <?php if(has_post_thumbnail()) : ?>
                        <div class="entry-media" style="background-image: url(<?php echo esc_url( $nt_landium_image_url[0] ); ?>); ">
                        <?php else : ?>
                        <div class="entry-media">
                        <?php endif; ?>
                        <div class="content-quote-format-overlay" style="background-color: <?php echo esc_attr( $nt_landium_color ); ?>; opacity: <?php echo esc_attr( $nt_landium_opacity ); ?>;"></div>
                        <div class="content-quote-format-textwrap">
                            <h3><a href="<?php esc_url( the_permalink() ); ?>"><?php echo esc_attr( $nt_landium_quote_text ); ?></a></h3>
                            <p><a href="#0" target="_blank" style="color: #ffffff;"><?php echo esc_attr( $nt_landium_quote_author ); ?></a></p>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        <?php endif; ?>

        <?php nt_landium_all_post_content(); ?>

    </div>
</article>
