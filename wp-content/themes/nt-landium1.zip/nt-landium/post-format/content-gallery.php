<?php

wp_enqueue_style( 'nt-landium-custom-flexslider');
wp_enqueue_script( 'nt-landium-custom-flexslider');
wp_enqueue_script( 'fitvids');
wp_enqueue_script( 'nt-landium-blog-settings');
$nt_landium_images = rwmb_meta( 'nt_landium_gallery_image', 'type=image_advanced' );

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="blog-bg">
        <?php if( $nt_landium_images != '' ) : ?>
            <div class="flexslider">
                <ul class="slides">
                    <?php
                    foreach ( $nt_landium_images as $image ) {
                        echo "<li><img src='{$image['full_url']}' alt='{$image['alt']}' /></li>";
                    }
                    ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>

    <?php nt_landium_all_post_content(); ?>

</article>
