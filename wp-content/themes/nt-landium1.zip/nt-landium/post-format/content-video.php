<?php
/**
* The template for displaying posts in the Video post format.
*
* @package WordPress
* @subpackage nt_landium_
* @since nt_landium_ 1.0
*/

$nt_landium_embed = rwmb_meta( 'nt_landium_video_embed' );
$nt_landium_m4v = rwmb_meta( 'nt_landium_video_m4v' );
$nt_landium_ogv = rwmb_meta( 'nt_landium_video_ogv' );
$nt_landium_webm = rwmb_meta( 'nt_landium_video_webm' );
$nt_landium_image_id = get_post_thumbnail_id();
$nt_landium_image_url = wp_get_attachment_image_src($nt_landium_image_id, true);
$nt_landium_wp_video = '[video poster="'.$nt_landium_image_url[0].'" mp4="'.$nt_landium_m4v.'"  webm="'.$nt_landium_webm.'"]';

?>

<!-- Start .hentry -->
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="hentry-box">
        <?php if ( $nt_landium_embed !='' ) : ?>
            <div class="post-thumb blog-bg">
                <div class="media-element video-responsive"><?php echo wp_kses($nt_landium_embed,nt_landium_allowed_html()); ?></div>
            </div>
        <?php else : ?>
            <div class="post-thumb"><?php echo do_shortcode ($nt_landium_wp_video); ?></div>
        <?php endif; ?>

        <?php nt_landium_all_post_content(); ?>

    </div>
</article><!-- #post-## -->
