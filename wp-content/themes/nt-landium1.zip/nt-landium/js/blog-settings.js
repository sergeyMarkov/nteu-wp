jQuery(document).ready(function( $ ) {

	  "use strict";
	
	// blog list
	jQuery('.flexslider').flexslider({controlNav:true});
	jQuery(".video-responsive").fitVids();
	jQuery( ".entry-content table" ).addClass( "table table-striped" );
	
	
});