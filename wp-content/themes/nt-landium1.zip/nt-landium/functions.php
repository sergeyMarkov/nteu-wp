<?php

	// Theme functions
	require_once get_template_directory() . '/includes/theme-init.php';