<?php
add_action( 'init', 'nt_landium_custom_theme_options' );
function nt_landium_custom_theme_options() {

    if ( ! function_exists( 'ot_settings_id' ) || ! is_admin() )
    return false;

    $nt_landium_saved_settings = get_option( ot_settings_id(), array() );
    $nt_landium_custom_settings = array(
        'contextual_help' => array(
            'sidebar' => ''
        ),
        'sections' => array(

            array(
                'id' => 'general',
                'title' => esc_html__( 'General Settings', 'nt-landium' ),
            ),
            array(
                'id' => 'navigation',
                'title' => esc_html__( 'Navigation', 'nt-landium' ),
            ),
            array(
                'id' => 'sidebars',
                'title' => esc_html__( 'Sidebar Type', 'nt-landium' ),
            ),
            array(
                'id' => 'sidebars_settings',
                'title' => esc_html__( 'Sidebar Customize', 'nt-landium' ),
            ),
            array(
                'id' => 'header',
                'title' => esc_html__( 'Blog Page', 'nt-landium' ),
            ),
            array(
                'id' => 'post_color',
                'title' => esc_html__( 'Blog Post Color', 'nt-landium' ),
            ),
            array(
                'id' => 'single_header',
                'title' => esc_html__( 'Single Page', 'nt-landium' ),
            ),
            array(
                'id' => 'archive_page',
                'title' => esc_html__( 'Archive Page', 'nt-landium' ),
            ),
            array(
                'id' => 'error_page',
                'title' => esc_html__( '404 Page', 'nt-landium' ),
            ),
            array(
                'id' => 'search_page',
                'title' => esc_html__( 'Search Page', 'nt-landium' ),
            ),
            array(
                'id'=> 'breadcrubms',
                'title'=> esc_html__( 'Breadcrubms', 'nt-landium' ),
            ),
            array(
                'id' => 'footer',
                'title' => esc_html__( 'Footer General', 'nt-landium' ),
            ),
            array(
                'id' => 'google_fonts',
                'title' => esc_html__( 'Google Fonts', 'nt-landium' )
            ),
            array(
                'id' => 'typography',
                'title' => esc_html__( 'Typography', 'nt-landium' )
            ),
        ), // sidebar end

        // options start
        'settings' => array(

            //GOOGLE FONTS  SETTINGS.
            array(
                'id' => 'body_google_fonts',
                'label' => esc_html__( 'Google Fonts', 'nt-landium'  ),
                'desc' => esc_html__( 'Add Google Font and after the save settings follow these steps Dashbont-landium > Appearance > Theme Options > Typography', 'nt-landium' ),
                'type' => 'google-fonts',
                'section' => 'google_fonts',
                'operator' => 'and'
            ),
            array(
                'id' => 'ot_font_api',
                'label' => esc_html__( 'Google Webfonts API for Theme Options fonts', 'nt-landium' ),
                'desc' => esc_html__( 'Enter your API, more details here: https://www.youtube.com/watch?v=3OT9tH141mc ', 'nt-landium' ),
                'type' => 'text',
                'section' => 'google_fonts',
                'operator' => 'and'
            ),
            //TYPOGRAPHY  SETTINGS.
            array(
                'id' => 'nt_landium_typgrph',
                'label' => esc_html__( 'Typography', 'nt-landium' ),
                'desc' => esc_html__( 'The Typography option type is for adding typography styles to your site.', 'nt-landium' ),
                'type' => 'typography',
                'section' => 'typography',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_typgrph1',
                'label' => esc_html__( 'Typography h1', 'nt-landium' ),
                'desc' => esc_html__( 'The Typography option type is for adding typography styles to your site.', 'nt-landium' ),
                'type' => 'typography',
                'section' => 'typography',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_typgrph2',
                'label' => esc_html__( 'Typography h2', 'nt-landium' ),
                'desc' => esc_html__( 'The Typography option type is for adding typography styles to your site.', 'nt-landium' ),
                'type' => 'typography',
                'section' => 'typography',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_typgrph3',
                'label' => esc_html__( 'Typography h3', 'nt-landium' ),
                'desc' => esc_html__( 'The Typography option type is for adding typography styles to your site.', 'nt-landium' ),
                'type' => 'typography',
                'section' => 'typography',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_typgrph4',
                'label' => esc_html__( 'Typography h4', 'nt-landium' ),
                'desc' => esc_html__( 'The Typography option type is for adding typography styles to your site.', 'nt-landium' ),
                'type' => 'typography',
                'section' => 'typography',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_typgrph5',
                'label' => esc_html__( 'Typography h5', 'nt-landium' ),
                'desc' => esc_html__( 'The Typography option type is for adding typography styles to your site.', 'nt-landium' ),
                'type' => 'typography',
                'section' => 'typography',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_typgrph6',
                'label' => esc_html__( 'Typography h6', 'nt-landium' ),
                'desc' => esc_html__( 'The Typography option type is for adding typography styles to your site.', 'nt-landium' ),
                'type' => 'typography',
                'section' => 'typography',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_typgrph7',
                'label' => esc_html__( 'Typography p ( paragraph )', 'nt-landium' ),
                'desc' => esc_html__( 'The Typography option type is for adding typography styles to your site.', 'nt-landium' ),
                'type' => 'typography',
                'section' => 'typography',
                'operator' => 'and'
            ),
            //theme color
            array(
                'id' => 'nt_landium_theme_color_tab',
                'label' => esc_html__( 'Theme Color', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_theme_color',
                'label' => esc_html__('Theme Color', 'nt-landium' ),
                'desc' => esc_html__('Choose theme general color', 'nt-landium' ),
                'std' => '#3c83cb',
                'type' => 'select',
                'section' => 'general',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '#3c83cb',
                        'label' => esc_html__('Blue', 'nt-landium' ),
                        'src' => ''
                    ),
                    array(
                        'value' => '#44d86e',
                        'label' => esc_html__('Green', 'nt-landium' ),
                        'src' => ''
                    ),
                    array(
                        'value' => '#fb53c2',
                        'label' => esc_html__('Pink', 'nt-landium' ),
                        'src' => ''
                    ),
                    array(
                        'value' => '#c95ef5',
                        'label' => esc_html__('Purple', 'nt-landium' ),
                        'src' => ''
                    ),
                    array(
                        'value' => '#ff7469',
                        'label' => esc_html__('Red', 'nt-landium' ),
                        'src' => ''
                    ),
                    array(
                        'value' => '#f7b943',
                        'label' => esc_html__('Yellow', 'nt-landium' ),
                        'src' => ''
                    ),
                    array(
                        'value' => 'custom',
                        'label' => esc_html__('Custom Color', 'nt-landium' ),
                        'src' => ''
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_theme_color_one',
                'label' => esc_html__( 'Theme general color 1', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_theme_color:is(custom)',
                'section' => 'general'
            ),
            array(
                'id' => 'nt_landium_theme_color_two',
                'label' => esc_html__( 'Theme general link color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_theme_color:is(custom)',
                'section' => 'general'
            ),
            array(
                'id' => 'nt_landium_theme_color_three',
                'label' => esc_html__( 'Theme general link hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_theme_color:is(custom)',
                'section' => 'general'
            ),
            // theme logo
            array(
                'id' => 'nt_landium_logo_type_tab',
                'label' => esc_html__( 'Theme Logo', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_logo_display',
                'label' => esc_html__( 'Logo Display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Logo visibility %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_logo_type',
                'label' => esc_html__('Logo Type', 'nt-landium' ),
                'desc' => esc_html__('Choose logo type', 'nt-landium' ),
                'std' => 'text',
                'type' => 'select',
                'section' => 'general',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => 'img',
                        'label' => esc_html__('Image Logo', 'nt-landium' ),
                        'src' => ''
                    ),
                    array(
                        'value' => 'text',
                        'label' => esc_html__('Text Logo', 'nt-landium' ),
                        'src' => ''
                    )
                )
            ),
            //img logo
            array(
                'id' => 'nt_landium_logoimg',
                'label' => 'Upload logo image',
                'desc' => 'Upload logo image',
                'type' => 'upload',
                'condition' => 'nt_landium_logo_type:is(img)',
                'section' => 'general'
            ),
            array(
                'id' => 'nt_landium_stickylogoimg',
                'label' => 'Sticky Upload logo image',
                'desc' => 'Sticky Upload logo image',
                'type' => 'upload',
                'condition' => 'nt_landium_logo_type:is(img)',
                'section' => 'general'
            ),
            array(
                'id' => 'nt_landium_logo_dimension',
                'label' => esc_html__( 'Logo image width and height', 'nt-landium' ),
                'desc' => esc_html__( 'The Dimension option type is used to set width and height values.', 'nt-landium' ),
                'type' => 'dimension',
                'condition' => 'nt_landium_logo_type:is(img)',
                'section' => 'general',
                'operator' => 'and'
            ),
            //text logo
            array(
                'id' => 'nt_landium_textlogo',
                'label' => 'Text logo',
                'desc' => 'Text logo',
                'std' => 'Landium',
                'type' => 'text',
                'condition' => 'nt_landium_logo_type:is(text)',
                'section' => 'general'
            ),
            array(
                'id' => 'nt_landium_stickytextlogo',
                'label' => 'Sticky Text logo',
                'desc' => 'Sticky Text logo',
                'type' => 'text',
                'condition' => 'nt_landium_logo_type:is(text)',
                'section' => 'general'
            ),
            array(
                'id' => 'nt_landium_staticlogo_color',
                'label' => esc_html__( 'Static Text Logo color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color for static menu text logo', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_logo_type:is(text)',
                'section' => 'general'
            ),
            array(
                'id' => 'nt_landium_stickylogo_color',
                'label' => esc_html__( 'Sticky Text Logo color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color for sticky menu text logo', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_logo_type:is(text)',
                'section' => 'general'
            ),
            array(
                'id' => 'nt_landium_textlogo_hovercolor',
                'label' => esc_html__( 'Text Logo hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color for menu text logo hover color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_logo_type:is(text)',
                'section' => 'general'
            ),
            array(
                'id' => 'nt_landium_textlogo_fs',
                'label' => esc_html__('Font size', 'nt-landium' ),
                'desc' => esc_html__('Font size for text logo', 'nt-landium' ),
                'std' => '36',
                'type' => 'numeric-slider',
                'condition' => 'nt_landium_logo_type:is(text)',
                'min_max_step'=> '0,100',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_textlogo_fw',
                'label' => esc_html__('Font weight', 'nt-landium' ),
                'desc' => esc_html__('Font weight for text logo', 'nt-landium' ),
                'std' => '700',
                'type' => 'numeric-slider',
                'condition' => 'nt_landium_logo_type:is(text)',
                'min_max_step'=> '100,900,100',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_textlogo_lettersp',
                'label' => esc_html__('Letter spacing', 'nt-landium' ),
                'desc' => esc_html__('Letter spacing for text logo', 'nt-landium' ),
                'std' => '0',
                'type' => 'numeric-slider',
                'condition' => 'nt_landium_logo_type:is(text)',
                'min_max_step'=> '0,10',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_textlogo_fstyle',
                'label' => esc_html__('Font style', 'nt-landium' ),
                'desc' => esc_html__('Choose font style for text logo', 'nt-landium' ),
                'std' => 'normal',
                'type' => 'select',
                'section' => 'general',
                'condition' => 'nt_landium_logo_type:is(text)',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => 'normal',
                        'label' => esc_html__('Normal', 'nt-landium' ),
                        'src' => ''
                    ),
                    array(
                        'value' => 'italic',
                        'label' => esc_html__('Italic', 'nt-landium' ),
                        'src' => ''
                    )
                )
            ),
            array(
                'id' => 'nt_landium_margin_logo',
                'label' => esc_html__( 'Logo margin values', 'nt-landium' ),
                'desc' => esc_html__( 'Logo margin in the form of top, right, bottom, and left.', 'nt-landium' ),
                'type' => 'spacing',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_padding_logo',
                'label' => esc_html__( 'Logo padding values', 'nt-landium' ),
                'desc' => esc_html__( 'Logo padding in the form of top, right, bottom, and left.', 'nt-landium' ),
                'type' => 'spacing',
                'section' => 'general',
                'operator' => 'and'
            ),
            //preloader
            array(
                'id' => 'nt_landium_preloader_tab',
                'label' => esc_html__( 'Preloader', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_pre',
                'label' => esc_html__( 'Preloader', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Preloader visibility %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_type',
                'label' => esc_html__( 'Select preloader type', 'nt-landium' ),
                'desc' => esc_html__( 'Loader types', 'nt-landium' ),
                'type' => 'select',
                'section' => 'general',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '0',
                        'label' => esc_html__( 'Select preloader type', 'nt-landium' )
                    ),
                    array(
                        'value' => '1',
                        'label' => esc_html__( '1', 'nt-landium' )
                    ),
                    array(
                        'value' => '2',
                        'label' => esc_html__( '2', 'nt-landium' )
                    ),
                    array(
                        'value' => '3',
                        'label' => esc_html__( '3', 'nt-landium' )
                    ),
                    array(
                        'value' => '4',
                        'label' => esc_html__( '4', 'nt-landium' )
                    ),
                    array(
                        'value' => '5',
                        'label' => esc_html__( '5', 'nt-landium' )
                    ),
                    array(
                        'value' => '6',
                        'label' => esc_html__( '6', 'nt-landium' )
                    ),
                    array(
                        'value' => 'custom',
                        'label' => esc_html__( 'Custom Preloader', 'nt-landium' )
                    )
                )
            ),
            //CUSTOM PRELOADER
            array(
                'id' => 'nt_landium_custom_preloader',
                'label' => esc_html__( 'Custom preloader html area', 'nt-landium' ),
                'desc' => esc_html__('Add your custom preloader html', 'nt-landium' ),
                'type' => 'textarea',
                'rows' => '15',
                'condition' => 'nt_landium_pre:is(on),nt_landium_type:is(custom)',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_preloadercss',
                'label' => esc_html__( 'Custom preloader CSS', 'nt-landium' ),
                'desc' => esc_html__('You can add additional css for custom preloader', 'nt-landium' ),
                'type' => 'css',
                'condition' => 'nt_landium_pre:is(on),nt_landium_type:is(custom)',
                'section' => 'general',
                'rows' => '20',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_custom_preloader_js',
                'label' => esc_html__( 'Use custom javascript ?', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'You can use custom javascript for your custom preloader class or ID name. %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'off',
                'type' => 'on-off',
                'condition' => 'nt_landium_pre:is(on),nt_landium_type:is(custom)',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_preloaderjs',
                'label' => esc_html__( 'Custom preloader JS', 'nt-landium' ),
                'desc' => esc_html__('You can add additional javascript function for your custom preloader', 'nt-landium' ),
                'type' => 'javascript',
                'condition' => 'nt_landium_pre:is(on),nt_landium_type:is(custom),nt_landium_custom_preloader_js:is(on)',
                'section' => 'general',
                'rows' => '20',
                'operator' => 'and'
            ),
            // button scroll
            array(
                'id' => 'nt_landium_buttonscroll_tab',
                'label' => esc_html__( 'Button Scroll', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'general',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_btn_to_top',
                'label' => esc_html__( 'Button scroll to top', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Button scroll to top visibility %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'general',
                'operator' => 'and'
            ),
            /**  NAVIGATION SETTINGS.  **/
            //menu icon
            array(
                'id' => 'nt_landium_mobileicon_tab',
                'label' => esc_html__( 'Navigation Icon', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_menuicon',
                'label' => 'Menu item before icon',
                'desc' => 'Add icon for menu item',
                'type' => 'list-item',
                'section' => 'navigation',
                'settings' => array(
                    array(
                        'id' => 'nt_landium_mobileitemicon',
                        'label' => 'Icon unicode',
                        'desc' => 'Enter font awesome icon unicode.example : f121',
                        'type' => 'text',
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_menuicon_color',
                'label' => esc_html__( 'Icon color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_menuicon_desktop',
                'label' => esc_html__( 'Display menu icon on big device?', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'You can select show or hide menu icon on big device with %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'navigation',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_menuicon_mobile',
                'label' => esc_html__( 'Display menu icon on mobile device?', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'You can select show or hide menu icon on mobile device with %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'navigation',
                'operator' => 'and'
            ),
            //static nav
            array(
                'id' => 'nt_landium_staticnav_tab',
                'label' => esc_html__( 'Static Navigation', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_static_header_height',
                'label' => esc_html__('Header Height', 'nt-landium' ),
                'desc' => esc_html__('You can use this field for header min-height.Defult: empty', 'nt-landium' ),
                'type' => 'text',
                'std'=> '',
                'section' => 'navigation',
                'class' => 'text-field-mini',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_static_header_padding_top',
                'label' => esc_html__('Header padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this field for header height.Defult: 55', 'nt-landium' ),
                'type' => 'text',
                'std'=> '',
                'section' => 'navigation',
                'class' => 'text-field-mini',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_static_header_padding_bottom',
                'label' => esc_html__('Header padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this field for header height.Defult: 12', 'nt-landium' ),
                'type' => 'text',
                'std'=> '',
                'section' => 'navigation',
                'class' => 'text-field-mini',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_nav_bg',
                'label' => esc_html__( 'Theme menu background color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_navitem',
                'label' => esc_html__( 'Theme menu item color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_navitemhover',
                'label' => esc_html__( 'Theme menu item hover and active color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_nav_menu_ifs',
                'label' => esc_html__('Navigation menu item font size', 'nt-landium' ),
                'desc' => esc_html__('Navigation menu item font size', 'nt-landium' ),
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'navigation',
                'operator' => 'and'
            ),
            array(
                'id' => 'static_navitemhoverborderdisplay',
                'label' => esc_html__( 'Theme menu hover and active item vertical border on-off', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Theme menu hover and active item vertical border display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'navigation',
                'operator' => 'and'
            ),
            array(
                'id' => 'static_navitemhoverborder',
                'label' => esc_html__( 'Theme menu hover and active item vertical border color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'static_navitemhoverborderdisplay:is(on)',
                'section' => 'navigation'
            ),
            array(
                'id' => 'static_navitemhoverborderwidth',
                'label' => esc_html__( 'Theme menu hover and active item vertical border width.', 'nt-landium' ),
                'desc' => esc_html__( 'Use simple number in pixel or percentage.Example: 1px, 2px, 10px.. or 50%, 100%', 'nt-landium' ),
                'type' => 'text',
                'condition' => 'static_navitemhoverborderdisplay:is(on)',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_navpadding',
                'label' => esc_html__( 'Theme menu padding', 'nt-landium' ),
                'desc' => esc_html__( 'The Spacing option type is used to set spacing values such as padding or margin in the form of top, right, bottom, and left.', 'nt-landium' ),
                'std' => '',
                'type' => 'spacing',
                'section' => 'navigation',
            ),
            array(
                'id' => 'nt_landium_navmargin',
                'label' => esc_html__( 'Theme menu margin', 'nt-landium' ),
                'desc' => esc_html__( 'The Spacing option type is used to set spacing values such as padding or margin in the form of top, right, bottom, and left.', 'nt-landium' ),
                'std' => '',
                'type' => 'spacing',
                'section' => 'navigation',
            ),
            //sticky nav
            array(
                'id' => 'nt_landium_stickynav_tab',
                'label' => esc_html__( 'Sticky Navigation', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_nav_fixed_display',
                'label' => esc_html__( 'Sticky menu on-off', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Sticky menu display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'navigation',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sticky_header_height',
                'label' => esc_html__('Header Height', 'nt-landium' ),
                'desc' => esc_html__('You can use this field for header min-height.Defult: 80', 'nt-landium' ),
                'type' => 'text',
                'std'=> '',
                'section' => 'navigation',
                'class' => 'text-field-mini',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sticky_header_padding_top',
                'label' => esc_html__('Header padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this field for header height.Defult: 25', 'nt-landium' ),
                'type' => 'text',
                'std'=> '',
                'section' => 'navigation',
                'class' => 'text-field-mini',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sticky_header_padding_bottom',
                'label' => esc_html__('Header padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this field for header height.Defult: 25', 'nt-landium' ),
                'type' => 'text',
                'std'=> '',
                'section' => 'navigation',
                'class' => 'text-field-mini',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_showmenu',
                'label' => esc_html__('Sticky menu display range', 'nt-landium' ),
                'desc' => esc_html__('You can control with this option navigation display range.Min:0 and Max:600', 'nt-landium' ),
                'type' => 'numeric-slider',
                'std' => '80',
                'min_max_step'=> '0,600',
                'section' => 'navigation',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_nav_fixed_bg',
                'label' => esc_html__( 'Theme sticky menu background color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_navitem_after_s',
                'label' => esc_html__( 'Theme sticky menu item color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_fixed_navitemhover',
                'label' => esc_html__( 'Theme sticky menu item hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_stick_navitemhoverborderdisplay',
                'label' => esc_html__( 'Theme sticky menu hover and active item vertical border on-off', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Theme menu hover and active item vertical border display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'navigation',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_stick_navitemhoverborder',
                'label' => esc_html__( 'Theme menu hover and active item vertical border color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_nav_fixed_display:is(on),nt_landium_stick_navitemhoverborderdisplay:is(on)',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_stick_navitemhoverborderwidth',
                'label' => esc_html__( 'Theme menu hover and active item vertical border width.', 'nt-landium' ),
                'desc' => esc_html__( 'Use simple number in pixel or percentage.Example: 1px, 2px, 10px.. or 50%, 100%', 'nt-landium' ),
                'type' => 'text',
                'condition' => 'nt_landium_nav_fixed_display:is(on),nt_landium_stick_navitemhoverborderdisplay:is(on)',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_stickynavpadding',
                'label' => esc_html__( 'Theme sticky menu padding', 'nt-landium' ),
                'desc' => esc_html__( 'The padding option type is used to set spacing values in the form of top, right, bottom, and left.', 'nt-landium' ),
                'std' => '',
                'type' => 'spacing',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'section' => 'navigation',
            ),
            array(
                'id' => 'nt_landium_stickynavmargin',
                'label' => esc_html__( 'Theme sticky menu margin', 'nt-landium' ),
                'desc' => esc_html__( 'The margin option type is used to set spacing values in the form of top, right, bottom, and left.', 'nt-landium' ),
                'std' => '',
                'type' => 'spacing',
                'condition' => 'nt_landium_nav_fixed_display:is(on)',
                'section' => 'navigation',
            ),
            //dropdown sub menu
            array(
                'id' => 'nt_landium_dropdownnav_tab',
                'label' => esc_html__( 'Dropdown Submenu', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_dropdown_bg',
                'label' => esc_html__( 'Dropdown menu background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_dropdown_item',
                'label' => esc_html__( 'Dropdown menu item color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_dropdown_itemhover',
                'label' => esc_html__( 'Dropdown menu item hover and active color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_dropdown_itemhoverbg',
                'label' => esc_html__( 'Dropdown menu hover and active item background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            //mobile sub menu
            array(
                'id' => 'nt_landium_mobilenav_tab',
                'label' => esc_html__( 'Mobile Navigation', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_mobile_header_height',
                'label' => esc_html__('Header Height', 'nt-landium' ),
                'desc' => esc_html__('You can use this field for mobile header height.Defult: 80', 'nt-landium' ),
                'type' => 'text',
                'std'=> '',
                'section' => 'navigation',
                'class' => 'text-field-mini',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_mobile_header_padding_top',
                'label' => esc_html__('Header padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this field for header height.Defult: 25', 'nt-landium' ),
                'type' => 'text',
                'std'=> '',
                'section' => 'navigation',
                'class' => 'text-field-mini',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_mobile_header_padding_bottom',
                'label' => esc_html__('Header padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this field for header height.Defult: 25', 'nt-landium' ),
                'type' => 'text',
                'std'=> '',
                'section' => 'navigation',
                'class' => 'text-field-mini',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_mobile_menubtn',
                'label' => esc_html__( 'Mobile menu open and close button iconbar color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_mobile_bg',
                'label' => esc_html__( 'Mobile menu background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_menuicon',
                'label' => esc_html__( 'Menu item icon', 'nt-landium' ),
                'desc' => esc_html__( 'Add icon before menu item', 'nt-landium' ),
                'type' => 'list-item',
                'section' => 'navigation',
                'settings' => array(
                    array(
                        'id' => 'nt_landium_mobileitemicon',
                        'label' => 'Icon unicode',
                        'label' => esc_html__( 'Fontawesome icon unicode', 'nt-landium' ),
                        'desc' => esc_html__( 'Enter fontawesome icon unicode.example : f015', 'nt-landium' ),
                        'type' => 'text',
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_mobile_item',
                'label' => esc_html__( 'Mobile menu item color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_mobile_itemhover',
                'label' => esc_html__( 'Mobile menu item hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_mobile_itemhoverbg',
                'label' => esc_html__( 'Mobile menu hover and active item background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_mobile_itempadding',
                'label' => esc_html__( 'Mobile menu item padding', 'nt-landium' ),
                'desc' => esc_html__( 'The padding option type is used to set spacing values in the form of top, right, bottom, and left.', 'nt-landium' ),
                'std' => '',
                'type' => 'spacing',
                'section' => 'navigation',
            ),
            array(
                'id' => 'nt_landium_mobile_itemmargin',
                'label' => esc_html__( 'Mobile menu item margin', 'nt-landium' ),
                'desc' => esc_html__( 'The margin option type is used to set spacing values in the form of top, right, bottom, and left.', 'nt-landium' ),
                'std' => '',
                'type' => 'spacing',
                'section' => 'navigation',
            ),
            array(
                'id' => 'nt_landium_mobile_itemborder',
                'label' => esc_html__( 'Mobile menu item border', 'nt-landium' ),
                'desc' => esc_html__( 'The Border option type is used to set width, unit, style, and color values.', 'nt-landium' ),
                'type' => 'border',
                'section' => 'navigation',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_mobile_itemfontsize',
                'label' => esc_html__( 'Mobile menu item font-size', 'nt-landium' ),
                'desc' => esc_html__( 'Change mobile menu item font size.Use number in (px or unit).example:30px or 4rem', 'nt-landium' ),
                'type' => 'text',
                'section' => 'navigation'
            ),
            array(
                'id' => 'nt_landium_mobile_itemtextalign',
                'label' => esc_html__( 'Mobile menu item text align', 'nt-landium' ),
                'desc' => esc_html__( 'Change mobile menu item text align', 'nt-landium' ),
                'type' => 'select',
                'section' => 'navigation',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_mobile_itemfontweight',
                'label' => esc_html__( 'Mobile menu item font weight', 'nt-landium' ),
                'desc' => esc_html__( 'Change mobile menu item font weight', 'nt-landium' ),
                'type' => 'select',
                'section' => 'navigation',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select font weight', 'nt-landium' )
                    ),
                    array(
                        'value' => '100',
                        'label' => esc_html__( '100', 'nt-landium' )
                    ),
                    array(
                        'value' => '200',
                        'label' => esc_html__( '200', 'nt-landium' )
                    ),
                    array(
                        'value' => '300',
                        'label' => esc_html__( '300', 'nt-landium' )
                    ),
                    array(
                        'value' => '400',
                        'label' => esc_html__( '400', 'nt-landium' )
                    ),
                    array(
                        'value' => '500',
                        'label' => esc_html__( '500', 'nt-landium' )
                    ),
                    array(
                        'value' => '600',
                        'label' => esc_html__( '600', 'nt-landium' )
                    ),
                    array(
                        'value' => '700',
                        'label' => esc_html__( '700', 'nt-landium' )
                    ),
                    array(
                        'value' => '800',
                        'label' => esc_html__( '800', 'nt-landium' )
                    ),
                    array(
                        'value' => '900',
                        'label' => esc_html__( '900', 'nt-landium' )
                    ),

                )
            ),
            array(
                'id' => 'nt_landium_mobile_dropitemfontsize',
                'label' => esc_html__( 'Mobile dropdown menu item font-size', 'nt-landium' ),
                'desc' => esc_html__( 'Change mobile dropdown menu item font size.Use number in (px or unit).example:24px or 2rem', 'nt-landium' ),
                'type' => 'text',
                'section' => 'navigation'
            ),
            /**  NAVIGATION SETTINGS.  **/

            /**  SIDEBAR TYPE SETTINGS.  **/
            array(
                'id' => 'nt_landium_bloglayout',
                'label' => esc_html__( 'Blog Layout', 'nt-landium' ),
                'desc' => esc_html__( 'Choose blog page layout type', 'nt-landium' ),
                'std' => 'right-sidebar',
                'type' => 'radio-image',
                'section' => 'sidebars',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_pagelayout',
                'label' => esc_html__( 'Default Page Layout', 'nt-landium' ),
                'desc' => esc_html__( 'Choose default page layout type', 'nt-landium' ),
                'std' => 'right-sidebar',
                'type' => 'radio-image',
                'section' => 'sidebars',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_searchlayout',
                'label' => esc_html__( 'Search page Layout', 'nt-landium' ),
                'desc' => esc_html__( 'Choose search page layout type', 'nt-landium' ),
                'std' => 'right-sidebar',
                'type' => 'radio-image',
                'section' => 'sidebars',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_postlayout',
                'label' => esc_html__( 'Blog single page layout', 'nt-landium' ),
                'desc' => esc_html__( 'Choose post page layout type', 'nt-landium' ),
                'std' => 'right-sidebar',
                'type' => 'radio-image',
                'section' => 'sidebars',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archivelayout',
                'label' => esc_html__( 'Archive page layout', 'nt-landium' ),
                'desc' => esc_html__( 'Choose archive page layout type', 'nt-landium' ),
                'std' => 'right-sidebar',
                'type' => 'radio-image',
                'section' => 'sidebars',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_404layout',
                'label' => esc_html__( '404 page layout', 'nt-landium' ),
                'desc' => esc_html__( 'Choose 404 page layout type', 'nt-landium' ),
                'std' => 'right-sidebar',
                'type' => 'radio-image',
                'section' => 'sidebars',
                'operator' => 'and'
            ),
            array(
                'id' => 'woosingle',
                'label' => esc_html__( 'Woocommerce single page layout', 'nt-landium' ),
                'desc' => esc_html__( 'Choose Woocommerce single page layout type', 'nt-landium' ),
                'std' => 'right-sidebar',
                'type' => 'radio-image',
                'section' => 'sidebars',
                'operator' => 'and'
            ),
            array(
                'id' => 'woopage',
                'label' => esc_html__( 'Woocommerce  page layout', 'nt-landium' ),
                'desc' => esc_html__( 'Choose 404 page layout type', 'nt-landium' ),
                'std' => 'right-sidebar',
                'type' => 'radio-image',
                'section' => 'sidebars',
                'operator' => 'and'
            ),

            /**  SIDEBAR SETTINGS.  **/
            array(
                'id' => 'nt_landium_sb_general_tab',
                'label' => esc_html__( 'Sidebar General', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_bg',
                'label' => esc_html__('Sidebar background color', 'nt-landium' ),
                'desc' => esc_html__('Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_border',
                'label' => esc_html__( 'Sidebar border', 'nt-landium' ),
                'desc' => esc_html__( 'The Border option type is used to set width, unit, style, and color values.', 'nt-landium' ),
                'type' => 'border',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_borderradius',
                'label' => esc_html__('Sidebar border radius', 'nt-landium' ),
                'desc' => esc_html__('Add sidebar border radius', 'nt-landium' ),
                'std' => '0',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_c',
                'label' => esc_html__( 'Sidebar general text color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'sidebars_settings'
            ),
            array(
                'id' => 'nt_landium_sidebar_animation',
                'label' => esc_html__( 'Sidebar animation', 'nt-landium' ),
                'desc' => esc_html__( 'Select sidebar animation', 'nt-landium' ),
                'type' => 'select',
                'section' => 'sidebars_settings',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'None', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounce',
                        'label' => esc_html__( 'bounce', 'nt-landium' )
                    ),
                    array(
                        'value' => 'flash',
                        'label' => esc_html__( 'flash', 'nt-landium' )
                    ),
                    array(
                        'value' => 'pulse',
                        'label' => esc_html__( 'pulse', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceIn',
                        'label' => esc_html__( 'bounceIn', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceInDown',
                        'label' => esc_html__( 'bounceInDown', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceInLeft',
                        'label' => esc_html__( 'bounceInLeft', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceInRight',
                        'label' => esc_html__( 'bounceInRight', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceInUp',
                        'label' => esc_html__( 'bounceInUp', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeIn',
                        'label' => esc_html__( 'fadeIn', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeInDown',
                        'label' => esc_html__( 'fadeInDown', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeInLeft',
                        'label' => esc_html__( 'fadeInLeft', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeInRight',
                        'label' => esc_html__( 'fadeInRight', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeInUp',
                        'label' => esc_html__( 'fadeInUp', 'nt-landium' )
                    ),
                    array(
                        'value' => 'slideInUp',
                        'label' => esc_html__( 'slideInUp', 'nt-landium' )
                    ),
                    array(
                        'value' => 'slideInLeft',
                        'label' => esc_html__( 'slideInLeft', 'nt-landium' )
                    ),
                    array(
                        'value' => 'slideInRight',
                        'label' => esc_html__( 'slideInRight', 'nt-landium' )
                    ),
                    array(
                        'value' => 'slideInDown',
                        'label' => esc_html__( 'slideInDown', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomIn',
                        'label' => esc_html__( 'zoomIn', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomInDown',
                        'label' => esc_html__( 'zoomInDown', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomInLeft',
                        'label' => esc_html__( 'zoomInLeft', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomInRight',
                        'label' => esc_html__( 'zoomInRight', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomInUp',
                        'label' => esc_html__( 'zoomInUp', 'nt-landium' )
                    )
                )
            ),
            // widget color
            array(
                'id' => 'nt_landium_sb_widget_tab',
                'label' => esc_html__( 'Sidebar Widget', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_w_bg',
                'label' => 'Widget background',
                'desc' => 'Upload background',
                'type' => 'background',
                'section' => 'sidebars_settings'
            ),
            array(
                'id' => 'nt_landium_sb_w_overlay',
                'label' => esc_html__( 'Widget background image overlay color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color and use opacity', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'sidebars_settings'
            ),
            array(
                'id' => 'nt_landium_sb_w_border',
                'label' => esc_html__( 'Sidebar widget border', 'nt-landium' ),
                'desc' => esc_html__( 'The Border option type is used to set width, unit, style, and color values.', 'nt-landium' ),
                'type' => 'border',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_w_borderradius',
                'label' => esc_html__('Sidebar widget border radius', 'nt-landium' ),
                'desc' => esc_html__('Add sidebar widget border radius', 'nt-landium' ),
                'std' => '0',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_w_margin',
                'label' => esc_html__( 'Sidebar widget margin', 'nt-landium' ),
                'desc' => esc_html__( 'The margin option type is used to set spacing values in the form of top, right, bottom, and left.', 'nt-landium' ),
                'type' => 'spacing',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_w_padding',
                'label' => esc_html__( 'Sidebar widget padding', 'nt-landium' ),
                'desc' => esc_html__( 'The padding option type is used to set spacing values in the form of top, right, bottom, and left.', 'nt-landium' ),
                'type' => 'spacing',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_t_c',
                'label' => esc_html__( 'Widget title color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'sidebars_settings'
            ),
            array(
                'id' => 'nt_landium_wt_before',
                'label' => 'Widget title before icon',
                'desc' => 'Add icon before widget title',
                'type' => 'list-item',
                'section' => 'sidebars_settings',
                'settings' => array(
                    array(
                        'id' => 'nt_landium_sb_wt_icon',
                        'label' => 'Icon unicode',
                        'desc' => 'Enter font awesome icon unicode.example : f121',
                        'type' => 'text',
                    )
                )
            ),
            // widget Link color
            array(
                'id' => 'nt_landium_sb_widgetlink_tab',
                'label' => esc_html__( 'Sidebar Link', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_l_c',
                'label' => esc_html__( 'Link color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'sidebars_settings'
            ),
            array(
                'id' => 'nt_landium_sb_l_c_h',
                'label' => esc_html__( 'Link hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'sidebars_settings'
            ),
            // widget Search color
            array(
                'id' => 'nt_landium_sb_widgetsearch_tab',
                'label' => esc_html__( 'Sidebar Search', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'sidebars_settings',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_sb_s_t',
                'label' => esc_html__( 'Sidebar search submit text color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'sidebars_settings'
            ),
            array(
                'id' => 'nt_landium_sb_s_bg',
                'label' => esc_html__( 'Sidebar search submit background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'sidebars_settings'
            ),
            /**  POST SETTINGS.  **/
            array(
                'id' => 'nt_landium_blogposttitle_tab',
                'label' => esc_html__( 'Post Title', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'post_color',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blogposttitlecolor',
                'label' => esc_html__( 'Blog post title color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogposttitlhoverecolor',
                'label' => esc_html__( 'Blog post title hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            //post meta
            array(
                'id' => 'nt_landium_blogmeta_tab',
                'label' => esc_html__( 'Post Meta', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'post_color',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blogmetacolor',
                'label' => esc_html__( 'Blog post meta title color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogmetalinktextcolor',
                'label' => esc_html__( 'Blog post meta link color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogmetalinkhovercolor',
                'label' => esc_html__( 'Blog post meta link hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogmetalinktextbgcolor',
                'label' => esc_html__( 'Blog post meta link background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogmetalinktextbghovercolor',
                'label' => esc_html__( 'Blog post meta link background hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            // content
            array(
                'id' => 'nt_landium_blogpostcontent_tab',
                'label' => esc_html__( 'Post Content', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'post_color',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blogpostparagraphcolor',
                'label' => esc_html__( 'Blog post content text color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogpostbuttonbgcolor',
                'label' => esc_html__( 'Blog post button background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogpostbuttonbghovercolor',
                'label' => esc_html__( 'Blog post button background hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogpostbuttontitlecolor',
                'label' => esc_html__( 'Blog post button title color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogpostbuttontitlehovercolor',
                'label' => esc_html__( 'Blog post button title hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            // single post share
            array(
                'id' => 'nt_landium_blogshare_tab',
                'label' => esc_html__( 'Post Share', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'post_color',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blogsharebgcolor',
                'label' => esc_html__( 'Blog post share icon background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogsharebghovercolor',
                'label' => esc_html__( 'Blog post share icon background hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogsharecolor',
                'label' => esc_html__( 'Blog post share icon color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogsharehovercolor',
                'label' => esc_html__( 'Blog post share icon hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            // single comment
            array(
                'id' => 'nt_landium_blogcomment_tab',
                'label' => esc_html__( 'Comment Form', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'post_color',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blogcommentformsubmitcolor',
                'label' => esc_html__( 'Single post comment button title color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogcommentformsubmithovercolor',
                'label' => esc_html__( 'Single post comment button title hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogcommentformsubmitbgcolor',
                'label' => esc_html__( 'Single post comment button background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_blogcommentformsubmitbghovercolor',
                'label' => esc_html__( 'Single post comment button background hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            // single comment
            array(
                'id' => 'nt_landium_blogpager_tab',
                'label' => esc_html__( 'Pager Button', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'post_color',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_pagertitlecolor',
                'label' => esc_html__( 'Pager button title color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_pagertitlehovercolor',
                'label' => esc_html__( 'Pager button title hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_pagerbgcolor',
                'label' => esc_html__( 'Pager button background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),
            array(
                'id' => 'nt_landium_pagerbghovercolor',
                'label' => esc_html__( 'Pager button background hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'post_color'
            ),

            /**  BLOG/PAGE HEADER SETTINGS.  **/
            // blog hero
            array(
                'id' => 'nt_landium_blog_hero',
                'label' => esc_html__( 'Blog Hero', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'header',
            ),
            array(
                'id' => 'nt_landium_blog_h_bg',
                'label' =>  esc_html__( 'Blog page hero section background image', 'nt-landium' ),
                'desc' =>  esc_html__( 'You can upload your image for parallax hero', 'nt-landium' ),
                'type' => 'upload',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_mask_v',
                'label' => esc_html__( 'Blog page hero section overlay color display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select blog page hero section overlay color display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_mask_c',
                'label' => esc_html__( 'Blog page hero section overlay color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_blog_mask_v:is(on)',
                'section' => 'header'
            ),
            array(
                'id' => 'nt_landium_blogheaderbgcolor',
                'label' => esc_html__( 'Blog page hero section background color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'header'
            ),
            array(
                'id' => 'nt_landium_blog_h_h',
                'label' => esc_html__('Blog page hero section height', 'nt-landium' ),
                'desc' => esc_html__('Blog page hero section height', 'nt-landium' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_h_p',
                'label' => esc_html__('Blog page hero section padding', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'type' => 'spacing',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_textalign',
                'label' => esc_html__( 'Blog page hero section text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select blog page text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            // blog heading
            array(
                'id' => 'nt_landium_blog_heading_tab',
                'label' => esc_html__( 'Blog Heading', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'header',
            ),
            array(
                'id' => 'nt_landium_blog_heading_display',
                'label' => esc_html__( 'Blog page heading display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select blog page heading display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_heading',
                'label' => esc_html__( 'Blog page heading', 'nt-landium' ),
                'desc' => esc_html__( 'Enter blog page heading', 'nt-landium' ),
                'std' => 'Blog',
                'type' => 'text',
                'condition' => 'nt_landium_blog_heading_display:is(on)',
                'section' => 'header'
            ),
            array(
                'id' => 'nt_landium_blog_h_c',
                'label' => esc_html__( 'Blog page heading color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_blog_heading_display:is(on)',
                'section' => 'header'
            ),
            array(
                'id' => 'nt_landium_blog_heading_fontsize',
                'label' => esc_html__('Blog page heading font size', 'nt-landium' ),
                'desc' => esc_html__('Blog page heading font size', 'nt-landium' ),
                'type' => 'numeric-slider',
                'std' => '65',
                'min_max_step'=> '0,100',
                'section' => 'header',
                'condition' => 'nt_landium_blog_heading_display:is(on)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_heading_margin',
                'label' => esc_html__( 'Blog page heading margin', 'nt-landium' ),
                'desc' => esc_html__( 'Blog page heading margin', 'nt-landium' ),
                'type' => 'spacing',
                'condition' => 'nt_landium_blog_heading_display:is(on)',
                'section' => 'header',
            ),
            // blog slogan
            array(
                'id' => 'nt_landium_blog_slogan_tab',
                'label' => esc_html__( 'Blog Slogan', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'header',
            ),
            array(
                'id' => 'nt_landium_blog_slogan_display',
                'label' => esc_html__( 'Blog page slogan display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select blog page slogan display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_slogan',
                'label' => esc_html__( 'Blog page slogan', 'nt-landium' ),
                'desc' => esc_html__( 'Enter blog page slogan', 'nt-landium' ),
                'std' => '',
                'type' => 'text',
                'condition' => 'nt_landium_blog_slogan_display:is(on)',
                'section' => 'header'
            ),
            array(
                'id' => 'nt_landium_blog_sub_h_c',
                'label' => esc_html__( 'Blog page slogan color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_blog_slogan_display:is(on)',
                'section' => 'header'
            ),
            array(
                'id' => 'nt_landium_blog_slogan_fontsize',
                'label' => esc_html__('Blog page slogan font size', 'nt-landium' ),
                'desc' => esc_html__('Blog page slogan font size', 'nt-landium' ),
                'type' => 'numeric-slider',
                'std' => '18',
                'min_max_step'=> '0,100',
                'section' => 'header',
                'condition' => 'nt_landium_blog_slogan_display:is(on)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_slogan_margin',
                'label' => esc_html__( 'Blog page slogan margin', 'nt-landium' ),
                'desc' => esc_html__( 'Blog page slogan margin', 'nt-landium' ),
                'type' => 'spacing',
                'condition' => 'nt_landium_blog_slogan_display:is(on)',
                'section' => 'header',
            ),
            //Blog Content
            array(
                'id' => 'nt_landium_blog_content_tab',
                'label' =>  esc_html__( 'Blog Content', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'header',
            ),
            array(
                'id' => 'nt_landium_blog_content_textalign',
                'label' => esc_html__( 'Blog content post text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select blog page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_post_animation',
                'label' => esc_html__( 'Blog content post animation', 'nt-landium' ),
                'desc' => esc_html__( 'Select blog page content post animation', 'nt-landium' ),
                'type' => 'select',
                'section' => 'header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'None', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounce',
                        'label' => esc_html__( 'bounce', 'nt-landium' )
                    ),
                    array(
                        'value' => 'flash',
                        'label' => esc_html__( 'flash', 'nt-landium' )
                    ),
                    array(
                        'value' => 'pulse',
                        'label' => esc_html__( 'pulse', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceIn',
                        'label' => esc_html__( 'bounceIn', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceInDown',
                        'label' => esc_html__( 'bounceInDown', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceInLeft',
                        'label' => esc_html__( 'bounceInLeft', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceInRight',
                        'label' => esc_html__( 'bounceInRight', 'nt-landium' )
                    ),
                    array(
                        'value' => 'bounceInUp',
                        'label' => esc_html__( 'bounceInUp', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeIn',
                        'label' => esc_html__( 'fadeIn', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeInDown',
                        'label' => esc_html__( 'fadeInDown', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeInLeft',
                        'label' => esc_html__( 'fadeInLeft', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeInRight',
                        'label' => esc_html__( 'fadeInRight', 'nt-landium' )
                    ),
                    array(
                        'value' => 'fadeInUp',
                        'label' => esc_html__( 'fadeInUp', 'nt-landium' )
                    ),
                    array(
                        'value' => 'slideInUp',
                        'label' => esc_html__( 'slideInUp', 'nt-landium' )
                    ),
                    array(
                        'value' => 'slideInLeft',
                        'label' => esc_html__( 'slideInLeft', 'nt-landium' )
                    ),
                    array(
                        'value' => 'slideInRight',
                        'label' => esc_html__( 'slideInRight', 'nt-landium' )
                    ),
                    array(
                        'value' => 'slideInDown',
                        'label' => esc_html__( 'slideInDown', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomIn',
                        'label' => esc_html__( 'zoomIn', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomInDown',
                        'label' => esc_html__( 'zoomInDown', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomInLeft',
                        'label' => esc_html__( 'zoomInLeft', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomInRight',
                        'label' => esc_html__( 'zoomInRight', 'nt-landium' )
                    ),
                    array(
                        'value' => 'zoomInUp',
                        'label' => esc_html__( 'zoomInUp', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_post_readmore',
                'label' => esc_html__( 'Blog post box read more button text', 'nt-landium' ),
                'desc' => esc_html__( 'Blog post box read more button text', 'nt-landium' ),
                'std' => 'Read More',
                'type' => 'text',
                'section' => 'header'
            ),
            //blog responsive 992px
            array(
                'id' => 'nt_landium_blog_992responsive_tab',
                'label' =>  esc_html__( 'Responsive( 992px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'header',
            ),
            array(
                'id' => 'nt_landium_blog_992_headbg',
                'label' =>  esc_html__( 'Blog hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>992px</strong>' ),
                'type' => 'upload',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_992_bgheight',
                'label' => esc_html__('Blog page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_992_heading_textalign',
                'label' => esc_html__( 'Blog hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_blog_992_heading_fontsize',
                'label' => esc_html__('Blog heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_992_heading_padtop',
                'label' => esc_html__('Blog hero section padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_992_heading_padbot',
                'label' => esc_html__('Blog hero section padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_992_content_textalign',
                'label' => esc_html__( 'Blog content post text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select blog page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            //blog responsive 768px
            array(
                'id' => 'nt_landium_blog_768responsive_tab',
                'label' =>  esc_html__( 'Responsive( 768px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'header',
            ),
            array(
                'id' => 'nt_landium_blog_768_headbg',
                'label' =>  esc_html__( 'Blog hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>768px</strong>' ),
                'type' => 'upload',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_768_bgheight',
                'label' => esc_html__('Blog page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>768px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_768_heading_textalign',
                'label' => esc_html__( 'Blog hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_blog_768_heading_fontsize',
                'label' => esc_html__('Blog heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>768px</strong>' ),
                'std' => '40',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_768_heading_padtop',
                'label' => esc_html__('Blog hero section padding top', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_768_heading_padbot',
                'label' => esc_html__('Blog hero section padding bottom', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blog_768_content_textalign',
                'label' => esc_html__( 'Blog content post text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select blog page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            /**  SINGLE HEADER SETTINGS.  **/
            // Single hero
            array(
                'id' => 'nt_landium_single_hero_tab',
                'label' => esc_html__( 'Single Hero', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'single_header',
            ),
            array(
                'id' => 'nt_landium_single_mask_v',
                'label' => esc_html__( 'Single hero section background overlay color display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select single hero section background overlay color %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_mask_c',
                'label' => esc_html__( 'Single hero section background overlay color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_single_mask_v:is(on)',
                'section' => 'single_header'
            ),
            array(
                'id' => 'nt_landium_singlepageheadbg',
                'label' =>  esc_html__( 'Single hero section background image', 'nt-landium' ),
                'desc' =>  esc_html__( 'You can upload your image for parallax header', 'nt-landium' ),
                'type' => 'upload',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_singleheaderbgcolor',
                'label' => esc_html__( 'Single hero section background color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker',
                'section' => 'single_header'
            ),
            array(
                'id' => 'nt_landium_singleheaderbgheight',
                'label' => esc_html__('Single hero section height', 'nt-landium' ),
                'desc' => esc_html__('Single hero section height', 'nt-landium' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_singleheaderpaddingtop',
                'label' => esc_html__('Single hero section padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_singleheaderpaddingbottom',
                'label' => esc_html__('Single hero section padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_textalign',
                'label' => esc_html__( 'Single hero section text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select single page hero section text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'single_header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            // Single heading
            array(
                'id' => 'nt_landium_single_heading_tab',
                'label' => esc_html__( 'Single Heading', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'single_header',
            ),
            array(
                'id' => 'nt_landium_single_disable_heading',
                'label' => esc_html__( 'Single pages heading post title visibility', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select single pages heading post title  visibility %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_singleheadingcolor',
                'label' => esc_html__( 'Single page heading color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker',
                'condition' => 'nt_landium_single_disable_heading:is(on)',
                'section' => 'single_header'
            ),
            array(
                'id' => 'nt_landium_single_heading_fontsize',
                'label' => esc_html__('Single page heading font size', 'nt-landium' ),
                'desc' => esc_html__('Enter single page heading font size', 'nt-landium' ),
                'std' => '65',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'condition' => 'nt_landium_single_disable_heading:is(on)',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            // single content
            array(
                'id' => 'nt_landium_single_content_tab',
                'label' =>  esc_html__( 'Single Content', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'single_header',
            ),
            array(
                'id' => 'nt_landium_single_content_textalign',
                'label' => esc_html__( 'Single content post text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select single page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'single_header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            //single responsive 992px
            array(
                'id' => 'nt_landium_single_992responsive_tab',
                'label' =>  esc_html__( 'Responsive( 992px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'single_header',
            ),
            array(
                'id' => 'nt_landium_single_992_headbg',
                'label' =>  esc_html__( 'Single hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>992px</strong>' ),
                'type' => 'upload',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_992_bgheight',
                'label' => esc_html__('Single page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_992_heading_textalign',
                'label' => esc_html__( 'Single hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'single_header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_single_992_heading_fontsize',
                'label' => esc_html__('Single heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_992_heading_padtop',
                'label' => esc_html__('Single hero section padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_992_heading_padbot',
                'label' => esc_html__('Single hero section padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_992_content_textalign',
                'label' => esc_html__( 'Single page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select single page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'single_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            //single responsive 768px
            array(
                'id' => 'nt_landium_single_768responsive_tab',
                'label' =>  esc_html__( 'Responsive( 768px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'single_header',
            ),
            array(
                'id' => 'nt_landium_single_768_headbg',
                'label' =>  esc_html__( 'Single hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>768px</strong>' ),
                'type' => 'upload',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_768_bgheight',
                'label' => esc_html__('Single page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>768px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_768_heading_textalign',
                'label' => esc_html__( 'Single hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'single_header',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_single_768_heading_fontsize',
                'label' => esc_html__('Single heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>768px</strong>' ),
                'std' => '40',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_768_heading_padtop',
                'label' => esc_html__('Single hero section padding top', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_768_heading_padbot',
                'label' => esc_html__('Single hero section padding bottom', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'single_header',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_single_768_content_textalign',
                'label' => esc_html__( 'Single page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select single page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'single_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            /**  ARCHIVE HEADER SETTINGS.  **/
            // Archive hero
            array(
                'id' => 'nt_landium_archive_hero_tab',
                'label' => esc_html__( 'Archive Hero', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'archive_page',
            ),
            array(
                'id' => 'nt_landium_archive_mask_v',
                'label' => esc_html__( 'Archive page hero section overlay color display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select archive hero section overlay color %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_mask_c',
                'label' => esc_html__( 'Archive page hero section background overlay color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_archive_mask_v:is(on)',
                'section' => 'archive_page'
            ),
            array(
                'id' => 'nt_landium_archivepageheadbg',
                'label' =>  esc_html__( 'Archive page hero section background image', 'nt-landium' ),
                'desc' =>  esc_html__( 'You can upload your image for parallax hero', 'nt-landium' ),
                'type' => 'upload',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archiveheaderbgcolor',
                'label' => esc_html__( 'Archive page hero section background color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker',
                'section' => 'archive_page'
            ),
            array(
                'id' => 'nt_landium_archiveheaderbgheight',
                'label' => esc_html__('Archive page hero section height', 'nt-landium' ),
                'desc' => esc_html__('Archive page hero section height', 'nt-landium' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archiveheaderpaddingtop',
                'label' => esc_html__('Archive page hero section padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archiveheaderpaddingbottom',
                'label' => esc_html__('Archive page hero section padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_textalign',
                'label' => esc_html__( 'Archive page text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select archive page text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'archive_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            // Archive heading
            array(
                'id' => 'nt_landium_archive_heading_tab',
                'label' => esc_html__( 'Archive Heading', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'archive_page',
            ),
            array(
                'id' => 'nt_landium_archive_heading_visibility',
                'label' => esc_html__( 'Archive page heading display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Archive page heading display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_heading',
                'label' => esc_html__( 'Archive page heading', 'nt-landium' ),
                'desc' => esc_html__( 'Enter archive page heading', 'nt-landium' ),
                'std' => 'Our Archive',
                'type' => 'text',
                'condition' => 'nt_landium_archive_heading_visibility:is(on)',
                'section' => 'archive_page'
            ),
            array(
                'id' => 'nt_landium_archive_heading_fontsize',
                'label' => esc_html__('Archive page heading font size', 'nt-landium' ),
                'desc' => esc_html__('Enter archive page heading font size', 'nt-landium' ),
                'std' => '65',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'condition' => 'nt_landium_archive_heading_visibility:is(on)',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archiveheadingcolor',
                'label' => esc_html__( 'Archive page heading color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_archive_heading_visibility:is(on)',
                'section' => 'archive_page'
            ),
            // Archive slogan
            array(
                'id' => 'nt_landium_archive_slogan_tab',
                'label' => esc_html__( 'Archive Slogan', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'archive_page',
            ),
            array(
                'id' => 'nt_landium_archive_slogan_visibility',
                'label' => esc_html__( 'Archive page slogan display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select archive page slogan display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_slogan',
                'label' => esc_html__( 'Archive page slogan', 'nt-landium' ),
                'desc' => esc_html__( 'Enter archive page slogan', 'nt-landium' ),
                'std' => 'Welcome to your Archive. This is your all post. Edit or delete them, then start writing!',
                'type' => 'text',
                'condition' => 'nt_landium_archive_slogan_visibility:is(on)',
                'section' => 'archive_page'
            ),
            array(
                'id' => 'nt_landium_archiveheaderparagraphcolor',
                'label' => esc_html__( 'Archive page slogan color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_archive_slogan_visibility:is(on)',
                'section' => 'archive_page'
            ),
            // archive content
            array(
                'id' => 'nt_landium_archive_content_tab',
                'label' =>  esc_html__( 'Archive Content', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'archive_page',
            ),
            array(
                'id' => 'nt_landium_archive_content_textalign',
                'label' => esc_html__( 'Archive content post text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select archive page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'archive_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            //archive responsive 992px
            array(
                'id' => 'nt_landium_archive_992responsive_tab',
                'label' =>  esc_html__( 'Responsive( 992px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'archive_page',
            ),
            array(
                'id' => 'nt_landium_archive_992_headbg',
                'label' =>  esc_html__( 'Archive hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>992px</strong>' ),
                'type' => 'upload',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_992_bgheight',
                'label' => esc_html__('Archive page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_992_heading_textalign',
                'label' => esc_html__( 'Archive hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'archive_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_archive_992_heading_fontsize',
                'label' => esc_html__('Archive heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_992_heading_padtop',
                'label' => esc_html__('Archive hero section padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_992_heading_padbot',
                'label' => esc_html__('Archive hero section padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_992_content_textalign',
                'label' => esc_html__( 'Search page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select search page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'archive_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            //archive responsive 768px
            array(
                'id' => 'nt_landium_archive_768responsive_tab',
                'label' =>  esc_html__( 'Responsive( 768px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'archive_page',
            ),
            array(
                'id' => 'nt_landium_archive_768_headbg',
                'label' =>  esc_html__( 'Archive hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>768px</strong>' ),
                'type' => 'upload',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_768_bgheight',
                'label' => esc_html__('Archive page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>768px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_768_heading_textalign',
                'label' => esc_html__( 'Archive page hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'archive_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_archive_768_heading_fontsize',
                'label' => esc_html__('Archive page heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>768px</strong>' ),
                'std' => '40',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_768_heading_padtop',
                'label' => esc_html__('Archive page hero section padding top', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_768_heading_padbot',
                'label' => esc_html__('Archive page hero section padding bottom', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'archive_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_archive_768_content_textalign',
                'label' => esc_html__( 'Search page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select search page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'archive_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            /**  404 PAGE HEADER SETTINGS.  **/
            // 404 Hero
            array(
                'id' => 'nt_landium_error_hero',
                'label' => esc_html__( '404 Hero', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'error_page',
            ),
            array(
                'id' => 'nt_landium_error_mask_v',
                'label' => esc_html__( '404 page hero section overlay color display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select 404 page hero section overlay color display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_mask_c',
                'label' => esc_html__( '404 page hero section overlay color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_error_mask_v:is(on)',
                'section' => 'error_page'
            ),
            array(
                'id' => 'nt_landium_errorpageheadbg',
                'label' =>  esc_html__( '404 page hero section background image', 'nt-landium' ),
                'desc' =>  esc_html__( 'You can upload your image for parallax hero', 'nt-landium' ),
                'type' => 'upload',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_errorheaderbgcolor',
                'label' => esc_html__( '404 page hero section background color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'error_page'
            ),
            array(
                'id' => 'nt_landium_errorheaderbgheight',
                'label' => esc_html__('404 page hero section height', 'nt-landium' ),
                'desc' => esc_html__('404 page hero section height', 'nt-landium' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_errorheaderpaddingtop',
                'label' => esc_html__('404 page hero section padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_errorheaderpaddingbottom',
                'label' => esc_html__('404 page hero section padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_textalign',
                'label' => esc_html__( '404 page text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select 404 page text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'error_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            // 404 heading
            array(
                'id' => 'nt_landium_error_heading_tab',
                'label' => esc_html__( '404 Heading', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'error_page',
            ),
            array(
                'id' => 'nt_landium_error_heading_visibility',
                'label' => esc_html__( '404 page heading display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select 404 page heading display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_heading',
                'label' => esc_html__( '404 page heading', 'nt-landium' ),
                'desc' => esc_html__( 'Enter 404 page heading', 'nt-landium' ),
                'std' => '404 Page',
                'type' => 'text',
                'condition' => 'nt_landium_error_heading_visibility:is(on)',
                'section' => 'error_page'
            ),
            array(
                'id' => 'nt_landium_error_heading_fontsize',
                'label' => esc_html__('404 page heading font size', 'nt-landium' ),
                'desc' => esc_html__('Enter 404 page heading font size', 'nt-landium' ),
                'std' => '65',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'condition' => 'nt_landium_error_heading_visibility:is(on)',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_errorheadingcolor',
                'label' => esc_html__( '404 page heading color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_error_heading_visibility:is(on)',
                'section' => 'error_page'
            ),
            // 404 slogan
            array(
                'id' => 'nt_landium_error_slogan_tab',
                'label' => esc_html__( '404 Slogan', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'error_page',
            ),
            array(
                'id' => 'nt_landium_error_slogan_visibility',
                'label' => esc_html__( '404 page slogan display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select 404 Page slogan display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_slogan',
                'label' => esc_html__( '404 Page slogan', 'nt-landium' ),
                'desc' => esc_html__( 'Enter 404 Page slogan', 'nt-landium' ),
                'std' => 'Oops! That page can not be found.',
                'type' => 'text',
                'condition' => 'nt_landium_error_slogan_visibility:is(on)',
                'section' => 'error_page'
            ),
            array(
                'id' => 'nt_landium_errorheaderparagraphcolor',
                'label' => esc_html__( '404 Page slogan color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_error_slogan_visibility:is(on)',
                'section' => 'error_page'
            ),
            // 404 content
            array(
                'id' => 'nt_landium_error_content_tab',
                'label' =>  esc_html__( '404 Content', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'error_page',
            ),
            array(
                'id' => 'nt_landium_error_content_textalign',
                'label' => esc_html__( '404 page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select 404 page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'error_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            //error responsive 992px
            array(
                'id' => 'nt_landium_error_992responsive_tab',
                'label' =>  esc_html__( 'Responsive( 992px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'error_page',
            ),
            array(
                'id' => 'nt_landium_error_992_headbg',
                'label' =>  esc_html__( '404 Page hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>992px</strong>' ),
                'type' => 'upload',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_992_bgheight',
                'label' => esc_html__('404 Page page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_992_heading_textalign',
                'label' => esc_html__( '404 Page hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'error_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_error_992_heading_fontsize',
                'label' => esc_html__('404 Page heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_992_heading_padtop',
                'label' => esc_html__('404 Page hero section padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_992_heading_padbot',
                'label' => esc_html__('404 Page hero section padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_992_content_textalign',
                'label' => esc_html__( 'Search page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select search page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'error_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            //error responsive 768px
            array(
                'id' => 'nt_landium_error_768responsive_tab',
                'label' =>  esc_html__( 'Responsive( 768px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'error_page',
            ),
            array(
                'id' => 'nt_landium_error_768_headbg',
                'label' =>  esc_html__( '404 Page hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>768px</strong>' ),
                'type' => 'upload',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_768_bgheight',
                'label' => esc_html__('404 Page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>768px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_768_heading_textalign',
                'label' => esc_html__( '404 Page hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'error_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_error_768_heading_fontsize',
                'label' => esc_html__('404 Page heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>768px</strong>' ),
                'std' => '40',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_768_heading_padtop',
                'label' => esc_html__('404 Page hero section padding top', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_768_heading_padbot',
                'label' => esc_html__('404 Page hero section padding bottom', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'error_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_error_768_content_textalign',
                'label' => esc_html__( 'Search page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select search page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'error_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            /**  SEARCH PAGE HEADER SETTINGS.  **/
            // Search hero
            array(
                'id' => 'nt_landium_error_hero_tab',
                'label' => esc_html__( 'Search Hero', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'search_page',
            ),
            array(
                'id' => 'nt_landium_search_mask_v',
                'label' => esc_html__( 'Search page hero section overlay color display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select search page hero section overlay color display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_mask_c',
                'label' => esc_html__( 'Search page hero section overlay color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_search_mask_v:is(on)',
                'section' => 'search_page'
            ),
            array(
                'id' => 'nt_landium_searchpageheadbg',
                'label' =>  esc_html__( 'Search page hero section background image', 'nt-landium' ),
                'desc' =>  esc_html__( 'You can upload your image for parallax hero', 'nt-landium' ),
                'type' => 'upload',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_searchheaderbgcolor',
                'label' => esc_html__( 'Search page hero section background color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'section' => 'search_page'
            ),
            array(
                'id' => 'nt_landium_searchheaderbgheight',
                'label' => esc_html__('Search page hero section height', 'nt-landium' ),
                'desc' => esc_html__('Search page hero section height', 'nt-landium' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_searchheaderpaddingtop',
                'label' => esc_html__('Search page hero section padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_searchheaderpaddingbottom',
                'label' => esc_html__('Search page hero section padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_textalign',
                'label' => esc_html__( 'Search page text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select search page text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'search_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            // Search heading
            array(
                'id' => 'nt_landium_search_heading_tab',
                'label' => esc_html__( 'Search Heading', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'search_page',
            ),
            array(
                'id' => 'nt_landium_search_heading_visibility',
                'label' => esc_html__( 'Search page heading display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select search page heading display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_heading',
                'label' => esc_html__( 'Search page heading', 'nt-landium' ),
                'desc' => esc_html__( 'Enter search page heading', 'nt-landium' ),
                'std' => 'Search Page',
                'type' => 'text',
                'condition' => 'nt_landium_search_heading_visibility:is(on)',
                'section' => 'search_page'
            ),
            array(
                'id' => 'nt_landium_search_heading_fontsize',
                'label' => esc_html__('Search page heading font size', 'nt-landium' ),
                'desc' => esc_html__('Enter search page heading font size', 'nt-landium' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'condition' => 'nt_landium_search_heading_visibility:is(on)',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_searchheadingcolor',
                'label' => esc_html__( 'Search page heading color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_search_heading_visibility:is(on)',
                'section' => 'search_page'
            ),
            // Search slogan
            array(
                'id' => 'nt_landium_search_slogan_tab',
                'label' => esc_html__( 'Search Slogan', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'search_page',
            ),
            array(
                'id' => 'nt_landium_search_slogan_visibility',
                'label' => esc_html__( 'Search page slogan display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select search page slogan display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_slogan',
                'label' => esc_html__( 'Search page slogan', 'nt-landium' ),
                'desc' => esc_html__( 'Enter search page slogan', 'nt-landium' ),
                'std' => 'Search completed',
                'type' => 'text',
                'condition' => 'nt_landium_search_slogan_visibility:is(on)',
                'section' => 'search_page'
            ),
            array(
                'id' => 'nt_landium_searchheaderparagraphcolor',
                'label' => esc_html__( 'Search page slogan color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_search_slogan_visibility:is(on)',
                'section' => 'search_page'
            ),
            // Search content
            array(
                'id' => 'nt_landium_search_content_tab',
                'label' =>  esc_html__( 'Search Content', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'search_page',
            ),
            array(
                'id' => 'nt_landium_search_content_textalign',
                'label' => esc_html__( 'Search page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select search page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'search_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            //search responsive 992px
            array(
                'id' => 'nt_landium_search_992responsive_tab',
                'label' =>  esc_html__( 'Responsive( 992px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'search_page',
            ),
            array(
                'id' => 'nt_landium_search_992_headbg',
                'label' =>  esc_html__( 'Search page hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>992px</strong>' ),
                'type' => 'upload',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_992_bgheight',
                'label' => esc_html__('Search page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_992_heading_textalign',
                'label' => esc_html__( 'Search page hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'search_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_search_992_heading_fontsize',
                'label' => esc_html__('Search page heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>992px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_992_heading_padtop',
                'label' => esc_html__('Search page hero section padding top', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_992_heading_padbot',
                'label' => esc_html__('Search page hero section padding bottom', 'nt-landium' ),
                'desc' => esc_html__('You can use this option for heading text vertical align', 'nt-landium' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_992_content_textalign',
                'label' => esc_html__( 'Search page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select search page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'search_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            //search responsive 768px
            array(
                'id' => 'nt_landium_search_768responsive_tab',
                'label' =>  esc_html__( 'Responsive( 768px )', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'search_page',
            ),
            array(
                'id' => 'nt_landium_search_768_headbg',
                'label' =>  esc_html__( 'Search page hero section background image', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>768px</strong>' ),
                'type' => 'upload',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_768_bgheight',
                'label' => esc_html__('Search page hero height', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero height</strong>', '<strong>768px</strong>' ),
                'std' => '50',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_768_heading_textalign',
                'label' => esc_html__( 'Search page hero section text align', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text position</strong>', '<strong>992px</strong>' ),
                'type' => 'select',
                'section' => 'search_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_search_768_heading_fontsize',
                'label' => esc_html__('Search page heading font size', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>heading font size</strong>', '<strong>768px</strong>' ),
                'std' => '40',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_768_heading_padtop',
                'label' => esc_html__('Search page hero section padding top', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '250',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_768_heading_padbot',
                'label' => esc_html__('Search hero section padding bottom', 'nt-landium' ),
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>hero section text vertical align</strong>', '<strong>768px</strong>' ),
                'std' => '200',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,500',
                'section' => 'search_page',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_search_768_content_textalign',
                'label' => esc_html__( 'Search page content text align', 'nt-landium' ),
                'desc' => esc_html__( 'Select search page content text position', 'nt-landium' ),
                'type' => 'select',
                'section' => 'search_page',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '',
                        'label' => esc_html__( 'Select text-align', 'nt-landium' )
                    ),
                    array(
                        'value' => 'left',
                        'label' => esc_html__( 'left', 'nt-landium' )
                    ),
                    array(
                        'value' => 'center',
                        'label' => esc_html__( 'center', 'nt-landium' )
                    ),
                    array(
                        'value' => 'right',
                        'label' => esc_html__( 'right', 'nt-landium' )
                    ),
                )
            ),
            /**  BREADCRUBMS SETTINGS.  **/
            array(
                'id' => 'nt_landium_bread',
                'label' => esc_html__( 'Breadcrubms display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Please select blog and page breadcrubms display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'breadcrubms',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_blogbreadcrubmscolor',
                'label' => esc_html__( 'Breadcrubms color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_bread:is(on)',
                'section' => 'breadcrubms'
            ),
            array(
                'id' => 'nt_landium_blogbreadcrubmshovercolor',
                'label' => esc_html__( 'Breadcrubms hover color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_bread:is(on)',
                'section' => 'breadcrubms'
            ),
            array(
                'id' => 'nt_landium_blogbreadcrubmscurrentcolor',
                'label' => esc_html__( 'Breadcrubms current page text color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_bread:is(on)',
                'section' => 'breadcrubms'
            ),
            array(
                'id' => 'nt_landium_blogbreadcrubmsfontsize',
                'label' => esc_html__('Breadcrubms font size', 'nt-landium' ),
                'desc' => esc_html__('Breadcrubms font size', 'nt-landium' ),
                'std' => '15',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'condition' => 'nt_landium_bread:is(on)',
                'section' => 'breadcrubms',
                'operator' => 'and'
            ),

            /**  FOOTER SETTINGS.  **/
            array(
                'id' => 'landium_footer_general',
                'label' => esc_html__( 'Footer General', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'footer'
            ),
            array(
                'id' => 'landium_footer_template_type',
                'label' => esc_html__( 'Footer Template Type ( New )', 'nt-landium' ),
                'std' => 'default',
                'type' => 'select',
                'section' => 'footer',
                'operator' => 'and',
                'choices' =>  array(
                    array(
                        'value' => 'default',
                        'label' => esc_html__( 'Default', 'nt-landium' )
                    ),
                    array(
                        'value' => 'page',
                        'label' => esc_html__( 'Page Content', 'nt-landium' )
                    ),
                    array(
                        'value' => 'custom',
                        'label' => esc_html__( 'Shortcode or Custom HTML', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'landium_footer_custom_template',
                'label' => esc_html__( 'Custom Page Content', 'nt-landium' ),
                'desc' => esc_html__( 'You can use your custom page instead of the default footer template.', 'nt-landium' ),
                'type' => 'page-select',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(page)',
                'operator' => 'and'
            ),
            array(
                'id' => 'landium_footer_custom_html',
                'label' => esc_html__( 'Custom HTML or Shortcode', 'nt-landium' ),
                'desc' => esc_html__( 'Copy paste your shortcode here.', 'nt-landium' ),
                'type' => 'textarea',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(custom)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_footer_style',
                'label' => esc_html__( 'Footer style', 'nt-landium' ),
                'desc' => esc_html__( 'Select theme footer style' , 'nt-landium' ),
                'type' => 'select',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(default)',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '1',
                        'label' => esc_html__( 'Style 1', 'nt-landium' )
                    ),
                    array(
                        'value' => '2',
                        'label' => esc_html__( 'Style 2', 'nt-landium' )
                    ),
                    array(
                        'value' => '3',
                        'label' => esc_html__( 'Style 3', 'nt-landium' )
                    ),
                )
            ),

            // WIDGETIZE FOOTER
            array(
                'id' => 'nt_landium_widgetize_tab',
                'label' => esc_html__( 'Footer Widgetize', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'footer',
            ),
            array(
                'id' => 'nt_landium_widgetize',
                'label' => esc_html__( 'Footer top widgetize area section', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Choose footer widgetize section %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'off',
                'type' => 'on-off',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(default)',
                'operator' => 'and',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_footerwidgetizebgimg',
                'label' => 'Footer widgetize background image',
                'desc' => 'Upload background image',
                'type' => 'background',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_widgetize:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footerwidgetizebgoverlay',
                'label' => esc_html__( 'Footer widgetize background overlay color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_widgetize:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footerwidgetizebgcolor',
                'label' => esc_html__( 'Footer widgetize background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_widgetize:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footer_h_c',
                'label' => esc_html__( 'Footer widgetize widget heading color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_widgetize:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footer_t_c',
                'label' => esc_html__( 'Footer widgetize text color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_widgetize:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footer_a_c',
                'label' => esc_html__( 'Footer widgetize a(link/URL) color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_widgetize:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footer_a_hc',
                'label' => esc_html__( 'Footer widgetize a(link/URL) hover color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_widgetize:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footerwidgetizepadtop',
                'label' => esc_html__('Footer widgetize padding top', 'nt-landium' ),
                'desc' => esc_html__('Enter padding top for footer widgetize section', 'nt-landium' ),
                'type' => 'numeric-slider',
                'std' => '40',
                'min_max_step'=> '0,250',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_widgetize:is(on)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_footerwidgetizepadbottom',
                'label' => esc_html__('Footer widgetize padding bottom', 'nt-landium' ),
                'desc' => esc_html__('Enter padding bottom for footer widgetize section', 'nt-landium' ),
                'type' => 'numeric-slider',
                'std' => '40',
                'min_max_step'=> '0,250',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_widgetize:is(on)',
                'operator' => 'and'
            ),
            // NEWSLETTER FOOTER
            array(
                'id' => 'nt_landium_newsletter_tab',
                'label' => esc_html__( 'Contact Form', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'footer',
            ),
            array(
                'id' => 'nt_landium_news',
                'label' => esc_html__( 'Footer newsletter section visibility ', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Choose newsletter section visibility %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(default)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_news_h',
                'label' => 'Footer newsletter heading',
                'type' => 'text',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_news_d',
                'label' => 'Footer newsletter description',
                'type' => 'text',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footernewsletterbgcolor',
                'label' => esc_html__( 'Footer newsletter background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footernewslettertitlecolor',
                'label' => esc_html__( 'Footer newsletter title color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footernewsletterdesccolor',
                'label' => esc_html__( 'Footer newsletter description color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footernewsletterinputcolor',
                'label' => esc_html__( 'Footer newsletter input text color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footernewslettericoncolor',
                'label' => esc_html__( 'Footer newsletter input icon color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footernewsletterinputbordercolor',
                'label' => esc_html__( 'Footer newsletter input border bottom color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footernewsletterbuttonbordercolor',
                'label' => esc_html__( 'Footer newsletter button border color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footernewsletterbuttoncolor',
                'label' => esc_html__( 'Footer newsletter button background hover color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_news:is(on)',
                'section' => 'footer'
            ),
            // CONTACT FOOTER
            array(
                'id' => 'nt_landium_contact_tab',
                'label' => esc_html__( 'Footer Contact', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'footer',
            ),
            array(
                'id' => 'nt_landium_contact',
                'label' => esc_html__( 'Footer contact section visibility ', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Choose contact section visibility %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'condition' => 'landium_footer_template_type:is(default)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_adress',
                'label' => 'Footer adress',
                'type' => 'textarea',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_contact:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_phone',
                'label' => 'Footer phone',
                'type' => 'textarea',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_contact:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_mail',
                'label' => 'Footer mail',
                'type' => 'textarea',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_contact:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footerbgcolor',
                'label' => esc_html__( 'Footer Background color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_contact:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footercontacttextcolor',
                'label' => esc_html__( 'Footer contact text color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_contact:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footercontacticoncolor',
                'label' => esc_html__( 'Footer contact icon color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_contact:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footercontactpaddingtop',
                'label' => esc_html__('Footer contact padding top', 'nt-landium' ),
                'desc' => esc_html__('Enter padding top for footer contact section', 'nt-landium' ),
                'type' => 'numeric-slider',
                'std' => '85',
                'min_max_step'=> '0,250',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_contact:is(on)',
                'operator' => 'and'
            ),

            array(
                'id' => 'nt_landium_footercontactpaddingbottom',
                'label' => esc_html__('Footer contact padding bottom', 'nt-landium' ),
                'desc' => esc_html__('Enter padding bottom for footer contact section', 'nt-landium' ),
                'type' => 'numeric-slider',
                'std' => '0',
                'min_max_step'=> '0,250',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_contact:is(on)',
                'operator' => 'and'
            ),
            // FOOTER COPYRIGHT
            array(
                'id' => 'nt_landium_copyright_tab',
                'label' => esc_html__( 'Footer Copyright', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'footer',
            ),
            array(
                'id' => 'nt_landium_footer_default',
                'label' => esc_html__( 'Footer copyright section display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Choose footer copyright section %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'section' => 'footer',
                'condition' => 'landium_footer_template_type:is(default)',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_copyright',
                'label' => 'Footer copyright',
                'type' => 'textarea',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_footer_default:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footerpoweredbordertopcolor',
                'label' => esc_html__( 'Footer copyright border top color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_footer_default:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footerpoweredcolor',
                'label' => esc_html__( 'Footer copyright text color', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_footer_default:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footercopyrightpadding',
                'label' => esc_html__('Footer copyright padding top and botom', 'nt-landium' ),
                'desc' => esc_html__('Enter padding top and botom for footer copyright', 'nt-landium' ),
                'type' => 'numeric-slider',
                'std' => '30',
                'min_max_step'=> '0,250',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_footer_default:is(on)',
                'section' => 'footer',
                'operator' => 'and'
            ),
            // FOOTER SOCIAL
            array(
                'id' => 'nt_landium_social_tab',
                'label' => esc_html__( 'Footer Social', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'footer',
            ),
            array(
                'id' => 'nt_landium_social_section',
                'label' => esc_html__( 'Social section visibility ', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Choose social section visibility %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'condition' => 'landium_footer_template_type:is(default)',
                'section' => 'footer',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_social',
                'label' => 'Footer Social Icons',
                'desc' => 'Footer Social Icons',
                'type' => 'list-item',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_social_section:is(on)',
                'section' => 'footer',
                'settings' => array(
                    array(
                        'id' => 'nt_landium_social_text',
                        'label' => 'social icon name',
                        'desc' => 'Enter font awesome social icon name',
                        'type' => 'text',
                    ),
                    array(
                        'id' => 'nt_landium_social_link',
                        'label' => 'Link',
                        'desc' => 'Enter font awesome social share link',
                        'type' => 'text',
                    )
                )
            ),
            array(
                'id' => 'nt_landium_social_target',
                'label' => esc_html__( 'Target social media', 'nt-landium' ),
                'desc' => esc_html__( 'Select social media target type. Default : _blank' , 'nt-landium' ),
                'std' => '_blank',
                'type' => 'select',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_social_section:is(on)',
                'section' => 'footer',
                'operator' => 'and',
                'choices' => array(
                    array(
                        'value' => '_blank',
                        'label' => esc_html__( '_blank', 'nt-landium' )
                    ),
                    array(
                        'value' => '_self',
                        'label' => esc_html__( '_self', 'nt-landium' )
                    ),
                    array(
                        'value' => '_parent',
                        'label' => esc_html__( '_parent', 'nt-landium' )
                    ),
                    array(
                        'value' => '_top',
                        'label' => esc_html__( '_top', 'nt-landium' )
                    ),
                )
            ),
            array(
                'id' => 'nt_landium_social_fontsize',
                'label' => esc_html__('Footer social font size', 'nt-landium' ),
                'desc' => esc_html__('Footer social media font size', 'nt-landium' ),
                'std' => '22',
                'type' => 'numeric-slider',
                'min_max_step'=> '0,100',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_social_section:is(on)',
                'section' => 'footer',
                'operator' => 'and'
            ),
            array(
                'id' => 'nt_landium_footersocialcolor',
                'label' => esc_html__( 'Footer Social color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_social_section:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_footersocialhovercolor',
                'label' => esc_html__( 'Footer Social Icon hover color ', 'nt-landium' ),
                'desc' => esc_html__( 'Please select color', 'nt-landium' ),
                'type' => 'colorpicker-opacity',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_social_section:is(on)',
                'section' => 'footer'
            ),

            // FOOTER map
            array(
                'id' => 'nt_landium_map_tab',
                'label' => esc_html__( 'Google Maps', 'nt-landium' ),
                'type' => 'tab',
                'section' => 'footer',
            ),
            array(
                'id' => 'nt_landium_map_display',
                'label' => esc_html__( 'Footer google maps display', 'nt-landium' ),
                'desc' => sprintf( esc_html__( 'Choose footer google maps display %s or %s.', 'nt-landium' ), '<code>on</code>', '<code>off</code>' ),
                'std' => 'on',
                'type' => 'on-off',
                'condition' => 'landium_footer_template_type:is(default)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_map_api_key',
                'label' =>  esc_html__( 'Google Maps api key', 'nt-landium' ),
                'desc' =>  esc_html__( 'You must create an api key and paste this box. Create :https://developers.google.com/maps/documentation/javascript/get-api-key#key ', 'nt-landium' ),
                'type' => 'text',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_map_display:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_longitude',
                'label' => esc_html__( 'Google Maps longitude', 'nt-landium' ),
                'type' => 'text',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_map_display:is(on)',
                'section' => 'footer'
            ),
            array(
                'id' => 'nt_landium_latitude',
                'label' => esc_html__( 'Google Maps latitude', 'nt-landium' ),
                'type' => 'text',
                'condition' => 'landium_footer_template_type:is(default),nt_landium_map_display:is(on)',
                'section' => 'footer'
            ),
        ) // end array
    ); // end function

    /* allow settings to be filtered before saving */
    $nt_landium_custom_settings = apply_filters( ot_settings_id() . '_args', $nt_landium_custom_settings );

    /* settings are not the same update the DB */
    if ( $nt_landium_saved_settings !== $nt_landium_custom_settings ) {
        update_option( ot_settings_id(), $nt_landium_custom_settings );
    }

    /* Lets OptionTree know the UI Builder is being overridden */
    global $ot_has_custom_theme_options;
    $ot_has_custom_theme_options = true;

}
