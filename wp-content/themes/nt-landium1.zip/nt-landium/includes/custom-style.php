<?php

function nt_landium_custom_preloader_script() { ?>

<?php  if ( function_exists( 'ot_get_option' ) ) : ?>

	<?php //CUSTOM PRELOADER AND CUSTOM JAVASCRIPT  ?>
	<?php if ( ot_get_option( 'nt_landium_custom_preloader_js' ) !='off' && ot_get_option( 'nt_landium_preloaderjs' ) !='' ) : ?>

		<script id="nt-landium-custom-preloader-and-custom-script" type="text/javascript">

		<?php if(ot_get_option('nt_landium_preloaderjs')) { echo  ot_get_option( 'nt_landium_preloaderjs' ) ; }  ?>

		</script>

	<?php endif; ?>

	<?php //CUSTOM PRELOADER AND DEFAULT JAVASCRIPT ?>
	<?php if ( ot_get_option( 'nt_landium_custom_preloader_js' ) =='off' && ot_get_option( 'nt_landium_custom_preloader' ) !='' ) : ?>

		<script id="nt-landium-custom-preloader-and-default-script" type="text/javascript">

			jQuery(document).ready(function($) {
				"use strict";

				jQuery(window).load(function() {
					// Animate loader off screen
					jQuery(".nt-landium-custom-preloader").fadeOut("slow");;
				});

			})(jQuery);

		</script>

	<?php endif;?>
<?php endif; ?>
<?php }

add_action('wp_footer', 'nt_landium_custom_preloader_script');


function nt_landium_css_options() {

    /* CSS to output */
    $theCSS = '';

	// admin bar
	if( is_admin_bar_showing() && ! is_customize_preview() ) {
		 $theCSS .= '.template-nav-style-1, .template-nav-style-2 {
			margin-top: 72px;
		}
		#top-bar.fixed{ margin-top: 32px !important;}

		@media (max-width: 992px){
			#top-bar.fixed{ margin-top: 0px !important;}
			body.admin-bar{ position: inherit !important; }
			#top-bar {top: 32px !important;}
		}
		@media (max-width: 600px){
			#top-bar {top: 46px !important;}
			#top-bar.fixed{ top: 0px !important;}
		}
		@media (max-width: 480px){
			#top-bar {top: 46px !important;}
			#top-bar.fixed{ top: 0px !important;}
		}
		';
	} // end admin

	// theme defaults
	$theCSS .= '.start-screen--static-bg--style-1 .start-screen__static-bg:after {
		content: "";
		position: absolute;
		left: 0;
		bottom: 0;
		width: 100%;
		height: 115px;
		background-image: url( '. get_template_directory_uri() . '/images/bevel.png'.'); background-position: 0 0;
	}

	.b-video .b-video__btn-play i:before {
		opacity: 1;
		background-image: url('. get_template_directory_uri() . '/images/ico_play.png'.');
	}

	.b-video .b-video__btn-play i:after {
		opacity: 0;
		background-image: url('. get_template_directory_uri() . '/images/ico_play_hover.png'.');
	}';

	function hex2rgb($hex) {
	$hex = str_replace("#", "", $hex);

	if(strlen($hex) == 3) {
	$r = hexdec(substr($hex,0,1).substr($hex,0,1));
	$g = hexdec(substr($hex,1,1).substr($hex,1,1));
	$b = hexdec(substr($hex,2,1).substr($hex,2,1));
	} else {
	$r = hexdec(substr($hex,0,2));
	$g = hexdec(substr($hex,2,2));
	$b = hexdec(substr($hex,4,2));
	}
	$rgb = array($r, $g, $b);

	return $rgb; // returns an array with the rgb values
	}

	// color options

	$nt_landium_theme_color = ot_get_option( 'nt_landium_theme_color' ) ;


	$custom_color 	= esc_attr( ot_get_option( 'nt_landium_theme_color_one' ) );
	$link_color 	= ot_get_option( 'nt_landium_theme_color_two' ) ;
	$link_hover 	= ot_get_option( 'nt_landium_theme_color_three' ) ;

	if( $nt_landium_theme_color == 'custom' ){

	$one_color = $custom_color;
	$a_color = $link_color;
	$a_hover = ( $link_hover != '') ? $link_hover : $custom_color;

	}else{

		$one_color = $nt_landium_theme_color;
		$a_color = '';
		$a_hover = $nt_landium_theme_color;

	}

	$theCSS .= '
	a, .entry-meta li a, #widget-area .widget ul li a, #share-buttons i { color:' . $a_color . ';}
	a:hover, a:focus, .entry-title a:hover, .entry-meta a:hover, #widget-area .widget ul li a:hover, #share-buttons i:hover, .flex-direction-nav a { color:' . $a_hover . ';}
	 a.margin_30.btn:hover, .pager li > a:hover { border-color:' . $a_hover . ';}
	 a.margin_30.btn:hover, .pager li > a, .pager li > a:hover { background-color:' . $a_hover . ';}
	.pricing-table .price-item__label, .list-with-icon--style-1 .font-icon, .list-with-icon--style-2 .font-icon, .list-with-icon--style-3 .font-icon, .feedback .feedback__text:before, .b-video .b-video__btn-play:hover i {
	color:' . $one_color . ';
	}
	.team .team__item:hover .team__description, .pricing-table--style-2 .price-item__active, .pricing-table--style-2 .price-item__btn, .custom-btn.info, .start-screen form input[type="submit"], .section--background-base, .pattern, .b-video .b-video__btn-play:before, #footer .s-form, #footer.footer--style-2:before, #footer.footer--style-2 .s-form:before, #top-bar__navigation li:not(.menu-item--button):before, #top-bar__navigation li:not(.menu-item--button):after, .margin_30, .pager li > a, .pager li > span, #widget-area #searchform input#searchsubmit, body.search article .searchform input[type="submit"], body.error404 .index .searchform input[type="submit"] {
	background-color:' . $one_color . ';
	}
	.pricing-table--style-2 .price-item__active, .custom-btn.info, .list-with-icon--style-3 .list__item__ico, .start-screen form input[type="submit"], .section--background-base, .pattern, .b-video .b-video__btn-play:before, .widget-title:after, .pager li > a, .pager li > span, a.margin_30.btn {
	border-color:' . $one_color . ';
	}
	.owl-theme .owl-dots .owl-dot.active span, .owl-theme .owl-dots .owl-dot:hover span {
		-webkit-box-shadow: 0 0 0 6px ' . $one_color . ' inset;
		box-shadow: 0 0 0 6px ' . $one_color . ' inset;
	}
	';

    $static_header_h  = ot_get_option('nt_landium_static_header_height' );
    $static_header_pt = ot_get_option('nt_landium_static_header_padding_top' );
    $static_header_pb = ot_get_option('nt_landium_static_header_padding_bottom' );

    $sticky_header_h  = ot_get_option('nt_landium_sticky_header_height' );
    $sticky_header_pt = ot_get_option('nt_landium_sticky_header_padding_top' );
    $sticky_header_pb = ot_get_option('nt_landium_sticky_header_padding_bottom' );
    
    if ( $sticky_header_h || $sticky_header_pt || $sticky_header_pb || $static_header_h || $static_header_pt || $static_header_pb ) {
        $theCSS .= '@media only screen and (min-width: 992px){';
        if ( $static_header_h != '' ) {
            $theCSS .= '#top-bar { height:auto;min-height: '.$static_header_h.'px;}';
        }
        if ( $static_header_pt != '' ) {
            $theCSS .= '#top-bar { padding-top: '.$static_header_pt.'px;}';
        }
        if ( $static_header_pb != '' ) {
            $theCSS .= '#top-bar { padding-bottom: '.$static_header_pb.'px;}';
        }
        if ( $sticky_header_h != '' ) {
            $theCSS .= '#top-bar.fixed {height:auto; min-height: '.$sticky_header_h.'px;}';
        }
        if ( $sticky_header_pt != '' ) {
            $theCSS .= '#top-bar.fixed { padding-top: '.$sticky_header_pt.'px;}';
        }
        if ( $sticky_header_pb != '' ) {
            $theCSS .= '#top-bar.fixed { padding-bottom: '.$sticky_header_pb.'px;}';
        }
        $theCSS .= '}';
    }
    $mobile_header_h  = ot_get_option('nt_landium_mobile_header_height' );
    $mobile_header_pt = ot_get_option('nt_landium_mobile_header_padding_top' );
    $mobile_header_pb = ot_get_option('nt_landium_mobile_header_padding_bottom' );
    if ( $mobile_header_h || $mobile_header_pt || $mobile_header_pb ) {
        $theCSS .= '@media only screen and (max-width: 991px){';
        if ( $mobile_header_h != '' ) {
            $theCSS .= '#top-bar { height:auto;min-height: '.$mobile_header_h.'px;}';
        }
        if ( $mobile_header_pt != '' ) {
            $theCSS .= '#top-bar { padding-top: '.$mobile_header_pt.'px;}';
        }
        if ( $mobile_header_pb != '' ) {
            $theCSS .= '#top-bar { padding-bottom: '.$mobile_header_pb.'px;}';
        }
        $theCSS .= '}';
    }

	$counticon = 1;
	$nt_landium_menuicon = ot_get_option('nt_landium_menuicon' );
	$nt_landium_menuicon_color = ot_get_option('nt_landium_menuicon_color' );
	$nt_landium_menuicon_desktop = ot_get_option('nt_landium_menuicon_desktop' );
	$nt_landium_menuicon_mobile = ot_get_option('nt_landium_menuicon_mobile' );
	if (!empty( $nt_landium_menuicon )) {
		$theCSS .= '#top-bar__navigation li a:before{position:relative;font-family:FontAwesome;margin-right:10px;}';
		$theCSS .= '#top-bar__navigation ul.dropdown-menu li a:before{content:none!important;}';
		if ( $nt_landium_menuicon_color !='' ) { $theCSS .= '#top-bar__navigation li a:before {color:'.$nt_landium_menuicon_color.';}'; }
		foreach($nt_landium_menuicon as $key => $icon) {
			$theCSS .= '#top-bar__navigation ul li:nth-child('.$counticon.') a:before{content:"\\'.esc_html($icon['nt_landium_mobileitemicon']).'";}';
			$counticon++;
		}
	}

	if ( $nt_landium_menuicon_desktop == 'off' ) {
		$theCSS .= '@media (min-width:992px){#top-bar__navigation ul li a:before{content:none!important;}}';
	}
	if ( $nt_landium_menuicon_mobile == 'off' ) {
		$theCSS .= '@media (max-width:992px){#top-bar__navigation ul li a:before{content:none!important;}}';
	}
	//static nav
	$nav_padding 			= ( ot_get_option( 'nt_landium_navpadding', array() ) );
	$nav_margin 			= ( ot_get_option( 'nt_landium_navmargin', array() ) );
	$nav_menu_ifs 			= esc_attr( ot_get_option( 'nt_landium_nav_menu_ifs' ) );
	$static_nav_bg 			= esc_attr( ot_get_option( 'nt_landium_nav_bg' ) );
    $static_navitem 		= esc_attr( ot_get_option( 'nt_landium_navitem' ) );
    $static_navitemhover 	= esc_attr( ot_get_option( 'nt_landium_navitemhover' ) );
    $static_navitemhoverborder 	= esc_attr( ot_get_option( 'static_navitemhoverborder' ) );
    $static_navitemhoverborderdisplay 	= esc_attr( ot_get_option( 'static_navitemhoverborderdisplay' ) );
    $static_navitemhoverborderwidth 	= esc_attr( ot_get_option( 'static_navitemhoverborderwidth' ) );
    $nt_landium_stickylogoimg 	= esc_attr( ot_get_option( 'nt_landium_stickylogoimg' ) );
    $nt_landium_stickytextlogo 	= esc_attr( ot_get_option( 'nt_landium_stickytextlogo' ) );

	// logo img width and height
	//logo padding
	if ( !empty($nav_padding) ) {
		$theCSS .= '#top-bar{';
		if(!empty($nav_padding['unit']))   { $logopadunit = $nav_padding['unit'];}else{ $logopadunit = 'px'; }
		if(!empty($nav_padding['top']))    { $theCSS .= 'padding-top:'.$nav_padding['top'].''.$logopadunit.' !important;'; }
		if(!empty($nav_padding['bottom'])) { $theCSS .= 'padding-bottom:'.$nav_padding['bottom'].''.$logopadunit.' !important;'; }
		if(!empty($nav_padding['right']))  { $theCSS .= 'padding-right:'.$nav_padding['right'].''.$logopadunit.' !important;'; }
		if(!empty($nav_padding['left']))   { $theCSS .= 'padding-left:'.$nav_padding['left'].''.$logopadunit.' !important;'; }
		$theCSS .= '}#top-bar.fixed {padding-bottom: 55px !important;}';
	}
	if ( !empty($nav_margin) ) {
		$theCSS .= '#top-bar{';
		if(!empty($nav_margin['unit']))   { $logomarunit = $nav_margin['unit'];}else{ $logomarunit = 'px'; }
		if(!empty($nav_margin['top']))    { $theCSS .= 'margin-top:'.$nav_margin['top'].''.$logomarunit.' !important;'; }
		if(!empty($nav_margin['bottom'])) { $theCSS .= 'margin-bottom:'.$nav_margin['bottom'].''.$logomarunit.' !important;'; }
		if(!empty($nav_margin['right']))  { $theCSS .= 'margin-right:'.$nav_margin['right'].''.$logomarunit.' !important;'; }
		if(!empty($nav_margin['left']))   { $theCSS .= 'margin-left:'.$nav_margin['left'].''.$logomarunit.' !important;'; }
		$theCSS .= '}';
	}
	if ( $static_nav_bg !='' ) 			{ $theCSS .= '#top-bar {background-color:'.$static_nav_bg.'!important;padding-bottom: 12px;}'; }
	if ( $nav_menu_ifs !=0 ) 		{ $theCSS .= '#top-bar  #top-bar__navigation ul > li > a {font-size:'.$nav_menu_ifs.'px!important;}'; }
	if ( $static_navitem !='' ) 		{ $theCSS .= '#top-bar  #top-bar__navigation ul > li > a {color:'.$static_navitem.'!important;}'; }
	if ( $static_navitemhover !='' )	{ $theCSS .= '#top-bar  #top-bar__navigation ul > li > a:focus, #top-bar  #top-bar__navigation ul > li > a:hover, #top-bar  #top-bar__navigation ul > li.active > a{color:'.$static_navitemhover.'!important;}'; }
	if ( $static_navitemhoverborder !='' )  { $theCSS .= '#top-bar__navigation li:not(.menu-item--button):before, #top-bar__navigation li:not(.menu-item--button):after{background-color:'.$static_navitemhoverborder.'!important;}'; }
	if ( $static_navitemhoverborderwidth !='' )  { $theCSS .= '#top-bar__navigation li:not(.menu-item--button):before, #top-bar__navigation li:not(.menu-item--button):after{width:'.$static_navitemhoverborderwidth.'!important;}'; }
	if ( $static_navitemhoverborderdisplay =='off' )  { $theCSS .= '#top-bar__navigation li:not(.menu-item--button):before, #top-bar__navigation li:not(.menu-item--button):after{content:none!important;}#top-bar.fixed #top-bar__navigation li:not(.menu-item--button):before, #top-bar.fixed #top-bar__navigation li:not(.menu-item--button):after{content:""!important;}'; }
	if ( $nt_landium_stickylogoimg !='' or $nt_landium_stickytextlogo !='' )  {
        $theCSS .= '#top-bar .sticky-logo{display:none!important}';
        $theCSS .= '#top-bar.fixed .static-logo{display:none!important}';
        $theCSS .= '#top-bar.fixed .sticky-logo{display:block!important}';
     }

	//sticky nav
	$snav_pad 				= ( ot_get_option( 'nt_landium_stickynavpadding', array() ) );
	$snav_margin 			= ( ot_get_option( 'nt_landium_stickynavmargin', array() ) );
	$nav_fixed_display 		= esc_attr( ot_get_option( 'nt_landium_nav_fixed_display' ) );
	$sticky_navbg 			= esc_attr( ot_get_option( 'nt_landium_nav_fixed_bg' ) );
    $sticky_navitem 		= esc_attr( ot_get_option( 'nt_landium_navitem_after_s' ) );
    $sticky_navitemhover 	= esc_attr( ot_get_option( 'nt_landium_fixed_navitemhover' ) );
    $sticky_navitemhoverborder 	= esc_attr( ot_get_option( 'nt_landium_stick_navitemhoverborder' ) );
    $sticky_navitemhoverborderdisplay 	= esc_attr( ot_get_option( 'nt_landium_stick_navitemhoverborderdisplay' ) );
    $sticky_navitemhoverborderwidth 	= esc_attr( ot_get_option( 'nt_landium_stick_navitemhoverborderwidth' ) );


	if ( $nav_fixed_display == 'off' ) {
		$theCSS .= '#top-bar.fixed {position: absolute!important;}';
		if ( $static_nav_bg !='' ) {$theCSS .= '#top-bar.fixed {background-color:'.$static_nav_bg.'!important;}'; }
		else{$theCSS .= '#top-bar.fixed { background-color: transparent!important;}'; }
	}
	if ( $nav_fixed_display != 'off' ) {
		if ( !empty($snav_pad) ) {
			$theCSS .= '#top-bar.fixed{';
			if(!empty($snav_pad['unit']))   { $navpadunit = $snav_pad['unit'];}else{ $navpadunit = 'px'; }
			if(!empty($snav_pad['top']))    { $theCSS .= 'padding-top:'.$snav_pad['top'].''.$navpadunit.' !important;'; }
			if(!empty($snav_pad['bottom'])) { $theCSS .= 'padding-bottom:'.$snav_pad['bottom'].''.$navpadunit.' !important;'; }
			if(!empty($snav_pad['right']))  { $theCSS .= 'padding-right:'.$snav_pad['right'].''.$navpadunit.' !important;'; }
			if(!empty($snav_pad['left']))   { $theCSS .= 'padding-left:'.$snav_pad['left'].''.$navpadunit.' !important;'; }
			$theCSS .= '}';
		}
		if ( !empty($snav_margin) ) {
			$theCSS .= '#top-bar.fixed{';
			if(!empty($snav_margin['unit']))   { $navmarunit = $snav_margin['unit'];}else{ $navmarunit = 'px'; }
			if(!empty($snav_margin['top']))    { $theCSS .= 'margin-top:'.$snav_margin['top'].''.$navmarunit.' !important;'; }
			if(!empty($snav_margin['bottom'])) { $theCSS .= 'margin-bottom:'.$snav_margin['bottom'].''.$navmarunit.' !important;'; }
			if(!empty($snav_margin['right']))  { $theCSS .= 'margin-right:'.$snav_margin['right'].''.$navmarunit.' !important;'; }
			if(!empty($snav_margin['left']))   { $theCSS .= 'margin-left:'.$snav_margin['left'].''.$navmarunit.' !important;'; }
			$theCSS .= '}';
		}

		if ( $sticky_navbg !='' ) 			{ $theCSS .= '#top-bar.fixed {background-color:'.$sticky_navbg.'!important;}'; }
		if ( $sticky_navitem !='' ) 		{ $theCSS .= '#top-bar.fixed #top-bar__navigation ul > li > a {color:'.$sticky_navitem.'!important;}'; }
		if ( $sticky_navitemhover !='' )	{ $theCSS .= '#top-bar.fixed #top-bar__navigation ul > li > a:focus, #top-bar.fixed  #top-bar__navigation ul > li > a:hover, #top-bar.fixed #top-bar__navigation ul > li.active > a{color:'.$sticky_navitemhover.'!important;}'; }
		if ( $sticky_navitemhoverborder !='' )  { $theCSS .= '#top-bar.fixed #top-bar__navigation li:not(.menu-item--button):before, #top-bar.fixed #top-bar__navigation li:not(.menu-item--button):after{background-color:'.$sticky_navitemhoverborder.'!important;}'; }
		if ( $sticky_navitemhoverborderwidth !='' )  { $theCSS .= '#top-bar.fixed #top-bar__navigation li:not(.menu-item--button):before, #top-bar.fixed #top-bar__navigation li:not(.menu-item--button):after{width:'.$sticky_navitemhoverborderwidth.'!important;}'; }
		if ( $sticky_navitemhoverborderdisplay =='off' )  { $theCSS .= '#top-bar.fixed #top-bar__navigation li:not(.menu-item--button):before, #top-bar.fixed #top-bar__navigation li:not(.menu-item--button):after{content:none!important;}'; }
	}

	//dropdown submenu
	$dropdownbg 			= esc_attr( ot_get_option( 'nt_landium_dropdown_bg' ) );
    $dropdownitem 			= esc_attr( ot_get_option( 'nt_landium_dropdown_item' ) );
    $dropdownitemhover 		= esc_attr( ot_get_option( 'nt_landium_dropdown_itemhover' ) );
    $dropdownitemhoverbg 	= esc_attr( ot_get_option( 'nt_landium_dropdown_itemhoverbg' ) );

	if ( $dropdownbg !='' )  { $theCSS .= '#top-bar  #top-bar__navigation ul > li .dropdown-menu {background-color:'.$dropdownbg.'!important;}'; }
	if ( $dropdownitem !='' ){ $theCSS .= '#top-bar  #top-bar__navigation ul > li .dropdown-menu > li > a{color:'.$dropdownitem.'!important;}'; }
	if ( $dropdownitemhover !='' ) 	{ $theCSS .= '#top-bar  #top-bar__navigation ul > li .dropdown-menu > li > a:focus, #top-bar  #top-bar__navigation ul > li .dropdown-menu > li > a:hover, #top-bar  #top-bar__navigation ul > li .dropdown-menu > li.active > a{color:'.$dropdownitemhover . '!important;}'; }
	if ( $dropdownitemhoverbg !='' ){ $theCSS .= '#top-bar  #top-bar__navigation ul > li .dropdown-menu > li > a:focus, #top-bar  #top-bar__navigation ul > li .dropdown-menu > li > a:hover, #top-bar  #top-bar__navigation ul > li .dropdown-menu > li.active > a{background-color:'.$dropdownitemhoverbg.'!important;}'; }

	// mobile nav
	$mobile_bg 		 = esc_attr( ot_get_option( 'nt_landium_mobile_bg' ) );
    $mobile_item 	 = esc_attr( ot_get_option( 'nt_landium_mobile_item' ) );
    $mobile_i_h 	 = esc_attr( ot_get_option( 'nt_landium_mobile_itemhover' ) );
    $mobile_i_hbg 	 = esc_attr( ot_get_option( 'nt_landium_mobile_itemhoverbg' ) );
    $mobile_i_fs     = esc_attr( ot_get_option( 'nt_landium_mobile_itemfontsize' ) );
    $mobile_i_ta     = esc_attr( ot_get_option( 'nt_landium_mobile_itemtextalign' ) );
    $mobile_i_fw     = esc_attr( ot_get_option( 'nt_landium_mobile_itemfontweight' ) );
    $mobile_di_fs     = esc_attr( ot_get_option( 'nt_landium_mobile_dropitemfontsize' ) );
    $mobile_menubtn  = esc_attr( ot_get_option( 'nt_landium_mobile_menubtn' ) );
	$mobile_i_pad 	 = ( ot_get_option( 'nt_landium_mobile_itempadding', array() ) );
	$mobile_i_mar 	 = ( ot_get_option( 'nt_landium_mobile_itemmargin', array() ) );
	$mobile_i_brd 	 = ( ot_get_option( 'nt_landium_mobile_itemborder', array() ) );
	$theCSS .= '@media (max-width: 991px){';
		if ( $mobile_bg !='' ) { $theCSS .= '#top-bar, .dropdown-menu{background-color:'.$mobile_bg.'!important;}';}
		if ( $mobile_item !='' ) { $theCSS .= '#top-bar__navigation li a{color:'.$mobile_item.'!important;}';}
		if ( $mobile_i_ta  !='' ) { $theCSS .= '#top-bar__navigation ul li a{text-align:'.$mobile_i_ta .';}';}
		if ( $mobile_i_fs  !='' ) { $theCSS .= '#top-bar__navigation ul:not(.dropdown-menu) li a{font-size:'.$mobile_i_fs .'!important;}';}
		if ( $mobile_di_fs  !='' ) { $theCSS .= '#top-bar__navigation ul.dropdown-menu li a{font-size:'.$mobile_di_fs .'!important;}';}
		if ( $mobile_i_fw  !='' ) { $theCSS .= '#top-bar__navigation ul li a{font-weight:'.$mobile_i_fw .'!important;}';}
		if ( $mobile_i_h !='' )  { $theCSS .= '#top-bar__navigation li.active a, #top-bar__navigation li a:hover{color:'.$mobile_i_h.'!important;}';}
		if ( $mobile_i_hbg !='' ){ $theCSS .= '#top-bar__navigation li a:hover{background-color:'.$mobile_i_hbg.' !important;}';}
		if ( $mobile_menubtn !='' ) { $theCSS .= '#top-bar__navigation-toggler span, #top-bar__navigation-toggler span:before, #top-bar__navigation-toggler span:after{background-color:'.$mobile_menubtn.';}';}

		if ( !empty($mobile_i_pad) ) {
			$theCSS .= '#top-bar__navigation ul:not(.dropdown-menu) li a{';
			if(!empty($mobile_i_pad['unit']))   { $mobpadunit = $mobile_i_pad['unit'];}else{ $mobpadunit = 'px'; }
			if(!empty($mobile_i_pad['top']))    { $theCSS .= 'padding-top:'.$mobile_i_pad['top'].''.$mobpadunit.' !important;'; }
			if(!empty($mobile_i_pad['bottom'])) { $theCSS .= 'padding-bottom:'.$mobile_i_pad['bottom'].''.$mobpadunit.' !important;'; }
			if(!empty($mobile_i_pad['right']))  { $theCSS .= 'padding-right:'.$mobile_i_pad['right'].''.$mobpadunit.' !important;'; }
			if(!empty($mobile_i_pad['left']))   { $theCSS .= 'padding-left:'.$mobile_i_pad['left'].''.$mobpadunit.' !important;'; }
			$theCSS .= '}';
		}
		if ( !empty($mobile_i_mar) ) {
			$theCSS .= '#top-bar__navigation ul:not(.dropdown-menu) li a{';
			if(!empty($mobile_i_mar['unit']))   { $mobmarunit = $mobile_i_mar['unit'];}else{ $mobmarunit = 'px'; }
			if(!empty($mobile_i_mar['top']))    { $theCSS .= 'margin-top:'.$mobile_i_mar['top'].''.$mobmarunit.' !important;'; }
			if(!empty($mobile_i_mar['bottom'])) { $theCSS .= 'margin-bottom:'.$mobile_i_mar['bottom'].''.$mobmarunit.' !important;'; }
			if(!empty($mobile_i_mar['right']))  { $theCSS .= 'margin-right:'.$mobile_i_mar['right'].''.$mobmarunit.' !important;'; }
			if(!empty($mobile_i_mar['left']))   { $theCSS .= 'margin-left:'.$mobile_i_mar['left'].''.$mobmarunit.' !important;'; }
			$theCSS .= '}';
		}
		if ( !empty($mobile_i_brd) ) {
			$theCSS .= '#top-bar__navigation ul:not(.dropdown-menu) li a{';
			if(!empty($mobile_i_brd['unit']))   { $mobbrdunit = $mobile_i_brd['unit'];}else{ $mobbrdunit = 'px'; }
			if(!empty($mobile_i_brd['width']))  { $theCSS .= 'border-width:'.$mobile_i_brd['width'].''.$mobbrdunit.';'; }
			if(!empty($mobile_i_brd['style']))  { $theCSS .= 'border-style:'.$mobile_i_brd['style'].';'; }
			if(!empty($mobile_i_brd['color']))  { $theCSS .= 'border-color:'.$mobile_i_brd['color'].';'; }
			$theCSS .= '}';
		}
	$theCSS .= '}';

	// sidebar
    $sb_bg		= esc_attr( ot_get_option( 'nt_landium_sb_bg' ) );
    $sb_t_c		= esc_attr( ot_get_option( 'nt_landium_sb_t_c' ) );
    $sb_c		= esc_attr( ot_get_option( 'nt_landium_sb_c' ) );
    $sb_l_c		= esc_attr( ot_get_option( 'nt_landium_sb_l_c' ) );
    $sb_l_c_h	= esc_attr( ot_get_option( 'nt_landium_sb_l_c_h' ) );
    $sb_s_t		= esc_attr( ot_get_option( 'nt_landium_sb_s_t' ) );
    $sb_s_bg	= esc_attr( ot_get_option( 'nt_landium_sb_s_bg' ) );

	if ( $sb_bg !='' ) 		{ $theCSS .= '#widget-area{background-color:'.$sb_bg.'!important;padding-top: 15px;padding-bottom: 15px;}'; }
	if ( $sb_t_c !='' ) 	{ $theCSS .= '#widget-area .widget-title{color:'.$sb_t_c.'!important;}'; }
	if ( $sb_c !='' ) 		{ $theCSS .= '#widget-area .widget ul{color:'.$sb_c .'!important;}'; }
	if ( $sb_l_c !='' ) 	{ $theCSS .= '#widget-area .widget ul li a{color:'.$sb_l_c.'!important;}'; }
	if ( $sb_l_c_h !='' ) 	{ $theCSS .= '#widget-area .widget ul li a:hover{color:'.$sb_l_c_h.'!important;}'; }
	if ( $sb_s_t !='' ) 	{ $theCSS .= '#widget-area #searchform input#searchsubmit{color:'.$sb_s_t.'!important;}'; }
	if ( $sb_s_bg !='' ) 	{ $theCSS .= '#widget-area #searchform input#searchsubmit{background-color:'.$sb_s_bg.'!important;}'; }

	$sb_w_bg 		= ot_get_option( 'nt_landium_sb_w_bg', array() );
	$sb_w_overlay	= esc_attr( ot_get_option( 'nt_landium_sb_w_overlay' ) );
	if ( !empty($sb_w_bg) ) {
		$theCSS .= '#widget-area .widget{';
		if(!empty($sb_w_bg['background-color'])) 	{ $theCSS .= 'background-color:'.$sb_w_bg['background-color'].' !important;'; }
		if(!empty($sb_w_bg['background-image'])) 	{ $theCSS .= 'background-image:url("'.$sb_w_bg['background-image'].'") !important;'; }
		if(!empty($sb_w_bg['background-repeat'])) 	{ $theCSS .= 'background-repeat:'.$sb_w_bg['background-repeat'].' !important;'; }
		if(!empty($sb_w_bg['background-position'])) { $theCSS .= 'background-position:'.$sb_w_bg['background-position'].' !important;'; }
		if(!empty($sb_w_bg['background-attachment'])){ $theCSS .= 'background-attachment:'.$sb_w_bg['background-attachment'].' !important;'; }
		if(!empty($sb_w_bg['background-size'])) 	{ $theCSS .= 'background-size:'.$sb_w_bg['background-size'].' !important;'; }
		$theCSS .= '}';
		if ( $sb_w_overlay !='' ) 	{ $theCSS .= '#widget-area .widget:before{content:"";position:absolute;width:100%;height:100%;left:0;top:0;background-color:'.$sb_w_overlay.'!important;}#widget-area .widget, #widget-area .widget ul, #widget-area .widget .textwidget{position:relative;}'; }
	}
	$sb_brd			= ( ot_get_option( 'nt_landium_sb_border', array() ) );
    $sb_brd_radius	= esc_attr( ot_get_option( 'nt_landium_sb_borderradius' ) );
	if ( !empty($sb_brd) ) {
		$theCSS .= '#widget-area{';
		if(!empty($sb_brd['unit']))   { $sbbrdunit = $sb_brd['unit'];}else{ $sbbrdunit = 'px'; }
		if(!empty($sb_brd['width']))  { $theCSS .= 'border-width:'.$sb_brd['width'].''.$sbbrdunit.';'; }
		if(!empty($sb_brd['style']))  { $theCSS .= 'border-style:'.$sb_brd['style'].';'; }
		if(!empty($sb_brd['color']))  { $theCSS .= 'border-color:'.$sb_brd['color'].';'; }
		if( $sb_brd_radius !='' ) 	  { $theCSS .= 'border-radius:'.$sb_brd_radius.'px;'; }
		$theCSS .= 'padding-bottom: 15px;';
		$theCSS .= '}';
	}
	// sidebar widget
	$sb_w_mar 		= ot_get_option( 'nt_landium_sb_w_margin', array() );
	if ( !empty($sb_w_mar) ) {
		$theCSS .= '#widget-area .widget{';
		if(!empty($sb_w_mar['unit']))   { $widgetmarunit = $sb_w_mar['unit'];}else{ $widgetmarunit = 'px'; }
		if(!empty($sb_w_mar['top']))    { $theCSS .= 'margin-top:'.$sb_w_mar['top'].''.$widgetmarunit.' !important;'; }
		if(!empty($sb_w_mar['bottom'])) { $theCSS .= 'margin-bottom:'.$sb_w_mar['bottom'].''.$widgetmarunit.' !important;'; }
		if(!empty($sb_w_mar['right']))  { $theCSS .= 'margin-right:'.$sb_w_mar['right'].''.$widgetmarunit.' !important;'; }
		if(!empty($sb_w_mar['left']))   { $theCSS .= 'margin-left:'.$sb_w_mar['left'].''.$widgetmarunit.' !important;'; }
		$theCSS .= '}';
	}
	$sb_w_pad 		= ot_get_option( 'nt_landium_sb_w_padding', array() );
	if ( !empty($sb_w_pad) ) {
		$theCSS .= '#widget-area .widget{';
		if(!empty($sb_w_pad['unit']))   { $widgetpadunit = $sb_w_pad['unit'];}else{ $widgetpadunit = 'px'; }
		if(!empty($sb_w_pad['top']))    { $theCSS .= 'padding-top:'.$sb_w_pad['top'].''.$widgetpadunit.' !important;'; }
		if(!empty($sb_w_pad['bottom'])) { $theCSS .= 'padding-bottom:'.$sb_w_pad['bottom'].''.$widgetpadunit.' !important;'; }
		if(!empty($sb_w_pad['right']))  { $theCSS .= 'padding-right:'.$sb_w_pad['right'].''.$widgetpadunit.' !important;'; }
		if(!empty($sb_w_pad['left']))   { $theCSS .= 'padding-left:'.$sb_w_pad['left'].''.$widgetpadunit.' !important;'; }
		$theCSS .= '}';
	}
	$sb_w_brd			= ( ot_get_option( 'nt_landium_sb_w_border', array() ) );
    $sb_w_brd_radius	= esc_attr( ot_get_option( 'nt_landium_sb_w_borderradius' ) );
	if ( !empty($sb_w_brd) ) {
		$theCSS .= '#widget-area .widget{';
		if(!empty($sb_w_brd['unit']))   { $widgetbrdunit = $sb_w_brd['unit'];}else{ $widgetbrdunit = 'px'; }
		if(!empty($sb_w_brd['width']))  { $theCSS .= 'border-width:'.$sb_w_brd['width'].''.$widgetbrdunit.';'; }
		if(!empty($sb_w_brd['style']))  { $theCSS .= 'border-style:'.$sb_w_brd['style'].';'; }
		if(!empty($sb_w_brd['color']))  { $theCSS .= 'border-color:'.$sb_w_brd['color'].';'; }
		if( $sb_w_brd_radius !='' ) 	{ $theCSS .= 'border-radius:'.$sb_w_brd_radius.'px;'; }
		$theCSS .= '}';
	}
	$widgeticon = 2;
	$nt_landium_widget_icon 		= ot_get_option('nt_landium_wt_before' );
	$nt_landium_widgeticon_color	= ot_get_option('nt_landium_widgeticon_color' );
	if (!empty( $nt_landium_widget_icon )) {
		$theCSS .= '#widget-area .widget-title{padding-left: 0px;}';
		$theCSS .= '.widget-title:before{position:relative;font-family:FontAwesome;margin-right:10px;}.widget-title:after{content:none!important;}';
		if ( $nt_landium_menuicon_color !='' ) { $theCSS .= '.widget-title:before {color:'.$nt_landium_widgeticon_color.';}'; }
		foreach($nt_landium_widget_icon as $key => $wicon) {
			$theCSS .= '#widget-area .widget:nth-child('.$widgeticon.') .widget-title:before{content:"\\'.esc_html($wicon['nt_landium_sb_wt_icon']).'";}';
			$widgeticon++;
		}
	}



	// logo dimension
	$theme_logo_type		= ( ot_get_option( 'nt_landium_logo_type' ) );
	$logo 					= ( ot_get_option( 'nt_landium_logo_dimension', array() ) );
	$logo_m 				= ( ot_get_option( 'nt_landium_margin_logo', array() ) );
	$logo_p 				= ( ot_get_option( 'nt_landium_padding_logo', array() ) );

	// logo
	if(isset($logo['unit']))   { $logounit = $logo['unit'];}else{ $logounit = 'px'; }
	if(isset($logo['width']))   { $theCSS .= '#top-bar__logo img{ width:' .  $logo['width'] .''. $logounit . ' !important; }'; }
	if(isset($logo['height']))  { $theCSS .= '#top-bar__logo img{ height:' . $logo['height'] .''. $logounit . ' !important; }'; }

	//logo  margin
	if(isset($logo_m['unit']))   { $logomarunit = $logo_m['unit'];}else{ $logomarunit = 'px'; }
	if(isset($logo_m['top']))    { $theCSS .= '#top-bar__logo img{ margin-top:' .  $logo_m['top'] .''. $logomarunit . ' !important; }'; }
	if(isset($logo_m['bottom'])) { $theCSS .= '#top-bar__logo img{ margin-bottom:' . $logo_m['bottom'] .''. $logomarunit . ' !important; }'; }
	if(isset($logo_m['right']))  { $theCSS .= '#top-bar__logo img{ margin-right:' . $logo_m['right'] .''. $logomarunit . ' !important; }'; }
	if(isset($logo_m['left']))   { $theCSS .= '#top-bar__logo img{ margin-left:' . $logo_m['left'] .''. $logomarunit . ' !important; }'; }

	//logo padding
	if(isset($logo_p['unit']))   { $logopadunit = $logo_p['unit'];}else{ $logopadunit = 'px'; }
	if(isset($logo_p['top']))    { $theCSS .= '#top-bar__logo img{ padding-top:' .  $logo_p['top'] .''. $logopadunit . ' !important; }'; }
	if(isset($logo_p['bottom'])) { $theCSS .= '#top-bar__logo img{ padding-bottom:' . $logo_p['bottom'] .''. $logopadunit . ' !important; }'; }
	if(isset($logo_p['right']))  { $theCSS .= '#top-bar__logo img{ padding-right:' . $logo_p['right'] .''. $logopadunit . ' !important; }'; }
	if(isset($logo_p['left']))   { $theCSS .= '#top-bar__logo img{ padding-left:' . $logo_p['left'] .''. $logopadunit . ' !important; }'; }

	// default logo
    if ( ot_get_option( 'nt_landium_logoimg' ) =='' ) {
		$theCSS .= '#top-bar__logo {
			width: 141px;
			height: 27px;
			overflow: hidden;
			text-indent: 100%;
			white-space: nowrap;
			background: url('. get_template_directory_uri() . '/images/site_logo.png' .');
		}';
	}

	if ( $theme_logo_type == 'text' ){

		//variable for text logo custom style
		$textlogo_fs 			= esc_attr( ot_get_option( 'nt_landium_textlogo_fs' ) );
		$textlogo_fw 			= esc_attr( ot_get_option( 'nt_landium_textlogo_fw' ) );
		$textlogo_fstyle		= esc_attr( ot_get_option( 'nt_landium_textlogo_fstyle' ) );
		$textlogo_ltsp			= esc_attr( ot_get_option( 'nt_landium_textlogo_lettersp' ) );
		$textlogo_h_color		= esc_attr( ot_get_option( 'nt_landium_textlogo_hovercolor' ) );
		$staticlogo_color		= esc_attr( ot_get_option( 'nt_landium_staticlogo_color' ) );
		$stickylogo_color		= esc_attr( ot_get_option( 'nt_landium_stickylogo_color' ) );

		//static menu text logo
		$theCSS .= '#top-bar__logo, #top-bar__logo_text {line-height: 1.1; text-decoration:none;';
		if ( $textlogo_fw 		!= '' ){ $theCSS .= 'font-weight:'.$textlogo_fw.';'; }
		if ( $textlogo_ltsp 	!= '' ){ $theCSS .= 'letter-spacing:'.$textlogo_ltsp.'px;';}
		if ( $textlogo_fs 		!= '' ){ $theCSS .= 'font-size:'.$textlogo_fs.'px;';}
		if ( $textlogo_fstyle 	!= '' ){ $theCSS .= 'font-style:'.$textlogo_fstyle.';';}
		$theCSS .= '}';
		if ( $staticlogo_color 	!= '' ){ $theCSS .= '#top-bar__logo_text, #top-bar__logo {color:'.$staticlogo_color.'!important;}';}
		if ( $textlogo_h_color 	!= '' ){ $theCSS .= '#top-bar__logo_text:hover, #top-bar__logo:hover {color:'.$textlogo_h_color.'!important;}';}

		//sticky menu text logo
		$theCSS .= '#top-bar__logo, #top-bar__logo_text {line-height: 1.1; text-decoration:none; ';
		if ( $textlogo_fw 		!= '' ){ $theCSS .= 'font-weight:'.$textlogo_fw.';'; }
		if ( $textlogo_ltsp 	!= '' ){ $theCSS .= 'letter-spacing:'.$textlogo_ltsp.'px;';}
		if ( $textlogo_fs 		!= '' ){ $theCSS .= 'font-size:'.$textlogo_fs.'px;';}
		if ( $textlogo_fstyle 	!= '' ){ $theCSS .= 'font-style:'.$textlogo_fstyle.';';}
		$theCSS .= '}';
		if ( $stickylogo_color 	!= '' ){ $theCSS .= '.fixed.in #top-bar__logo_text, .fixed.in #top-bar__logo{color:'.$stickylogo_color.'!important;}';}
		if ( $textlogo_h_color 	!= '' ){ $theCSS .= '.fixed.in #top-bar__logo_text:hover, .fixed.in #top-bar__logo:hover {color:'.$textlogo_h_color.'!important;}';}
	}

	// ALL PAGE OVERLAY MASK COLOR
	$single_mask_v 	= esc_attr( ot_get_option( 'nt_landium_single_mask_v' ) );
	$single_mask_c 	= esc_attr( ot_get_option( 'nt_landium_single_mask_c' ) );
	$archive_mask_v = esc_attr( ot_get_option( 'nt_landium_archive_mask_v' ) );
	$archive_mask_c = esc_attr( ot_get_option( 'nt_landium_archive_mask_c' ) );
	$error_mask_v 	= esc_attr( ot_get_option( 'nt_landium_error_mask_v' ) );
	$error_mask_c 	= esc_attr( ot_get_option( 'nt_landium_error_mask_c' ) );
	$search_mask_v 	= esc_attr( ot_get_option( 'nt_landium_search_mask_v' ) );
	$search_mask_c 	= esc_attr( ot_get_option( 'nt_landium_search_mask_c' ) );


	//blog hero
	$blog_h_bg 		= esc_attr( ot_get_option( 'nt_landium_blog_h_bg' ) );
	$blogheaderbgcolor 		= esc_attr( ot_get_option( 'nt_landium_blogheaderbgcolor' ) );
	$blog_mask_v 	= esc_attr( ot_get_option( 'nt_landium_blog_mask_v' ) );
	$blog_mask_c 	= esc_attr( ot_get_option( 'nt_landium_blog_mask_c' ) );
	$blog_h_h 		= esc_attr( ot_get_option( 'nt_landium_blog_h_h' ) );
	$blog_h_p 		= ( ot_get_option( 'nt_landium_blog_h_p', array() ) );


    	if ( $blog_h_bg !='' ) 	{
    		$theCSS .= '.index-header {background: transparent url( ' . $blog_h_bg .')no-repeat fixed center top / cover!important; }';
    	} elseif( $blogheaderbgcolor =='' ) {
    		$theCSS .= '.index-header{ background-image: url('. get_template_directory_uri() . '/images/1.jpg'.');}';
    	}

	if ( $blogheaderbgcolor !='' ) 	{
		$theCSS .= '.index-header {background-color:' . $blogheaderbgcolor .' !important; }';
	}
	if ( $blog_mask_v =='off' ){
		$theCSS .= '.blog .index-header .template-overlay{display: none !important; }';
	}

	if (( $blog_mask_c !='' ) && ( $blog_mask_v !='off' )){
		$theCSS .= '.blog .index-header .template-overlay{background: '.$blog_mask_c.';!important; }';
	}
	if ( $blog_h_h !='' ) {  $theCSS .= '.blog .index-header {height: ' . $blog_h_h .'vh !important;     max-height: 100%; }'; }

	if(!empty($blog_h_p['top']))    { $theCSS .= '.blog .index-header { padding-top:'.$blog_h_p['top'].''.$blog_h_p['unit'].' !important; }'; }
	if(!empty($blog_h_p['bottom'])) { $theCSS .= '.blog .index-header { padding-bottom:'.$blog_h_p['bottom'].''.$blog_h_p['unit'].' !important; }'; }
	if(!empty($blog_h_p['right']))  { $theCSS .= '.blog .index-header { padding-right:'.$blog_h_p['right'].''.$blog_h_p['unit'].' !important; }'; }
	if(!empty($blog_h_p['left']))   { $theCSS .= '.blog .index-header { padding-left:'.$blog_h_p['left'].''.$blog_h_p['unit'].' !important; }'; }

	//blog heading
	$blog_textalign = 	ot_get_option( 'nt_landium_blog_textalign' );
	$blog_content_textalign = 	ot_get_option( 'nt_landium_blog_content_textalign' );
	$blog_h_c 		= esc_attr( ot_get_option( 'nt_landium_blog_h_c' ) );
	$blog_h_fs		= esc_attr( ot_get_option( 'nt_landium_blog_heading_fontsize' ) );
	$blog_h_mar		= ( ot_get_option( 'nt_landium_blog_heading_margin', array() ) );

	if ( $blog_textalign !='' ) 	{ $theCSS .= '.blog .index-header .template-cover-text *{text-align: '.$blog_textalign.' !important; }'; }
    if ( $blog_content_textalign !='' ) 	{
        $theCSS .= '.blog article .entry-content{text-align: '.$blog_content_textalign.' !important;}
        .blog .article-img img {margin-left: auto;margin-right: auto;display: block;}';
    }
	if ( $blog_h_c !='' ) 	{ $theCSS .= '.blog .index-header .template-cover-text .uppercase{color: '.$blog_h_c.' !important; }'; }
	if ( $blog_h_fs !='' ) 	{ $theCSS .= '.blog .index-header .template-cover-text .uppercase{font-size: '.$blog_h_fs.'px; }'; }
	if ( !empty($blog_h_mar) ) {
		$theCSS .= '.blog .index-header .template-cover-text .uppercase{';
		if(!empty($blog_h_mar['unit']))   { $footermarunit = $blog_h_mar['unit'];}else{ $footermarunit = 'px'; }
		if(!empty($blog_h_mar['top']))    { $theCSS .= 'margin-top:'.$blog_h_mar['top'].''.$footermarunit.' !important;'; }
		if(!empty($blog_h_mar['bottom'])) { $theCSS .= 'margin-bottom:'.$blog_h_mar['bottom'].''.$footermarunit.' !important;'; }
		if(!empty($blog_h_mar['right']))  { $theCSS .= 'margin-right:'.$blog_h_mar['right'].''.$footermarunit.' !important;'; }
		if(!empty($blog_h_mar['left']))   { $theCSS .= 'margin-left:'.$blog_h_mar['left'].''.$footermarunit.' !important;'; }
		$theCSS .= '}';
	}
	// blog slogan
	$blog_s_c 	= esc_attr( ot_get_option( 'nt_landium_blog_sub_h_c' ) );
	$blog_s_fs	= esc_attr( ot_get_option( 'nt_landium_blog_slogan_fontsize' ) );
	$blog_s_mar	= ( ot_get_option( 'nt_landium_blog_slogan_margin', array() ) );

	if ( $blog_s_c !='' ) 	{ $theCSS .= '.blog .index-header .template-cover-text .cover-text-sublead{color: '.$blog_s_c.' !important; }'; }
	if ( $blog_s_fs !='' ) 	{ $theCSS .= '.blog .index-header .template-cover-text .cover-text-sublead{font-size: '.$blog_s_fs.'px; }'; }
	if ( !empty($blog_s_mar) ) {
		$theCSS .= '.blog .index-header .template-cover-text .cover-text-sublead{';
		if(!empty($blog_s_mar['unit']))   { $footermarunit = $blog_s_mar['unit'];}else{ $footermarunit = 'px'; }
		if(!empty($blog_s_mar['top']))    { $theCSS .= 'margin-top:'.$blog_s_mar['top'].''.$footermarunit.' !important;'; }
		if(!empty($blog_s_mar['bottom'])) { $theCSS .= 'margin-bottom:'.$blog_s_mar['bottom'].''.$footermarunit.' !important;'; }
		if(!empty($blog_s_mar['right']))  { $theCSS .= 'margin-right:'.$blog_s_mar['right'].''.$footermarunit.' !important;'; }
		if(!empty($blog_s_mar['left']))   { $theCSS .= 'margin-left:'.$blog_s_mar['left'].''.$footermarunit.' !important;'; }
		$theCSS .= '}';
	}


	// PAGE.PHP AND FULLWIDTH-PAGE.PHP HEADER - CUSTOM PAGE METABOX OPTIONS
	//page bg image and overlay
	$nt_landium_page_bg 			= 	wp_get_attachment_url( get_post_meta(get_the_ID(), 'nt_landium_page_bg_image', true ),'full' );
	$nt_landium_disable_bgimg 		= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_disable_bgimg', true ) );
	$nt_landium_page_bg_color 		= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_pagebgcolor', true ) );
	$nt_landium_disable_page_mask 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_disable_page_mask', true ) );
	$nt_landium_page_mask_color 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_page_mask_color', true ) );
	$nt_landium_page_mask_opacity 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_page_mask_opacity', true ) );
	//page heading
	$nt_landium_page_text_color 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_pagetitlecolor', true ) );
	$nt_landium_pagetitlefontsize 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_pagetitlefontsize', true ) );
	$nt_landium_page_subtitle_color = 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_pagesubtitlecolor', true ) );
	$nt_landium_pagesubtitlefontsize= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_pagesubtitlefontsize', true ) );
	$nt_landium_header_p_top 		= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_headerptop', true ) );
	$nt_landium_header_p_bottom 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_headerpbottom', true ) );
	$nt_landium_headerheight 	    = 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_headerheight', true ) );
	$nt_landium_headerminheight 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_headerminheight', true ) );
	$nt_landium_headermaxheight 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_headermaxheight', true ) );
	$nt_landium_page_textalign 	    = 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_page_textalign', true ) );

	$page_mask_color = $nt_landium_page_mask_color;
	$mask_rgb_color = hex2rgb($page_mask_color);
	$final_page_mask_color = implode(", ", $mask_rgb_color);

	if ( $nt_landium_page_bg !='' ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header { background-image: url('.esc_url( $nt_landium_page_bg ).') !important; }';
	}
	if ( $nt_landium_page_bg_color !='' && $nt_landium_page_bg =='' ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header { background-image: none !important; }';
	}
	if ( $nt_landium_headerheight !='' ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header {
            height: '.$nt_landium_headerheight.'vh !important;
            min-height: '.$nt_landium_headerminheight.'px !important;
            max-height: '.$nt_landium_headermaxheight.'px !important;
        }';
	}
	if ( $nt_landium_disable_bgimg == true ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header { background-image: none!important; }';
	}
	if ( $nt_landium_disable_page_mask == true ){
		$theCSS .= '.page-id-'.get_the_ID().'.index-header .template-overlay .template-overlay{ display: none !important; }';
	}
	if ( ( $nt_landium_disable_page_mask != true ) && ( $nt_landium_page_mask_color != '' ) ){
		$theCSS .= '.page-id-'.get_the_ID().'.index-header .template-overlay{background: rgba('.$final_page_mask_color.', '.$nt_landium_page_mask_opacity.') !important; }';
	}
	if ( $nt_landium_page_bg_color !='' ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header { background-color: ' .$nt_landium_page_bg_color.' !important; }';
	}
	if ( $nt_landium_page_text_color !='' ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header h2.lead-heading { color: '.$nt_landium_page_text_color.' !important; }';
	}
	if ( $nt_landium_page_textalign !='' ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header .template-cover-text{ text-align: '.$nt_landium_page_textalign.' !important; }';
	}
	if ( $nt_landium_pagetitlefontsize !='' ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header h2.lead-heading { font-size: '.$nt_landium_pagetitlefontsize.'px!important; }';
	}
	if ( $nt_landium_page_subtitle_color !='' ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header h2.cover-text-sublead, .page-id-'.get_the_ID().'.index-header h2.cover-text-sublead p { color: '. $nt_landium_page_subtitle_color .' !important; }';
	}
	if ( $nt_landium_pagesubtitlefontsize !='' ) {
		$theCSS .= '.page-id-'.get_the_ID().'.index-header h2.cover-text-sublead, .page-id-'.get_the_ID().'.index-header h2.cover-text-sublead p { font-size: '. $nt_landium_pagesubtitlefontsize .'px !important; }';
	}
	if ( $nt_landium_header_p_top !='' ) {
		$theCSS .= '.page-id-' . get_the_ID().'.index-header { padding-top : '.$nt_landium_header_p_top.'px !important; }';
	}
	if ( $nt_landium_header_p_bottom !='' ) {
		$theCSS .= '.page-id-' . get_the_ID().'.index-header { padding-bottom : '.$nt_landium_header_p_bottom.'px !important; }';
	}

	// page responsive 992px
	$nt_landium_page_bg_img992 		= 	wp_get_attachment_url( get_post_meta(get_the_ID(), 'nt_landium_page_bg_image992', true ),'full' );
	$nt_landium_disable_bg992 		= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_disable_bg992', true ) );
	$nt_landium_page_hero_height992 = 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_page_hero_height992', true ) );
	$nt_landium_page_title_fs992 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_page_title_fs992', true ) );
	$nt_landium_header_992_p_top 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_header_992_p_top', true ) );
	$nt_landium_header_992_p_bottom = 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_header_992_p_bottom', true ) );
	$nt_landium_page_textalign_992 = 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_page_textalign_992', true ) );

	if ( $nt_landium_page_bg_img992 !='' || $nt_landium_disable_bg992 !='' || $nt_landium_page_hero_height992 !='' || $nt_landium_page_title_fs992 !='' ){
		$theCSS .= '@media ( max-width: 992px ){';
			if ( ( $nt_landium_page_bg_img992 !='' ) && ( $nt_landium_page_bg_parallax == true ) ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header {background: transparent url('.esc_url($nt_landium_page_bg_img992).')no-repeat fixed center top / cover!important; }';
			}else {
				if ( $nt_landium_page_bg_img992 !='' ) {
					$theCSS .= '.page-id-' . get_the_ID().'.index-header {background-image: url('.esc_url($nt_landium_page_bg_img992).')!important; }';
				}
			}
			if ( $nt_landium_disable_bg992 == true ) {
				$theCSS .= '.page-id-'.get_the_ID().'.index-header { background-image: none!important; }';
			}
			if ( $nt_landium_page_textalign_992 !='' ) {
				$theCSS .= '.page-id-'.get_the_ID().'.index-header .template-cover-text{ text-align: '.$nt_landium_page_textalign_992.' !important; }';
			}
			if ( $nt_landium_page_hero_height992 !='' ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header { height: '.$nt_landium_page_hero_height992.'vh !important; max-height: 100%; min-height: auto; }';
			}
			if ( $nt_landium_page_title_fs992 !='' ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header h2.lead-heading { font-size: '.$nt_landium_page_title_fs992.'px !important; }';
			}
			if ( $nt_landium_header_992_p_top !='' ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header { padding-top : '.$nt_landium_header_992_p_top.'px !important; }';
			}
			if ( $nt_landium_header_992_p_bottom !='' ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header { padding-bottom : '.$nt_landium_header_992_p_bottom.'px !important; }';
			}
		$theCSS .= '}';
	}

	// page responsive 768px
	$nt_landium_page_bg_img768 		= 	wp_get_attachment_url( get_post_meta(get_the_ID(), 'nt_landium_page_bg_image768', true ),'full' );
	$nt_landium_disable_bg768 		= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_disable_bg768', true ) );
	$nt_landium_page_hero_height768 = 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_page_hero_height768', true ) );
	$nt_landium_page_title_fs768 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_page_title_fs768', true ) );
	$nt_landium_header_768_p_top 	= 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_header_768_p_top', true ) );
	$nt_landium_header_768_p_bottom = 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_header_768_p_bottom', true ) );
	$nt_landium_page_textalign_768 = 	esc_attr( get_post_meta(get_the_ID(), 'nt_landium_page_textalign_768', true ) );

	if ( $nt_landium_page_bg_img768 !='' || $nt_landium_disable_bg768 !='' || $nt_landium_page_hero_height768 !='' || $nt_landium_page_title_fs768 !='' ){
		$theCSS .= '@media ( max-width: 768px ){';
			if ( ( $nt_landium_page_bg_img768 !='' ) && ( $nt_landium_page_bg_parallax == true ) ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header {background: transparent url('.esc_url($nt_landium_page_bg_img768).')no-repeat fixed center top / cover!important; }';
			}else {
				if ( $nt_landium_page_bg_img768 !='' ) {
					$theCSS .= '.page-id-' . get_the_ID().'.index-header {background-image: url('.esc_url($nt_landium_page_bg_img768).')!important; }';
				}
			}
			if ( $nt_landium_disable_bg768 == true ) {
				$theCSS .= '.page-id-'.get_the_ID().'.index-header { background-image: none!important; }';
			}
			if ( $nt_landium_page_textalign_768 !='' ) {
				$theCSS .= '.page-id-'.get_the_ID().'.index-header .template-cover-text{ text-align: '.$nt_landium_page_textalign_768.' !important; }';
			}
			if ( $nt_landium_page_hero_height768 !='' ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header { height: '.$nt_landium_page_hero_height768.'vh !important; max-height: 100%;min-height: auto; }';
			}
			if ( $nt_landium_page_title_fs768 !='' ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header h2.lead-heading { font-size: '.$nt_landium_page_title_fs768.'px !important; }';
			}
			if ( $nt_landium_header_768_p_top !='' ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header { padding-top : '.$nt_landium_header_768_p_top.'px !important; }';
			}
			if ( $nt_landium_header_768_p_bottom !='' ) {
				$theCSS .= '.page-id-' . get_the_ID().'.index-header { padding-bottom : '.$nt_landium_header_768_p_bottom.'px !important; }';
			}
		$theCSS .= '}';
	}

	// single post
	if ( ot_get_option( 'nt_landium_singlepageheadbg' ) !='' ){
    $theCSS .= '.single .index-header {background: transparent url( '.esc_attr( ot_get_option( 'nt_landium_singlepageheadbg' ) ) .')no-repeat fixed center top / cover!important; }';
    }
	if ( ot_get_option( 'nt_landium_singleheaderbgcolor' ) !='' ){
    $theCSS .= '.single .index-header {background-color: '.esc_attr( ot_get_option( 'nt_landium_singleheaderbgcolor' ) ).'; }';
    }
	if ( ot_get_option( 'nt_landium_singleheadingcolor' ) !='' ){
    $theCSS .= '.single .index-header .uppercase{color: '.esc_attr( ot_get_option( 'nt_landium_singleheadingcolor' ) ).'; }';
    }
	if ( ot_get_option( 'nt_landium_single_heading_fontsize' ) !='' ){
    $theCSS .= '.single .index-header .uppercase{font-size: '.esc_attr( ot_get_option( 'nt_landium_single_heading_fontsize' ) ).'px; }';
    }
	if ( ot_get_option( 'nt_landium_single_textalign' ) !='' ){
    $theCSS .= '.single .index-header .template-cover-text *{text-align: '.esc_attr( ot_get_option( 'nt_landium_single_textalign' ) ).'; }';
    }
	if ( ot_get_option( 'nt_landium_single_content_textalign' ) !='' ){
    $theCSS .= '.single article, .single .container-for-comments h3, .single .logged-in-as {text-align: '.esc_attr( ot_get_option( 'nt_landium_single_content_textalign' ) ).';}.single .article-img img {margin-left: auto;margin-right: auto;display: block;}';
    }
	if ( ot_get_option( 'nt_landium_singleheaderbgheight' ) !='' ){
    $theCSS .= '.single .index-header {height: '.esc_attr( ot_get_option( 'nt_landium_singleheaderbgheight' ) ).'vh !important; }';
    }
	if (( ot_get_option( 'nt_landium_singleheaderpaddingtop' ) !='' )||( ot_get_option( 'nt_landium_singleheaderpaddingbottom' ) !='' )){
		$theCSS .= '@media (min-width: 768px){
			.single .index-header  {
				padding-top: '.  esc_attr( ot_get_option( 'nt_landium_singleheaderpaddingtop' ) ) .'px !important;
				padding-bottom: '.  esc_attr( ot_get_option( 'nt_landium_singleheaderpaddingbottom' ) ) .'px !important;
			}
		}';
    }

	// archive pages
	if ( ot_get_option( 'nt_landium_archivepageheadbg' ) !='' ){
     $theCSS .= '.archive .index-header {background: transparent url( '.esc_attr( ot_get_option( 'nt_landium_archivepageheadbg' ) ).')no-repeat fixed center top / cover!important; }';
    }
	if ( ot_get_option( 'nt_landium_archiveheaderbgcolor' ) !='' ){
     $theCSS .= '.archive .index-header {background-color: '.esc_attr( ot_get_option( 'nt_landium_archiveheaderbgcolor' ) ).'; }';
    }
	if ( ot_get_option( 'nt_landium_archiveheadingcolor' ) !='' ){
     $theCSS .= '.archive .index-header .uppercase{color: '.esc_attr( ot_get_option( 'nt_landium_archiveheadingcolor' ) ).'; }';
	}
	if ( ot_get_option( 'nt_landium_archive_heading_fontsize' ) !='' ){
     $theCSS .= '.archive .index-header .uppercase{font-size: '.esc_attr( ot_get_option( 'nt_landium_archive_heading_fontsize' ) ).'px; }';
    }
	if ( ot_get_option( 'nt_landium_archiveheaderparagraphcolor' ) !='' ){
     $theCSS .= '.archive .index-header .cover-text-sublead{color: '.esc_attr( ot_get_option( 'nt_landium_archiveheaderparagraphcolor' ) ).'; }';
    }
	if ( ot_get_option( 'nt_landium_archiveheaderparagraphfontsize' ) !='' ){
     $theCSS .= '.archive .index-header .cover-text-sublead{font-size: '.esc_attr( ot_get_option( 'nt_landium_archiveheaderparagraphfontsize' ) ).'px; }';
    }
	if ( ot_get_option( 'nt_landium_archive_textalign' ) !='' ){
    $theCSS .= '.archive .index-header .template-cover-text *{text-align: '.esc_attr( ot_get_option( 'nt_landium_archive_textalign' ) ).'; }';
    }
	if ( ot_get_option( 'nt_landium_archive_content_textalign' ) !='' ){
    $theCSS .= '.archive article {text-align: '.esc_attr( ot_get_option( 'nt_landium_archive_content_textalign' ) ).';}.archive .article-img img {margin-left: auto;margin-right: auto;display: block;}';
    }
	if ( ot_get_option( 'nt_landium_archiveheaderbgheight' ) !='' ){
     $theCSS .= '.archive .index-header {height: '.esc_attr( ot_get_option( 'nt_landium_archiveheaderbgheight' ) ).'vh !important; }';
    }
	if (( ot_get_option( 'nt_landium_archiveheaderpaddingtop' ) !='' )||( ot_get_option( 'nt_landium_archiveheaderpaddingbottom' ) !='' )) {
		$theCSS .= '@media (min-width: 768px){
			.archive .index-header  {
				padding-top: '.  esc_attr( ot_get_option( 'nt_landium_archiveheaderpaddingtop' ) ) .'px !important;
				padding-bottom: '.  esc_attr( ot_get_option( 'nt_landium_archiveheaderpaddingbottom' ) ) .'px !important;
			}
		}';
	}

	// 404
	if  ( ot_get_option( 'nt_landium_errorpageheadbg' ) !='' ){
     $theCSS .= '.error404 .index-header {background: transparent url( '.esc_attr( ot_get_option( 'nt_landium_errorpageheadbg' ) ).')no-repeat fixed center top / cover!important; }';
    }
	if  ( ot_get_option( 'nt_landium_errorheaderbgcolor' ) !='' ){
     $theCSS .= '.error404 .index-header {background-color: '.esc_attr( ot_get_option( 'nt_landium_errorheaderbgcolor' ) ).'; }';
    }
	if  ( ot_get_option( 'nt_landium_errorheadingcolor' ) !='' ){
     $theCSS .= '.error404 .index-header .uppercase{color: '.esc_attr( ot_get_option( 'nt_landium_errorheadingcolor' ) ).'; }';
	}
	if  ( ot_get_option( 'nt_landium_error_heading_fontsize' ) !='' ){
     $theCSS .= '.error404 .index-header .uppercase{font-size: '.esc_attr( ot_get_option( 'nt_landium_error_heading_fontsize' ) ).'px; }';
    }
	if  ( ot_get_option( 'nt_landium_errorheaderparagraphcolor' ) !='' ){
     $theCSS .= '.error404 .index-header .cover-text-sublead{color: '.esc_attr( ot_get_option( 'nt_landium_errorheaderparagraphcolor' ) ).'; }';
    }
	if  ( ot_get_option( 'nt_landium_errorheaderparagraphfontsize' ) !='' ){
     $theCSS .= '.error404 .index-header .cover-text-sublead{font-size: '.esc_attr( ot_get_option( 'nt_landium_errorheaderparagraphfontsize' ) ).'px; }';
    }
	if ( ot_get_option( 'nt_landium_error_textalign' ) !='' ){
    $theCSS .= '.error404 .index-header .template-cover-text *{text-align: '.esc_attr( ot_get_option( 'nt_landium_error_textalign' ) ).'; }';
    }
	if ( ot_get_option( 'nt_landium_error_content_textalign' ) !='' ){
    $theCSS .= '.error404 article {text-align: '.esc_attr( ot_get_option( 'nt_landium_error_content_textalign' ) ).';}';
    }
	if ( ot_get_option( 'nt_landium_error_content_textalign' ) =='center' ){
    $theCSS .= 'body.error404 article .searchform {float:none}';
    }
	if  ( ot_get_option( 'nt_landium_errorheaderbgheight' ) !='' ){
     $theCSS .= '.error404 .index-header {height: '.  esc_attr( ot_get_option( 'nt_landium_errorheaderbgheight' ) ) .'vh !important; }';
    }
	if  (( ot_get_option( 'nt_landium_errorheaderpaddingtop' ) !='' )||( ot_get_option( 'nt_landium_errorheaderpaddingbottom' ) !='' )) {
		$theCSS .= '@media (min-width: 768px){
			.error404 .index-header  {
				padding-top: '.  esc_attr( ot_get_option( 'nt_landium_errorheaderpaddingtop' ) ) .'px !important;
				padding-bottom: '.  esc_attr( ot_get_option( 'nt_landium_errorheaderpaddingbottom' ) ) .'px !important;
			}
		}';
	}

	// search page
	if  ( ot_get_option( 'nt_landium_searchpageheadbg' ) !='' ){
     $theCSS .= '.search .index-header {background: transparent url( '.esc_attr( ot_get_option( 'nt_landium_searchpageheadbg' ) ).')no-repeat scroll center top / cover!important; }';
    }
	if  ( ot_get_option( 'nt_landium_searchheaderbgcolor' ) !='' ){
     $theCSS .= '.search .index-header {background-color: '.esc_attr( ot_get_option( 'nt_landium_searchheaderbgcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_searchheadingcolor' ) !='' ){
     $theCSS .= '.search .index-header .uppercase{color: '.esc_attr( ot_get_option( 'nt_landium_searchheadingcolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_search_heading_fontsize' ) !='' ){
     $theCSS .= '.search .index-header .uppercase{font-size: '.esc_attr( ot_get_option( 'nt_landium_search_heading_fontsize' ) ) .'px; }';
    }
	if  ( ot_get_option( 'nt_landium_searchheaderparagraphcolor' ) !='' ){
     $theCSS .= '.search .index-header .cover-text-sublead{color: '.esc_attr( ot_get_option( 'nt_landium_searchheaderparagraphcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_searchheaderparagraphfontsize' ) !='' ){
     $theCSS .= '.search .index-header .cover-text-sublead{font-size: '.esc_attr( ot_get_option( 'nt_landium_searchheaderparagraphfontsize' ) ).'px; }';
    }
	if ( ot_get_option( 'nt_landium_search_textalign' ) !='' ){
    $theCSS .= '.search .index-header .template-cover-text *{text-align: '.esc_attr( ot_get_option( 'nt_landium_search_textalign' ) ).'; }';
    }
	if ( ot_get_option( 'nt_landium_search_content_textalign' ) !='' ){
    $theCSS .= '.search article {text-align: '.esc_attr( ot_get_option( 'nt_landium_search_content_textalign' ) ).';}';
    }
	if ( ot_get_option( 'nt_landium_search_content_textalign' ) =='center' ){
    $theCSS .= '@media (min-width: 992px){body.search article .searchform {float:none}}';
    }
	if  ( ot_get_option( 'nt_landium_searchheaderbgheight' ) !='' ){
     $theCSS .= '.search .index-header {height: '.esc_attr( ot_get_option( 'nt_landium_searchheaderbgheight' ) ) .'vh !important; }';
    }
	if  (( ot_get_option( 'nt_landium_searchheaderpaddingtop' ) !='' )||( ot_get_option( 'nt_landium_searchheaderpaddingbottom' ) !='' )) {
		$theCSS .= '@media (min-width: 768px){
			.search .index-header  {
				padding-top: '.  esc_attr( ot_get_option( 'nt_landium_searchheaderpaddingtop' ) ) .'px !important;
				padding-bottom: '.  esc_attr( ot_get_option( 'nt_landium_searchheaderpaddingbottom' ) ) .'px !important;
			}
		}';
	}

	if( is_home() )			{ $nt_landium_ot_id = 'blog'; }
	elseif( is_single() )	{ $nt_landium_ot_id = 'single'; }
	elseif( is_archive() )	{ $nt_landium_ot_id = 'archive'; }
	elseif( is_search() )	{ $nt_landium_ot_id = 'search'; }
	elseif( is_404() )		{ $nt_landium_ot_id = 'error'; }
	else					{ $nt_landium_ot_id = 'page'; }

	if ( $nt_landium_ot_id != 'page' ){
		//max-width 992px resolution
		$nt_landium_992_bg 	 = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_992_headbg' );
		$nt_landium_992_bg_h = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_992_bgheight' );
		$nt_landium_992_h_ta = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_992_heading_textalign' );
		$nt_landium_992_c_ta = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_992_content_textalign' );
		$nt_landium_992_h_fs = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_992_heading_fontsize' );
		$nt_landium_992_h_pt = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_992_heading_padtop' );
		$nt_landium_992_h_pb = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_992_heading_padbot' );

		if ( $nt_landium_992_bg !='' || $nt_landium_992_bg_h !='' || $nt_landium_992_h_fs !='' ){
			$theCSS .= '@media (max-width: 992px){';
				if  ( $nt_landium_992_bg !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header{background: transparent url('.esc_attr( $nt_landium_992_bg ).')no-repeat scroll center top / cover!important; }';
				}
				if  ( $nt_landium_992_bg_h !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header{height:'.esc_attr( $nt_landium_992_bg_h ).'vh !important;min-height:auto; }';
				}
				if  ( $nt_landium_992_h_ta !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header .template-cover-text *{text-align:'.esc_attr( $nt_landium_992_h_ta ).'; }';
				}
				if  ( $nt_landium_992_c_ta !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' article {text-align:'.esc_attr( $nt_landium_992_c_ta ).'; }.'.$nt_landium_ot_id.' .article-img img {margin-left: auto;margin-right: auto;display: block;}';
				}
				if  ( $nt_landium_992_c_ta =='center' ){
				 $theCSS .= 'body.'.$nt_landium_ot_id.' article .searchform {float:none}';
				}
				if  ( $nt_landium_992_h_fs !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header .uppercase{font-size:'.esc_attr( $nt_landium_992_h_fs ).'px !important; }';
				}
				if  ( $nt_landium_992_h_pt !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header {padding-top:'.esc_attr( $nt_landium_992_h_pt ).'px !important; }';
				}
				if  ( $nt_landium_992_h_pb !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header {padding-bottom:'.esc_attr( $nt_landium_992_h_pb ).'px !important; }';
				}
			$theCSS .= '}';
		}
		//max-width 768px resolution
		$nt_landium_768_bg 	= ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_768_headbg' );
		$nt_landium_768_bg_h = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_768_bgheight' );
		$nt_landium_768_h_ta = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_768_heading_textalign' );
		$nt_landium_768_c_ta = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_768_content_textalign' );
		$nt_landium_768_h_fs = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_768_heading_fontsize' );
		$nt_landium_768_h_pt = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_768_heading_padtop' );
		$nt_landium_768_h_pb = ot_get_option( 'nt_landium_'.$nt_landium_ot_id.'_768_heading_padbot' );

		if ( $nt_landium_768_bg !='' || $nt_landium_768_bg_h !='' || $nt_landium_768_h_fs !='' ){
			$theCSS .= '@media (max-width: 768px){';
				if  ( $nt_landium_768_bg !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header{background: transparent url('.esc_attr( $nt_landium_768_bg ).')no-repeat scroll center top / cover!important; }';
				}
				if  ( $nt_landium_768_bg_h !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header{height:'.esc_attr( $nt_landium_768_bg_h ).'vh !important; }';
				}
				if  ( $nt_landium_768_h_ta !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header .template-cover-text *{text-align:'.esc_attr( $nt_landium_768_h_ta ).'; }';
				}
				if  ( $nt_landium_768_c_ta !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' article {text-align:'.esc_attr( $nt_landium_768_c_ta ).'; }.'.$nt_landium_ot_id.' .article-img img {margin-left: auto;margin-right: auto;display: block;}body.search article .searchform, body.error404 article .searchform {float:none}';
				}
				if  ( $nt_landium_768_h_fs !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header .uppercase{font-size:'.esc_attr( $nt_landium_768_h_fs ).'px !important; }';
				}
				if  ( $nt_landium_768_h_pt !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header {padding-top:'.esc_attr( $nt_landium_768_h_pt ).'px !important; }';
				}
				if  ( $nt_landium_768_h_pb !='' ){
				 $theCSS .= '.'.$nt_landium_ot_id.' .index-header {padding-bottom:'.esc_attr( $nt_landium_768_h_pb ).'px !important; }';
				}
			$theCSS .= '}';
		}
	}


	if  ( ot_get_option( 'nt_landium_bread' ) !='off' ){
		// BREADCRUBMS
		if  ( ot_get_option( 'nt_landium_blogbreadcrubmscolor' ) !='' ){
		 $theCSS .= '.breadcrubms, .breadcrubms span a span{color: '.  esc_attr( ot_get_option( 'nt_landium_blogbreadcrubmscolor' ) ) .'; }';
		}
		if  ( ot_get_option( 'nt_landium_blogbreadcrubmshovercolor' ) !='' ){
		 $theCSS .= '.breadcrubms span a span:hover{color: '.  esc_attr( ot_get_option( 'nt_landium_blogbreadcrubmshovercolor' ) ) .'; }';
		}
		if  ( ot_get_option( 'nt_landium_blogbreadcrubmscurrentcolor' ) !='' ){
		 $theCSS .= '.breadcrubms span {color: '.  esc_attr( ot_get_option( 'nt_landium_blogbreadcrubmscurrentcolor' ) ) .'; }';
		}
		if  ( ot_get_option( 'nt_landium_blogbreadcrubmsfontsize' ) !='' ){
		 $theCSS .= '.breadcrubms{font-size: '.  esc_attr( ot_get_option( 'nt_landium_blogbreadcrubmsfontsize' ) ) .'px; }';
		}
	}



	if  ( ot_get_option( 'nt_landium_blogposttitlecolor' ) !='' ){
     $theCSS .= '.entry-title a{color: '.  esc_attr( ot_get_option( 'nt_landium_blogposttitlecolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_blogposttitlhoverecolor' ) !='' ){
     $theCSS .= '.entry-title a:hover{color: '.  esc_attr( ot_get_option( 'nt_landium_blogposttitlhoverecolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetacolor' ) !='' ){
     $theCSS .= '.entry-meta li{color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetacolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetalinktextcolor' ) !='' ){
     $theCSS .= '.entry-meta li a{color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinktextcolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_blogmetalinkhovercolor' ) !='' ){
     $theCSS .= '.entry-meta li a:hover{color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinkhovercolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetalinktextbgcolor' ) !='' ){
     $theCSS .= '.entry-meta li a{background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinktextbgcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetalinktextbghovercolor' ) !='' ){
     $theCSS .= '.entry-meta li a:hover{background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinktextbghovercolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogpostparagraphcolor' ) !='' ){
     $theCSS .= '.entry-content p{color: '.  esc_attr( ot_get_option( 'nt_landium_blogpostparagraphcolor' ) ) .'; }';
	 $theCSS .= '.entry-content p{color:#000;}';
	}
	if  ( ot_get_option( 'nt_landium_blogpostbuttonbgcolor' ) !='' ){
     $theCSS .= 'a.margin_30{background-color:'.  esc_attr( ot_get_option( 'nt_landium_blogpostbuttonbgcolor' ) ) .';}';
    }
	if  ( ot_get_option( 'nt_landium_blogpostbuttonbghovercolor' ) !='' ){
     $theCSS .= 'a.margin_30:hover{background-color:'.  esc_attr( ot_get_option( 'nt_landium_blogpostbuttonbghovercolor' ) ) .';}';
    }
	if  ( ot_get_option( 'nt_landium_blogpostbuttontitlecolor' ) !='' ){
     $theCSS .= 'a.margin_30{color:'.  esc_attr( ot_get_option( 'nt_landium_blogpostbuttontitlecolor' ) ) .';}';
    }
	if  ( ot_get_option( 'nt_landium_blogpostbuttontitlehovercolor' ) !='' ){
     $theCSS .= 'a.margin_30:hover{color:'.  esc_attr( ot_get_option( 'nt_landium_blogpostbuttontitlehovercolor' ) ) .';}';
    }


	if  ( ot_get_option( 'nt_landium_blogsharebgcolor' ) !='' ){
     $theCSS .= '#share-buttons i{ background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogsharebgcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogsharebghovercolor' ) !='' ){
    $theCSS .= ' #share-buttons i:hover{ background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogsharebghovercolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogsharecolor' ) !='' ){
     $theCSS .= '#share-buttons i{ color: '.  esc_attr( ot_get_option( 'nt_landium_blogsharecolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogsharehovercolor' ) !='' ){
     $theCSS .= '#share-buttons i:hover{ color: '.  esc_attr( ot_get_option( 'nt_landium_blogsharehovercolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetalinktextcolor' ) !='' ){
     $theCSS .= 'p.logged-in-as a{color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinktextcolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_blogmetalinkhovercolor' ) !='' ){
     $theCSS .= 'p.logged-in-as a:hover{color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinkhovercolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetalinktextbgcolor' ) !='' ){
     $theCSS .= 'p.logged-in-as a{background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinktextbgcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetalinktextbghovercolor' ) !='' ){
     $theCSS .= 'p.logged-in-as a:hover{background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinktextbghovercolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetalinktextcolor' ) !='' ){
     $theCSS .= 'a.comment-edit-link,a.comment-reply-link{color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinktextcolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_blogmetalinkhovercolor' ) !='' ){
     $theCSS .= 'a.comment-edit-link:hover,a.comment-reply-link:hover{color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinkhovercolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetalinktextbgcolor' ) !='' ){
     $theCSS .= 'a.comment-edit-link,a.comment-reply-link{background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinktextbgcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogmetalinktextbghovercolor' ) !='' ){
     $theCSS .= 'a.comment-edit-link:hover,a.comment-reply-link:hover{background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogmetalinktextbghovercolor' ) ) .'; }';
    }

	if  ( ot_get_option( 'nt_landium_blogcommentformsubmitcolor' ) !='' ){
     $theCSS .= '.comment-form .submit{color: '.  esc_attr( ot_get_option( 'nt_landium_blogcommentformsubmitcolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_blogcommentformsubmithovercolor' ) !='' ){
     $theCSS .= '.comment-form .submit:hover{color: '.  esc_attr( ot_get_option( 'nt_landium_blogcommentformsubmithovercolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogcommentformsubmitbgcolor' ) !='' ){
     $theCSS .= '.comment-form .submit{background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogcommentformsubmitbgcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_blogcommentformsubmitbghovercolor' ) !='' ){
     $theCSS .= '.comment-form .submit:hover{background-color: '.  esc_attr( ot_get_option( 'nt_landium_blogcommentformsubmitbghovercolor' ) ) .'; }';
	}


	if  ( ot_get_option( 'nt_landium_pagertitlecolor' ) !='' ){
     $theCSS .= '.pager li a{color: '.  esc_attr( ot_get_option( 'nt_landium_pagertitlecolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_pagertitlehovercolor' ) !='' ){
     $theCSS .= '.pager li a:hover{color: '.  esc_attr( ot_get_option( 'nt_landium_pagertitlehovercolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_pagerbgcolor' ) !='' ){
     $theCSS .= '.pager li a{background-color: '.  esc_attr( ot_get_option( 'nt_landium_pagerbgcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_pagerbghovercolor' ) !='' ){
     $theCSS .= '.pager li a:hover{background-color: '.  esc_attr( ot_get_option( 'nt_landium_pagerbghovercolor' ) ) .'; }';
	}

	// FOOTER WIDGETIZE OPTIONS
	$nt_landium_f_v_overlay	= 	esc_attr( ot_get_option( 'nt_landium_footerwidgetizebgoverlay' ) );
	$nt_landium_f_v_bg		= 	esc_attr( ot_get_option( 'nt_landium_footerwidgetizebgcolor' ) );
	$nt_landium_f_v_padtop	= 	esc_attr( ot_get_option( 'nt_landium_footerwidgetizepadtop' ) );
	$nt_landium_f_v_padbot	= 	esc_attr( ot_get_option( 'nt_landium_footerwidgetizepadbottom' ) );
	$nt_landium_f_h_c		= 	esc_attr( ot_get_option( 'nt_landium_footer_h_c' ) );
	$nt_landium_f_t_c		= 	esc_attr( ot_get_option( 'nt_landium_footer_t_c' ) );
	$nt_landium_f_a_c		= 	esc_attr( ot_get_option( 'nt_landium_footer_a_c' ) );
	$nt_landium_f_a_hc		= 	esc_attr( ot_get_option( 'nt_landium_footer_a_hc' ) );

	// WIDGETIZE FOOTER
	$footerbgimg = ot_get_option( 'nt_landium_footerwidgetizebgimg', array() );
	if ( !empty($footerbgimg) ) {
		$theCSS .= '.footer-top.footer-widgetize{';
		if(!empty($footerbgimg['background-color'])) 	{ $theCSS .= 'background-color:'.$footerbgimg['background-color'].' !important;'; }
		if(!empty($footerbgimg['background-image'])) 	{ $theCSS .= 'background-image:url("'.$footerbgimg['background-image'].'") !important;'; }
		if(!empty($footerbgimg['background-repeat'])) 	{ $theCSS .= 'background-repeat:'.$footerbgimg['background-repeat'].' !important;'; }
		if(!empty($footerbgimg['background-position'])) { $theCSS .= 'background-position:'.$footerbgimg['background-position'].' !important;'; }
		if(!empty($footerbgimg['background-attachment'])){ $theCSS .= 'background-attachment:'.$footerbgimg['background-attachment'].' !important;'; }
		if(!empty($footerbgimg['background-size'])) 	{ $theCSS .= 'background-size:'.$footerbgimg['background-size'].' !important;'; }
		$theCSS .= '}';
	}

	if  ( $nt_landium_f_v_overlay !='' ){
    $theCSS .= '.footer-top.footer-widgetize{position:relative;}.footer-top.footer-widgetize:before{content:"";position:absolute;width:100%;height:100%;left:0;top:0; background-color: '.$nt_landium_f_v_overlay .'; }';
    }
	if  ( $nt_landium_f_v_bg !='' ){
    $theCSS .= '.footer-top.footer-widgetize{ background-color: '.$nt_landium_f_v_bg .'; }';
    }
	if  ( $nt_landium_f_v_padtop !='' ){
    $theCSS .= '.footer-top.footer-widgetize{ padding-top: '.$nt_landium_f_v_padtop.'px!important; }';
    }
	if  ( $nt_landium_f_v_padbot !='' ){
    $theCSS .= '.footer-top.footer-widgetize{ padding-bottom: '.$nt_landium_f_v_padbot.'px !important; }';
    }
	if  ( $nt_landium_f_h_c !='' ){
     $theCSS .= '.footer-top.footer-widgetize .widget .widget-head{color: '.$nt_landium_f_h_c.'!important; }';
	}
	if  ( $nt_landium_f_a_c ){
     $theCSS .= '.footer-top.footer-widgetize .widget ul li a{ color: '.$nt_landium_f_a_c .'!important; }';
	}
	if  ( $nt_landium_f_a_hc ){
     $theCSS .= '.footer-top.footer-widgetize .widget ul li a:hover{ color: '. $nt_landium_f_a_hc.'!important; }';
	}
	if  ( $nt_landium_f_t_c !='' ){
     $theCSS .= '.footer-top.footer-widgetize .widget .textwidget{color: '.$nt_landium_f_t_c.'!important; }';
	}

	// FOOTER COPYRIGHT OPTIONS

	//footer form section
	if ( ot_get_option( 'nt_landium_footernewsletterbgcolor' ) !='' ){
    $theCSS .= '#footer .s-form, #footer.footer--style-2:before, #footer.footer--style-2 .s-form:before{background-color: '.  esc_attr( ot_get_option( 'nt_landium_footernewsletterbgcolor' ) ) .'!important; }';
    }
	if ( ot_get_option('nt_landium_contact') == 'off' ){
    $theCSS .= '#footer .s-form, #footer.footer--style-2:before, #footer.footer--style-2 .s-form:before{width: 100%!important; }';
    }
	if ( ot_get_option('nt_landium_news') == 'off' ){
    $theCSS .= '#footer .s-form, #footer.footer--style-2:before, #footer.footer--style-2 .s-form:before{background-color: '.  esc_attr( ot_get_option( 'nt_landium_footerbgcolor' ) ) .'!important; }';
    }
	if ( ot_get_option('nt_landium_news') == 'off' ){
    $theCSS .= '#footer.footer--style-2 .disable-news .contact__item{display: inline-block!important;margin-right:20px; }';
    }
	if ( ot_get_option('nt_landium_news') == 'off' ){
		if ( ot_get_option('nt_landium_news') == 'off' &&  ot_get_option('nt_landium_social_section') != 'off' ){
		$theCSS .= '#footer.footer--style-2 .contact__item.clearfix.footer-social {float: right;}';
		$theCSS .= '@media (max-width:768px){#footer.footer--style-2 .contact__item.clearfix.footer-social {float: none;padding-left: 0px;}}';
		}
		if ( ot_get_option('nt_landium_news') == 'off' &&  ot_get_option('nt_landium_footer_default') != 'off' ){
		$theCSS .= '#footer.footer--style-2 .footer-copyright {text-align: left;margin-bottom: 60px;position: relative;}';
		}
	}

	if ( ot_get_option('nt_landium_map_display') == 'off' ){
		$theCSS .= '#footer.footer--style-3 .contact__item{display: inline-block!important;margin-right:20px; }';
		if ( ot_get_option('nt_landium_map_display') == 'off' &&  ot_get_option('nt_landium_social_section') != 'off' ){
		$theCSS .= '#footer.footer--style-3 .contact__item.clearfix.footer-social {float: right;}';
		$theCSS .= '@media (max-width:768px){#footer.footer--style-3 .contact__item.clearfix.footer-social {float: none;padding-left: 0px;}}';
		}
		if ( ot_get_option('nt_landium_map_display') == 'off' &&  ot_get_option('nt_landium_footer_default') != 'off' ){
		$theCSS .= '#footer.footer--style-3 .footer-copyright {text-align: left;margin-bottom: 60px;position: relative;}';
		}
	}

	if (ot_get_option('nt_landium_contact') == 'off' && ot_get_option('nt_landium_social_section') == 'off' && ot_get_option('nt_landium_footer_default') == 'off' ){
		$theCSS .= '#footer.footer--style-3 .map-container {float:none;width:100%;}';
	}

	if ( ot_get_option( 'nt_landium_footernewslettertitlecolor' ) !='' ){
    $theCSS .= '.s-form .section-heading.section-heading--white .title{color: '.  esc_attr( ot_get_option( 'nt_landium_footernewslettertitlecolor' ) ) .'!important; }';
    }
	if ( ot_get_option( 'nt_landium_footernewsletterdesccolor' ) !='' ){
    $theCSS .= '.s-form .section-heading.section-heading--white p{color: '.  esc_attr( ot_get_option( 'nt_landium_footernewsletterdesccolor' ) ) .'!important; }';
    }
	if ( ot_get_option( 'nt_landium_footernewsletterinputcolor' ) !='' ){
    $theCSS .= '#footer .footer__form .input-wrp input, #footer .footer__form .input-wrp textarea{color: '.  esc_attr( ot_get_option( 'nt_landium_footernewsletterinputcolor' ) ) .'!important; }';
    }
	if ( ot_get_option( 'nt_landium_footernewsletterinputbordercolor' ) !='' ){
    $theCSS .= '#footer .footer__form .input-wrp input, #footer .footer__form .input-wrp textarea{border-color: '.  esc_attr( ot_get_option( 'nt_landium_footernewsletterinputbordercolor' ) ) .'!important; }';
    }
	if ( ot_get_option( 'nt_landium_footernewslettericoncolor' ) !='' ){
    $theCSS .= '.s-form form .input-wrp i{color: '.  esc_attr( ot_get_option( 'nt_landium_footernewslettericoncolor' ) ) .'!important; }';
    }
	if ( ot_get_option( 'nt_landium_footernewsletterbuttonbordercolor' ) !='' ){
    $theCSS .= '.s-form .custom-btn.light, .s-form .custom-btn.light.inverted {border-color: '.  esc_attr( ot_get_option( 'nt_landium_footernewsletterbuttonbordercolor' ) ) .'!important; }';
    }
	if ( ot_get_option( 'nt_landium_footernewsletterbuttoncolor' ) !='' ){
    $theCSS .= '.s-form .custom-btn.light.inverted:hover, .s-form .custom-btn.light.inverted:focus {background-color: '.  esc_attr( ot_get_option( 'nt_landium_footernewsletterbuttoncolor' ) ) .'!important; }';
    }
	//footer bottom and contact item
	if  ( ot_get_option( 'nt_landium_footerbgcolor' ) !='' ){
    $theCSS .= '.footer--style-3, .footer--style-2, .footer__bottom-text, .footer__contact{background-color: '.  esc_attr( ot_get_option( 'nt_landium_footerbgcolor' ) ) .'!important; }';
    }
	if  ( ot_get_option( 'nt_landium_footercopyrightpadding' ) !='' ){
    $theCSS .= '.footer__bottom-text{padding: '.  esc_attr( ot_get_option( 'nt_landium_footercopyrightpadding' ) ) .'px 0!important; }';
    }
	if  ( ot_get_option( 'nt_landium_footercontactpaddingtop' ) !='' ){
    $theCSS .= '.footer__contact{padding-top: '.  esc_attr( ot_get_option( 'nt_landium_footercontactpaddingtop' ) ) .'px!important; }';
    }
	if  ( ot_get_option( 'nt_landium_footercontactpaddingbottom' ) !='' ){
    $theCSS .= '.footer__contact{padding-bottom: '.  esc_attr( ot_get_option( 'nt_landium_footercontactpaddingbottom' ) ) .'px!important; }';
    }
	if  ( ot_get_option( 'nt_landium_footercontacttextcolor' ) !='' ){
    $theCSS .= '.footer__contact, #footer .contact__item {color: '.  esc_attr( ot_get_option( 'nt_landium_footercontacttextcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_footercontacttextcolor' ) !='' ){
    $theCSS .= '#footer .contact__item > a[href^="mailto"] {border-color: '.  esc_attr( ot_get_option( 'nt_landium_footercontacttextcolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_footercontacticoncolor' ) !='' ){
    $theCSS .= '.footer__contact i, #footer .contact__item i{color: '.  esc_attr( ot_get_option( 'nt_landium_footercontacticoncolor' ) ) .'; }';
    }
	if  ( ot_get_option( 'nt_landium_footerpoweredcolor' ) !='' ){
     $theCSS .= '.footer__bottom-text, .footer__bottom-text p, .footer-style-2 p, .footer-style-2 p, .footer-style-2, .footer-style-3 {color: '.  esc_attr( ot_get_option( 'nt_landium_footerpoweredcolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_footerpoweredbordertopcolor' ) !='' ){
     $theCSS .= '#footer.footer--style-1 .footer__bottom-text{border-color: '.  esc_attr( ot_get_option( 'nt_landium_footerpoweredbordertopcolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_footersocialcolor' ) !='' ){
     $theCSS .= '#footer .social-btns a{color: '.  esc_attr( ot_get_option( 'nt_landium_footersocialcolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_footersocialhovercolor' ) !='' ){
     $theCSS .= '#footer .social-btns a:hover{color: '.  esc_attr( ot_get_option( 'nt_landium_footersocialhovercolor' ) ) .'; }';
	}
	if  ( ot_get_option( 'nt_landium_social_fontsize' ) !='' ){
     $theCSS .= '#footer .social-btns a{font-size: '.  esc_attr( ot_get_option( 'nt_landium_social_fontsize' ) ) .'px; }';
    }
	if  ( ot_get_option( 'nt_landium_social_margin_left' ) !='' ){
     $theCSS .= '.footer__bottom-text .social-btns a{margin-left: '.  esc_attr( ot_get_option( 'nt_landium_social_margin_left' ) ) .'px; }';
    }
	if  ( ot_get_option( 'nt_landium_social_opacity' ) !='' ){
     $theCSS .= '.footer__bottom-text .social-btns a{opacity: '.  esc_attr( ot_get_option( 'nt_landium_social_opacity' ) ) .'; }';
    }

	// tipigrof
	$nt_landium_typgrph = ot_get_option( 'nt_landium_typgrph', array() );
	if ( !empty($nt_landium_typgrph) ) :
	$theCSS .= 'body{';
	if ( !empty($nt_landium_typgrph['font-color']) ) {$theCSS .= 'color:'.esc_attr( $nt_landium_typgrph['font-color'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph['font-family']) ) {$theCSS .= 'font-family:"'.esc_attr( $nt_landium_typgrph['font-family'] ).'"!important;'; }
	if ( !empty($nt_landium_typgrph['font-size']) ) {$theCSS .= 'font-size:'.esc_attr( $nt_landium_typgrph['font-size'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph['font-style']) ) {$theCSS .= 'font-style:'.esc_attr( $nt_landium_typgrph['font-style'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph['font-variant']) ) {$theCSS .= 'font-variant:'.esc_attr( $nt_landium_typgrph['font-variant'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph['font-weight']) ) {$theCSS .= 'font-weight:'.esc_attr( $nt_landium_typgrph['font-weight'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph['letter-spacing']) ) {$theCSS .= 'letter-spacing:'.esc_attr( $nt_landium_typgrph['letter-spacing'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph['line-height'])) {$theCSS .= 'line-height:'.esc_attr( $nt_landium_typgrph['line-height'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph['text-decoration'])){$theCSS .= 'text-decoration:'.esc_attr($nt_landium_typgrph['text-decoration']).'!important;'; }
	if ( !empty($nt_landium_typgrph['text-transform'])){$theCSS .= 'text-transform:'.esc_attr($nt_landium_typgrph['text-transform']).'!important;'; }
	$theCSS .= '}';
	endif;
	//
	$nt_landium_typgrph1 = ot_get_option( 'nt_landium_typgrph1', array() );
	if ( !empty($nt_landium_typgrph1) ) :
	$theCSS .= 'body h1{';
	if ( !empty($nt_landium_typgrph1['font-color']) ) {$theCSS .= 'color:'.esc_attr( $nt_landium_typgrph1['font-color'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph1['font-family']) ) {$theCSS .= 'font-family:"'.esc_attr( $nt_landium_typgrph1['font-family'] ).'"!important;'; }
	if ( !empty($nt_landium_typgrph1['font-size']) ) {$theCSS .= 'font-size:'.esc_attr( $nt_landium_typgrph1['font-size'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph1['font-style']) ) {$theCSS .= 'font-style:'.esc_attr( $nt_landium_typgrph1['font-style'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph1['font-variant']) ) {$theCSS .= 'font-variant:'.esc_attr( $nt_landium_typgrph1['font-variant'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph1['font-weight']) ) {$theCSS .= 'font-weight:'.esc_attr( $nt_landium_typgrph1['font-weight'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph1['letter-spacing']) ) {$theCSS .= 'letter-spacing:'.esc_attr( $nt_landium_typgrph1['letter-spacing'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph1['line-height'])) {$theCSS .= 'line-height:'.esc_attr( $nt_landium_typgrph1['line-height'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph1['text-decoration'])){$theCSS .= 'text-decoration:'.esc_attr($nt_landium_typgrph1['text-decoration']).'!important;'; }
	if ( !empty($nt_landium_typgrph1['text-transform'])){$theCSS .= 'text-transform:'.esc_attr($nt_landium_typgrph1['text-transform']).'!important;'; }
	$theCSS .= '}';
	endif;
	//
	$nt_landium_typgrph2 = ot_get_option( 'nt_landium_typgrph2', array() );
	if ( !empty($nt_landium_typgrph2) ) :
	$theCSS .= 'body h2{';
	if ( !empty($nt_landium_typgrph2['font-color']) ) {$theCSS .= 'color:'.esc_attr( $nt_landium_typgrph2['font-color'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph2['font-family']) ) {$theCSS .= 'font-family:'.esc_attr( $nt_landium_typgrph2['font-family'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph2['font-size']) ) {$theCSS .= 'font-size:'.esc_attr( $nt_landium_typgrph2['font-size'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph2['font-style']) ) {$theCSS .= 'font-style:'.esc_attr( $nt_landium_typgrph2['font-style'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph2['font-variant']) ) {$theCSS .= 'font-variant:'.esc_attr( $nt_landium_typgrph2['font-variant'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph2['font-weight']) ) {$theCSS .= 'font-weight:'.esc_attr( $nt_landium_typgrph2['font-weight'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph2['letter-spacing']) ) {$theCSS .= 'letter-spacing:'.esc_attr( $nt_landium_typgrph2['letter-spacing'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph2['line-height'])) {$theCSS .= 'line-height:'.esc_attr( $nt_landium_typgrph2['line-height'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph2['text-decoration'])){$theCSS .= 'text-decoration:'.esc_attr($nt_landium_typgrph2['text-decoration']).'!important;'; }
	if ( !empty($nt_landium_typgrph2['text-transform'])){$theCSS .= 'text-transform:'.esc_attr($nt_landium_typgrph2['text-transform']).'!important;'; }
	$theCSS .= '}';
	endif;
	//
	$nt_landium_typgrph3 = ot_get_option( 'nt_landium_typgrph3', array() );
	if ( !empty($nt_landium_typgrph3) ) :
	$theCSS .= 'body h3{';
	if ( !empty($nt_landium_typgrph3['font-color']) ) {$theCSS .= 'color:'.esc_attr( $nt_landium_typgrph3['font-color'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph3['font-family']) ) {$theCSS .= 'font-family:'.esc_attr( $nt_landium_typgrph3['font-family'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph3['font-size']) ) {$theCSS .= 'font-size:'.esc_attr( $nt_landium_typgrph3['font-size'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph3['font-style']) ) {$theCSS .= 'font-style:'.esc_attr( $nt_landium_typgrph3['font-style'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph3['font-variant']) ) {$theCSS .= 'font-variant:'.esc_attr( $nt_landium_typgrph3['font-variant'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph3['font-weight']) ) {$theCSS .= 'font-weight:'.esc_attr( $nt_landium_typgrph3['font-weight'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph3['letter-spacing']) ) {$theCSS .= 'letter-spacing:'.esc_attr( $nt_landium_typgrph3['letter-spacing'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph3['line-height'])) {$theCSS .= 'line-height:'.esc_attr( $nt_landium_typgrph3['line-height'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph3['text-decoration'])){$theCSS .= 'text-decoration:'.esc_attr($nt_landium_typgrph3['text-decoration']).'!important;'; }
	if ( !empty($nt_landium_typgrph3['text-transform'])){$theCSS .= 'text-transform:'.esc_attr($nt_landium_typgrph3['text-transform']).'!important;'; }
	$theCSS .= '}';
	endif;
	//
	$nt_landium_typgrph4 = ot_get_option( 'nt_landium_typgrph4', array() );
	if ( !empty($nt_landium_typgrph4) ) :
	$theCSS .= 'body h4{';
	if ( !empty($nt_landium_typgrph4['font-color']) ) {$theCSS .= 'color:'.esc_attr( $nt_landium_typgrph4['font-color'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph4['font-family']) ) {$theCSS .= 'font-family:'.esc_attr( $nt_landium_typgrph4['font-family'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph4['font-size']) ) {$theCSS .= 'font-size:'.esc_attr( $nt_landium_typgrph4['font-size'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph4['font-style']) ) {$theCSS .= 'font-style:'.esc_attr( $nt_landium_typgrph4['font-style'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph4['font-variant']) ) {$theCSS .= 'font-variant:'.esc_attr( $nt_landium_typgrph4['font-variant'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph4['font-weight']) ) {$theCSS .= 'font-weight:'.esc_attr( $nt_landium_typgrph4['font-weight'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph4['letter-spacing']) ) {$theCSS .= 'letter-spacing:'.esc_attr( $nt_landium_typgrph4['letter-spacing'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph4['line-height'])) {$theCSS .= 'line-height:'.esc_attr( $nt_landium_typgrph4['line-height'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph4['text-decoration'])){$theCSS .= 'text-decoration:'.esc_attr($nt_landium_typgrph4['text-decoration']).'!important;'; }
	if ( !empty($nt_landium_typgrph4['text-transform'])){$theCSS .= 'text-transform:'.esc_attr($nt_landium_typgrph4['text-transform']).'!important;'; }
	$theCSS .= '}';
	endif;
	//
	$nt_landium_typgrph5 = ot_get_option( 'nt_landium_typgrph5', array() );
	if ( !empty($nt_landium_typgrph5) ) :
	$theCSS .= 'body h5{';
	if ( !empty($nt_landium_typgrph5['font-color']) ) {$theCSS .= 'color:'.esc_attr( $nt_landium_typgrph5['font-color'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph5['font-family']) ) {$theCSS .= 'font-family:'.esc_attr( $nt_landium_typgrph5['font-family'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph5['font-size']) ) {$theCSS .= 'font-size:'.esc_attr( $nt_landium_typgrph5['font-size'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph5['font-style']) ) {$theCSS .= 'font-style:'.esc_attr( $nt_landium_typgrph5['font-style'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph5['font-variant']) ) {$theCSS .= 'font-variant:'.esc_attr( $nt_landium_typgrph5['font-variant'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph5['font-weight']) ) {$theCSS .= 'font-weight:'.esc_attr( $nt_landium_typgrph5['font-weight'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph5['letter-spacing']) ) {$theCSS .= 'letter-spacing:'.esc_attr( $nt_landium_typgrph5['letter-spacing'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph5['line-height'])) {$theCSS .= 'line-height:'.esc_attr( $nt_landium_typgrph5['line-height'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph5['text-decoration'])){$theCSS .= 'text-decoration:'.esc_attr($nt_landium_typgrph5['text-decoration']).'!important;'; }
	if ( !empty($nt_landium_typgrph5['text-transform'])){$theCSS .= 'text-transform:'.esc_attr($nt_landium_typgrph5['text-transform']).'!important;'; }
	$theCSS .= '}';
	endif;
	//
	$nt_landium_typgrph6 = ot_get_option( 'nt_landium_typgrph6', array() );
	if ( !empty($nt_landium_typgrph6) ) :
	$theCSS .= 'body h6{';
	if ( !empty($nt_landium_typgrph6['font-color']) ) {$theCSS .= 'color:'.esc_attr( $nt_landium_typgrph6['font-color'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph6['font-family']) ) {$theCSS .= 'font-family:'.esc_attr( $nt_landium_typgrph6['font-family'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph6['font-size']) ) {$theCSS .= 'font-size:'.esc_attr( $nt_landium_typgrph6['font-size'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph6['font-style']) ) {$theCSS .= 'font-style:'.esc_attr( $nt_landium_typgrph6['font-style'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph6['font-variant']) ) {$theCSS .= 'font-variant:'.esc_attr( $nt_landium_typgrph6['font-variant'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph6['font-weight']) ) {$theCSS .= 'font-weight:'.esc_attr( $nt_landium_typgrph6['font-weight'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph6['letter-spacing']) ) {$theCSS .= 'letter-spacing:'.esc_attr( $nt_landium_typgrph6['letter-spacing'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph6['line-height'])) {$theCSS .= 'line-height:'.esc_attr( $nt_landium_typgrph6['line-height'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph6['text-decoration'])){$theCSS .= 'text-decoration:'.esc_attr($nt_landium_typgrph6['text-decoration']).'!important;'; }
	if ( !empty($nt_landium_typgrph6['text-transform'])){$theCSS .= 'text-transform:'.esc_attr($nt_landium_typgrph6['text-transform']).'!important;'; }
	$theCSS .= '}';
	endif;
	$nt_landium_typgrph7 = ot_get_option( 'nt_landium_typgrph7', array() );
	if ( !empty($nt_landium_typgrph7) ) :
	$theCSS .= 'body p{';
	if ( !empty($nt_landium_typgrph7['font-color']) ) {$theCSS .= 'color:'.esc_attr( $nt_landium_typgrph7['font-color'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph7['font-family']) ) {$theCSS .= 'font-family:'.esc_attr( $nt_landium_typgrph7['font-family'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph7['font-size']) ) {$theCSS .= 'font-size:'.esc_attr( $nt_landium_typgrph7['font-size'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph7['font-style']) ) {$theCSS .= 'font-style:'.esc_attr( $nt_landium_typgrph7['font-style'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph7['font-variant']) ) {$theCSS .= 'font-variant:'.esc_attr( $nt_landium_typgrph7['font-variant'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph7['font-weight']) ) {$theCSS .= 'font-weight:'.esc_attr( $nt_landium_typgrph7['font-weight'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph7['letter-spacing']) ) {$theCSS .= 'letter-spacing:'.esc_attr( $nt_landium_typgrph7['letter-spacing'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph7['line-height'])) {$theCSS .= 'line-height:'.esc_attr( $nt_landium_typgrph7['line-height'] ).'!important;'; }
	if ( !empty($nt_landium_typgrph7['text-decoration'])){$theCSS .= 'text-decoration:'.esc_attr($nt_landium_typgrph7['text-decoration']).'!important;'; }
	if ( !empty($nt_landium_typgrph7['text-transform'])){$theCSS .= 'text-transform:'.esc_attr($nt_landium_typgrph7['text-transform']).'!important;'; }
	$theCSS .= '}';
	endif;


	// CUSTOM PRELOADER CSS
	if  ( ot_get_option('nt_landium_preloadercss')  !='' ) { $theCSS .= ''.ot_get_option( 'nt_landium_preloadercss' ).''; }

    /* Add CSS to style.css */
    wp_add_inline_style( 'nt-landium-custom-style', $theCSS );
	}

add_action( 'wp_enqueue_scripts', 'nt_landium_css_options' );
