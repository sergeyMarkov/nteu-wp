<?php

add_filter( 'rwmb_meta_boxes', 'nt_landium_register_meta_boxes' );
function nt_landium_register_meta_boxes( $meta_boxes ) {
    $prefix = 'nt_landium_';
    $meta_boxes = array();

    /* ----------------------------------------------------- */
    // Frontpage Settings
    /* ----------------------------------------------------- */
    
    $meta_boxes[] = array(
        'id' => 'pageherosettings',
        'title' => 'Page Hero Section',
        'pages' => array( 'page' ),
        'context' => 'normal',
        'priority' => 'high',
        'hide' => array(
            'template' => array( 'one-page-template.php' )
        ),
        'fields' => array(
            array(
                'type' => 'heading',
                'id' => 'page_design_section',
                'name' => esc_html__( 'Page Hero Section', 'nt-landium' ),
            ),
            array(
                'name' => esc_html__( 'Disable background Image', 'nt-landium' ),
                'id' => $prefix . "disable_bgimg",
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Hero section background image', 'nt-landium' ),
                'id' => $prefix . "page_bg_image",
                'type' => 'image_advanced',
                'max_file_uploads' => 1,
            ),
            array(
                'name' => esc_html__( 'Disable background image mask color', 'nt-landium' ),
                'id' => $prefix . "disable_page_mask",
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Disable page breadcrubms', 'nt-landium' ),
                'id' => $prefix . "disable_page_bred",
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Background image mask color', 'nt-landium' ),
                'id' => $prefix . "page_mask_color",
                'type' => 'color',
            ),
            array(
                'name' => esc_html__( 'Mask color opacity', 'nt-landium' ),
                'id' => $prefix . "page_mask_opacity",
                'type' => 'number',
                'min' => 0,
                'max' => 1,
                'step' => 0.1,
            ),
            array(
                'name' => esc_html__( 'Page background color', 'nt-landium' ),
                'id' => $prefix . "pagebgcolor",
                'type' => 'color',
            ),
            array(
                'name' => esc_html__( 'Page hero padding top', 'nt-landium' ),
                'id' => $prefix . "headerptop",
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
            array(
                'name' => esc_html__( 'Page hero padding bottom', 'nt-landium' ),
                'id' => $prefix . "headerpbottom",
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
            array(
                'name' => esc_html__( 'Header hero height. 1-100 ( vertical height - vh )', 'nt-landium' ),
                'id' => $prefix . "headerheight",
                'clone' => false,
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Header hero max height', 'nt-landium' ),
                'id' => $prefix . "headermaxheight",
                'clone' => false,
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Header hero min height', 'nt-landium' ),
                'id' => $prefix . "headerminheight",
                'clone' => false,
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Page hero text align', 'nt-landium' ),
                'id' => $prefix . "page_textalign",
                'type' => 'select',
                'options' => array(
                    'left' => esc_html__( 'left',  'nt-landium' ),
                    'right' => esc_html__( 'right', 'nt-landium' ),
                    'center'=> esc_html__( 'center','nt-landium' ),
                ),
                'multiple' => false,
                'std' => '',
                'placeholder' => esc_html__( 'Select an Item', 'nt-landium' ),
            ),
        )
    );
    //Page Title Options
    $meta_boxes[] = array(
        'id' => 'pageheadingsettings',
        'title' => 'Page Settings',
        'pages' => array( 'page' ),
        'context' => 'normal',
        'priority' => 'high',
        'hide' => array(
            'template' => array( 'one-page-template.php' )
        ),
        'fields' => array(
            array(
                'type' => 'heading',
                'id' => 'page_design_section',
                'name' => esc_html__( 'Page Title Options', 'nt-landium' ),
            ),
            array(
                'name' => esc_html__( 'Disable Page Title', 'nt-landium' ),
                'id' => $prefix . "disable_title",
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Alternate Page Title', 'nt-landium' ),
                'id' => $prefix . "alt_title",
                'clone' => false,
                'type' => 'text'
            ),
            array(
                'name' => esc_html__( 'Page title color', 'nt-landium' ),
                'id' => $prefix . "pagetitlecolor",
                'type' => 'color',
            ),
            array(
                'name' => esc_html__( 'Page title font size', 'nt-landium' ),
                'id' => $prefix . "pagetitlefontsize",
                'type' => 'number',
                'min' => 0,
                'max' => 100,
                'step' => 1,
            ),
        )
    );
    //Page Subtitle Options
    $meta_boxes[] = array(
        'id' => 'pagesubtitlesettings',
        'title' => 'Page Settings',
        'pages' => array( 'page' ),
        'context' => 'normal',
        'priority' => 'high',
        'hide' => array(
            'template' => array( 'one-page-template.php' )
        ),
        'fields' => array(
            array(
                'type' => 'heading',
                'id' => 'page_design_section',
                'name' => esc_html__( 'Page Subtitle Options', 'nt-landium' ),
            ),
            array(
                'name' => esc_html__( 'Disable Page Subtitle', 'nt-landium' ),
                'id' => $prefix . "disable_subtitle",
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Page Subtitle / Rich Text Editor', 'nt-landium' ),
                'id' => $prefix . "subtitle",
                'type' => 'wysiwyg',
                'raw' => false,
                'options' => array(
                    'textarea_rows' => 4,
                    'teeny' => true,
                    'media_buttons' => false,
                ),
            ),
            array(
                'name' => esc_html__( 'Page subtitle color', 'nt-landium' ),
                'id' => $prefix . "pagesubtitlecolor",
                'type' => 'color',
            ),
            array(
                'name' => esc_html__( 'Page subtitle font size', 'nt-landium' ),
                'id' => $prefix . "pagesubtitlefontsize",
                'type' => 'number',
                'min' => 0,
                'max' => 100,
                'step' => 1,
            ),
        )
    );

    //Page Sidebar Options
    $meta_boxes[] = array(
        'id' => 'pagesidebarsettings',
        'title' => 'Page Sidebar Options',
        'pages' => array( 'page' ),
        'context' => 'normal',
        'priority' => 'high',
        'hide' => array(
            'template' => array( 'one-page-template.php' )
        ),
        'fields' => array(
            array(
                'type' => 'heading',
                'id' => 'page_design_section',
                'name' => esc_html__( 'Page Sidebar Options', 'nt-landium' ),
            ),
            // SELECT BOX
            array(
                'name' => esc_html__( 'Page sidebar', 'nt-landium' ),
                'id' => $prefix . "pagelayout",
                'type' => 'select',
                'options' => array(
                    'left-sidebar' => esc_html__( 'left',  'nt-landium' ),
                    'right-sidebar' => esc_html__( 'right', 'nt-landium' ),
                    'full-width' => esc_html__( 'full',  'nt-landium' ),
                ),
                'multiple' => false,
                'std' => 'right-sidebar',
                'placeholder' => esc_html__( 'Select an Item', 'nt-landium' ),
            ),
        )
    );
    //responsive 992px
    $meta_boxes[] = array(
        'id' => 'pageresponsive992',
        'title' => esc_html__( 'Page Responsive( 992px )', 'nt-landium' ),
        'pages' => array( 'page' ),
        'context' => 'normal',
        'priority' => 'high',
        'hide' => array(
            'template' => array( 'one-page-template.php' )
        ),
        'fields' => array(
            // heading
            array(
                'type' => 'heading',
                'id' => 'page_design_section',
                'name' => esc_html__( 'Page Responsive( 992px )', 'nt-landium' ),
            ),
            array(
                'name' => esc_html__( 'Disable background Image', 'nt-landium' ),
                'id' => $prefix . "disable_bg992",
                'desc' =>  sprintf( esc_html__( 'You can use this option to disable %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>992px</strong>' ),
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Add new background Image', 'nt-landium' ),
                'id' => $prefix . "page_bg_image992",
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>992px</strong>' ),
                'type' => 'image_advanced',
                'max_file_uploads' => 1,
            ),
            array(
                'name' => esc_html__( 'Page hero height', 'nt-landium' ),
                'id' => $prefix . "page_hero_height992",
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the hero height</strong>', '<strong>992px</strong>' ),
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
            array(
                'name' => esc_html__( 'Page hero text align', 'nt-landium' ),
                'id' => $prefix . "page_textalign_992",
                'type' => 'select',
                'options' => array(
                    'left' => esc_html__( 'left',  'nt-landium' ),
                    'right' => esc_html__( 'right', 'nt-landium' ),
                    'center'=> esc_html__( 'center','nt-landium' ),
                ),
                'multiple' => false,
                'std' => '',
                'placeholder' => esc_html__( 'Select text align', 'nt-landium' ),
            ),
            array(
                'name' => esc_html__( 'Page title font-size', 'nt-landium' ),
                'id' => $prefix . "page_title_fs992",
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the page title font size</strong>', '<strong>992px</strong>' ),
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
            array(
                'name' => esc_html__( 'Page hero padding top', 'nt-landium' ),
                'id' => "nt_landium_header_992_p_top",
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
            array(
                'name' => esc_html__( 'Page hero padding bottom', 'nt-landium' ),
                'id' => "nt_landium_header_992_p_bottom",
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
        )
    );

    $meta_boxes[] = array(
        'id' => 'pageresponsive768',
        'title' => esc_html__( 'Page Responsive( 768px )', 'nt-landium' ),
        'pages' => array( 'page' ),
        'context' => 'normal',
        'priority' => 'high',
        'hide' => array(
            'template' => array( 'one-page-template.php' )
        ),
        'fields' => array(
            // heading
            array(
                'type' => 'heading',
                'id' => 'page_design_section',
                'name' => esc_html__( 'Page Responsive( 768px )', 'nt-landium' ),
            ),
            array(
                'name' => esc_html__( 'Disable background Image', 'nt-landium' ),
                'id' => $prefix . "disable_bg768",
                'desc' =>  sprintf( esc_html__( 'You can use this option to disable %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>768px</strong>' ),
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Add new background Image', 'nt-landium' ),
                'id' => $prefix . "page_bg_image768",
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the background image</strong>', '<strong>768px</strong>' ),
                'type' => 'image_advanced',
                'max_file_uploads' => 1,
            ),
            array(
                'name' => esc_html__( 'Page hero height', 'nt-landium' ),
                'id' => $prefix . "page_hero_height768",
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the hero height</strong>', '<strong>768px</strong>' ),
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
            array(
                'name' => esc_html__( 'Page hero text align', 'nt-landium' ),
                'id' => $prefix . "page_textalign_768",
                'type' => 'select',
                'options' => array(
                    'left' => esc_html__( 'left',  'nt-landium' ),
                    'right' => esc_html__( 'right', 'nt-landium' ),
                    'center' => esc_html__( 'center','nt-landium' ),
                ),
                'multiple' => false,
                'std' => '',
                'placeholder' => esc_html__( 'Select text align', 'nt-landium' ),
            ),
            array(
                'name' => esc_html__( 'Page title font-size', 'nt-landium' ),
                'id' => $prefix . "page_title_fs768",
                'desc' =>  sprintf( esc_html__( 'You can use this option to change %s while the width of the screen is max %s.', 'nt-landium' ), '<strong>the page title font size</strong>', '<strong>768px</strong>' ),
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
            array(
                'name' => esc_html__( 'Page hero padding top', 'nt-landium' ),
                'id' => "nt_landium_header_768_p_top",
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
            array(
                'name' => esc_html__( 'Page hero padding bottom', 'nt-landium' ),
                'id' => "nt_landium_header_768_p_bottom",
                'type' => 'number',
                'min' => 0,
                'step' => 1,
            ),
        )
    );

    // onepage metabox menu
    $meta_boxes[] = array(
        'title' => esc_html__( 'Metabox menu', 'nt-landium' ),
        'pages' => array( 'page' ),
        'clone-group' => 'onepage-clone-group','clone-group' => 'onepage-clone-group',
        'id' => 'page_menu',
        'context' => 'side',
        'priority' => 'low',
        'show' => array(
            'template' => array( 'one-page-template.php' )
        ),
        'fields' => array(
            array(
                'name' => esc_html__('Header menu type', 'nt-landium'),
                'desc' => esc_html__('Select header menu type', 'nt-landium'),
                'id' => $prefix . 'menutype',
                'type' => 'select',
                'options' => array(
                    'm' => esc_html__( 'Metabox menu', 'nt-landium' ),
                    'p' => esc_html__( 'Default Primary menu', 'nt-landium' ),
                ),
                'std' => 'm'
            ),
            array(
                'name' => esc_html__( 'Menu item name', 'nt-landium' ),
                'desc' => esc_html__( 'Format: Any text', 'nt-landium' ),
                'id' => $prefix . 'section_name',
                'type' => 'text',
                'std' => esc_html__( 'Menu item name', 'nt-landium' ),
                'class' => 'custom-class',
                'clone' => true,
                'sort_clone' => true,
                'clone-group' => 'onepage-clone-group',
            ),
            array(
                'name' => esc_html__( 'Menu item Url', 'nt-landium' ),
                'desc' => esc_html__( 'Format: #sectionname or http://yoururl.com', 'nt-landium' ),
                'id' => $prefix . 'section_url',
                'type' => 'text',
                'std' => esc_html__( '#sectionname', 'nt-landium' ),
                'class' => 'custom-class',
                'clone' => true,
                'sort_clone' => true,
                'clone-group' => 'onepage-clone-group',
            ),
        ),
    );

    /* ----------------------------------------------------- */
    // PRICE PLUGINS SETTINGS
    /* ----------------------------------------------------- */

    $meta_boxes[] = array(
        'id' => 'eventssettings',
        'title' => esc_html__('Price table', 'nt-landium'),
        'pages' => array( 'price' ),
        'context' => 'normal',
        'priority' => 'high',
        'fields' => array(
            array(
                'name' => esc_html__('Select featured pack', 'nt-landium'),
                'id' => $prefix . "bestpack",
                'type' => 'select',
                'options' => array(
                    'price-item__normal' => esc_html__( 'Normal Pack', 'nt-landium' ),
                    'price-item__active' => esc_html__( 'Best Pack', 'nt-landium' ),
                ),
                'multiple' => false,
                'std' => 'price-item__normal'
            ),
            array(
                'name' => esc_html__('Featured pack tag', 'nt-landium'),
                'id' => $prefix . "bestpacktag",
                'clone' => false,
                'type' => 'text',
                'std' => esc_html__( 'Sale', 'nt-landium' ),
            ),
            array(
                'name' => esc_html__('Select pack color', 'nt-landium'),
                'id' => $prefix . "packcolor",
                'desc' => esc_html__( 'This option is only for style 1 ( in shortcode Post options)', 'nt-landium' ),
                'type' => 'select',
                'options' => array(
                    'price-item__blue' => esc_html__( 'Blue', 'nt-landium' ),
                    'price-item__green' => esc_html__( 'Green', 'nt-landium' ),
                    'price-item__red' => esc_html__( 'Red', 	'nt-landium' ),
                    'price-item__yellow'=> esc_html__( 'Yellow', 'nt-landium' ),
                ),
                'multiple' => false,
                'std' => 'price-item__blue'
            ),
            array(
                'name' => esc_html__('Price pack name', 'nt-landium'),
                'id' => $prefix . "packname",
                'clone' => false,
                'type' => 'text',
                'std' => esc_html__( 'Standart', 'nt-landium' ),
            ),
            array(
                'name' => esc_html__('Currency', 'nt-landium'),
                'id' => $prefix . "currency",
                'clone' => false,
                'type' => 'text',
                'std' => '$'
            ),
            array(
                'name' => esc_html__('Price', 'nt-landium'),
                'id' => $prefix . "price",
                'clone' => false,
                'type' => 'text',
                'std' => '399'
            ),
            array(
                'name' => esc_html__('Small amount', 'nt-landium'),
                'id' => $prefix . "subprice",
                'clone' => false,
                'type' => 'text',
                'std' => '99'
            ),
            array(
                'name' => esc_html__('Period', 'nt-landium'),
                'id' => $prefix . "period",
                'clone' => false,
                'type' => 'text',
                'std' => 'per month'
            ),

            array(
                'name' => esc_html__('Table Features List', 'nt-landium'),
                'desc' => esc_html__( 'Add features for this pack', 'nt-landium' ),
                'id' => $prefix . 'features_list',
                'type' => 'text',
                'std' => esc_html__( 'Single user account', 'nt-landium' ),
                'class' => 'custom-class',
                'clone' => true,
                'clone-group' => 'my-clone-group','clone-group' => 'my-clone-group',
            ),
            array(
                'name' => esc_html__('Button Text', 'nt-landium'),
                'id' => $prefix . "btn_text",
                'clone' => false,
                'type' => 'text',
                'std' => 'Buy Now',
            ),
            array(
                'name' => esc_html__('Button URL', 'nt-landium'),
                'id' => $prefix . "btn_url",
                'clone' => false,
                'type' => 'text',
                'std' => '#0',
            ),
            array(
                'name' => esc_html__( 'Select target type', 'nt-landium' ),
                'name' => esc_html__('Select target type', 'nt-landium'),
                'id' => $prefix . "btn_target",
                'type' => 'select',
                'multiple' => false,
                'std' => '_blank',
                'options' => array(
                    '_blank' => '_blank',
                    '_self' => '_self',
                    '_parent' => '_parent',
                    '_top' => '_top',
                )
            ),

            // responsive opt

            array(
                'type' => 'divider',
                'id' => 'fake_divider_7', // Not used, but needed
            ),
            array(
                'name' => esc_html__( 'Mobile column size', 'nt-landium' ),
                'id' => $prefix . "column_mobile",
                'type' => 'select',
                'multiple' => false,
                'std' => 'col-sm-6',
                'options' => array(
                    '' => esc_html__( 'Select Custom Column', 'nt-landium' ),
                    'col-sm-1' => esc_html__( 'col-sm-1', 'nt-landium' ),
                    'col-sm-2' => esc_html__( 'col-sm-2', 'nt-landium' ),
                    'col-sm-3' => esc_html__( 'col-sm-3', 'nt-landium' ),
                    'col-sm-4' => esc_html__( 'col-sm-4', 'nt-landium' ),
                    'col-sm-5' => esc_html__( 'col-sm-5', 'nt-landium' ),
                    'col-sm-6' => esc_html__( 'col-sm-6', 'nt-landium' ),
                    'col-sm-7' => esc_html__( 'col-sm-7', 'nt-landium' ),
                    'col-sm-8' => esc_html__( 'col-sm-8', 'nt-landium' ),
                    'col-sm-9' => esc_html__( 'col-sm-9', 'nt-landium' ),
                    'col-sm-10' => esc_html__( 'col-sm-10', 'nt-landium' ),
                    'col-sm-11' => esc_html__( 'col-sm-11', 'nt-landium' ),
                    'col-sm-12' => esc_html__( 'col-sm-12', 'nt-landium' ),
                )
            ),
            array(
                'name' => esc_html__( 'Desktop column size', 'nt-landium' ),
                'id' => $prefix . "column_desk",
                'type' => 'select',
                'multiple' => false,
                'std' => 'col-md-3',
                'options' => array(
                    '' => esc_html__( 'Select Custom Column', 'nt-landium' ),
                    'col-md-1' => esc_html__( 'col-md-1', 'nt-landium' ),
                    'col-md-2' => esc_html__( 'col-md-2', 'nt-landium' ),
                    'col-md-3' => esc_html__( 'col-md-3', 'nt-landium' ),
                    'col-md-4' => esc_html__( 'col-md-4', 'nt-landium' ),
                    'col-md-5' => esc_html__( 'col-md-5', 'nt-landium' ),
                    'col-md-6' => esc_html__( 'col-md-6', 'nt-landium' ),
                    'col-md-7' => esc_html__( 'col-md-7', 'nt-landium' ),
                    'col-md-8' => esc_html__( 'col-md-8', 'nt-landium' ),
                    'col-md-9' => esc_html__( 'col-md-9', 'nt-landium' ),
                    'col-md-10' => esc_html__( 'col-md-10', 'nt-landium' ),
                    'col-md-11' => esc_html__( 'col-md-11', 'nt-landium' ),
                    'col-md-12' => esc_html__( 'col-md-12', 'nt-landium' ),
                )
            ),
            array(
                'name' => esc_html__( 'Column offset size for desktop', 'nt-landium' ),
                'id' => $prefix . "column_offset",
                'type' => 'select',
                'multiple' => false,
                'std' => 'col-md-offset-0',
                'options' => array(
                    '' => esc_html__( 'Select Column offset', 'nt-landium' ),
                    'col-md-offset-0' => esc_html__( 'offset-0', 'nt-landium' ),
                    'col-md-offset-1' => esc_html__( 'offset-1', 'nt-landium' ),
                    'col-md-offset-2' => esc_html__( 'offset-2', 'nt-landium' ),
                    'col-md-offset-3' => esc_html__( 'offset-3', 'nt-landium' ),
                    'col-md-offset-4' => esc_html__( 'offset-4', 'nt-landium' ),
                    'col-md-offset-5' => esc_html__( 'offset-5', 'nt-landium' ),
                    'col-md-offset-6' => esc_html__( 'offset-6', 'nt-landium' ),
                    'col-md-offset-7' => esc_html__( 'offset-7', 'nt-landium' ),
                    'col-md-offset-8' => esc_html__( 'offset-8', 'nt-landium' ),
                    'col-md-offset-9' => esc_html__( 'offset-9', 'nt-landium' ),
                    'col-md-offset-10' => esc_html__( 'offset-10', 'nt-landium' ),
                    'col-md-offset-11' => esc_html__( 'offset-11', 'nt-landium' ),
                    'col-md-offset-12' => esc_html__( 'offset-12', 'nt-landium' ),
                )
            ),

        )
    );

    /* ----------------------------------------------------- */
    // TEAM PLUGINS SETTINGS
    /* ----------------------------------------------------- */

    $meta_boxes[] = array(
        'title' => esc_html__( 'Team Details', 'nt-landium' ),
        'pages' => array( 'team' ),
        'clone-group' => 'my-clone-group',
        'id' => 'mm_review',
        'context' => 'normal',
        'priority' => 'high',
        'fields' => array(

            array(
                'name' => esc_html__('Team Job', 'nt-landium'),
                'id' => $prefix . "team_job",
                'clone' => false,
                'type' => 'text',
                'std' => 'Developer'
            ),
            array(
                'name' => esc_html__('Social Icon Name', 'nt-landium'),
                'desc' => esc_html__('Format: fa fa-facebook or fonticon class name. Enter social icon name here', 'nt-landium'),
                'id' => $prefix . 'social_icon',
                'type' => 'text',
                'std' => 'facebook',
                'class' => 'custom-class',
                'clone' => true,
                'clone-group' => 'my-clone-group',
            ),

            array(
                'name' => esc_html__('Social Url', 'nt-landium'),
                'desc' => esc_html__('Format: http://facebook.com', 'nt-landium'),
                'id' => $prefix . 'social_url',
                'type' => 'text',
                'std' => '#',
                'class' => 'custom-class',
                'clone' => true,
                'clone-group' => 'my-clone-group',
            ),
            array(
                'name' => esc_html__( 'Select target type', 'nt-landium' ),
                'name' => esc_html__('Select target type', 'nt-landium'),
                'id' => $prefix . "social_target",
                'type' => 'select',
                'multiple' => false,
                'std' => '_blank',
                'options' => array(
                    '_blank' => '_blank',
                    '_self' => '_self',
                    '_parent' => '_parent',
                    '_top' => '_top',
                )
            ),
            array(
                'name' => esc_html__('Team Item Link', 'nt-landium'),
                'id' => $prefix . "team_link",
                'clone' => false,
                'type' => 'text',
                'std' => '#0'
            ),
            array(
                'name' => esc_html__( 'Select target type', 'nt-landium' ),
                'name' => esc_html__('Select target type', 'nt-landium'),
                'id' => $prefix . "link_target",
                'type' => 'select',
                'multiple' => false,
                'std' => '_blank',
                'options' => array(
                    '_blank' => '_blank',
                    '_self' => '_self',
                    '_parent' => '_parent',
                    '_top' => '_top',
                )
            ),
            array(
                'type' => 'divider',
                'id' => 'fake_divider_7', // Not used, but needed
            ),
            array(
                'name' => esc_html__( 'Mobile column size', 'nt-landium' ),
                'id' => $prefix . "column_mobile",
                'type' => 'select',
                'multiple' => false,
                'std' => 'col-sm-6',
                'options' => array(
                    '' => esc_html__( 'Select Custom Column', 'nt-landium' ),
                    'col-sm-1' => esc_html__( 'col-sm-1', 'nt-landium' ),
                    'col-sm-2' => esc_html__( 'col-sm-2', 'nt-landium' ),
                    'col-sm-3' => esc_html__( 'col-sm-3', 'nt-landium' ),
                    'col-sm-4' => esc_html__( 'col-sm-4', 'nt-landium' ),
                    'col-sm-5' => esc_html__( 'col-sm-5', 'nt-landium' ),
                    'col-sm-6' => esc_html__( 'col-sm-6', 'nt-landium' ),
                    'col-sm-7' => esc_html__( 'col-sm-7', 'nt-landium' ),
                    'col-sm-8' => esc_html__( 'col-sm-8', 'nt-landium' ),
                    'col-sm-9' => esc_html__( 'col-sm-9', 'nt-landium' ),
                    'col-sm-10' => esc_html__( 'col-sm-10', 'nt-landium' ),
                    'col-sm-11' => esc_html__( 'col-sm-11', 'nt-landium' ),
                    'col-sm-12' => esc_html__( 'col-sm-12', 'nt-landium' ),
                )
            ),
            array(
                'name' => esc_html__( 'Desktop column size', 'nt-landium' ),
                'id' => $prefix . "column_desk",
                'type' => 'select',
                'multiple' => false,
                'std' => 'col-md-3',
                'options' => array(
                    '' => esc_html__( 'Select Custom Column', 'nt-landium' ),
                    'col-md-1' => esc_html__( 'col-md-1', 'nt-landium' ),
                    'col-md-2' => esc_html__( 'col-md-2', 'nt-landium' ),
                    'col-md-3' => esc_html__( 'col-md-3', 'nt-landium' ),
                    'col-md-4' => esc_html__( 'col-md-4', 'nt-landium' ),
                    'col-md-5' => esc_html__( 'col-md-5', 'nt-landium' ),
                    'col-md-6' => esc_html__( 'col-md-6', 'nt-landium' ),
                    'col-md-7' => esc_html__( 'col-md-7', 'nt-landium' ),
                    'col-md-8' => esc_html__( 'col-md-8', 'nt-landium' ),
                    'col-md-9' => esc_html__( 'col-md-9', 'nt-landium' ),
                    'col-md-10' => esc_html__( 'col-md-10', 'nt-landium' ),
                    'col-md-11' => esc_html__( 'col-md-11', 'nt-landium' ),
                    'col-md-12' => esc_html__( 'col-md-12', 'nt-landium' ),
                )
            ),
            array(
                'name' => esc_html__( 'Column offset size for desktop', 'nt-landium' ),
                'id' => $prefix . "column_offset",
                'type' => 'select',
                'multiple' => false,
                'std' => 'col-md-offset-0',
                'options' => array(
                    '' => esc_html__( 'Select Column offset', 'nt-landium' ),
                    'col-md-offset-0' => esc_html__( 'offset-0', 'nt-landium' ),
                    'col-md-offset-1' => esc_html__( 'offset-1', 'nt-landium' ),
                    'col-md-offset-2' => esc_html__( 'offset-2', 'nt-landium' ),
                    'col-md-offset-3' => esc_html__( 'offset-3', 'nt-landium' ),
                    'col-md-offset-4' => esc_html__( 'offset-4', 'nt-landium' ),
                    'col-md-offset-5' => esc_html__( 'offset-5', 'nt-landium' ),
                    'col-md-offset-6' => esc_html__( 'offset-6', 'nt-landium' ),
                    'col-md-offset-7' => esc_html__( 'offset-7', 'nt-landium' ),
                    'col-md-offset-8' => esc_html__( 'offset-8', 'nt-landium' ),
                    'col-md-offset-9' => esc_html__( 'offset-9', 'nt-landium' ),
                    'col-md-offset-10' => esc_html__( 'offset-10', 'nt-landium' ),
                    'col-md-offset-11' => esc_html__( 'offset-11', 'nt-landium' ),
                    'col-md-offset-12' => esc_html__( 'offset-12', 'nt-landium' ),
                )
            ),


        )
    );
    $meta_boxes[] = array(
        'id' => 'portfoliosettings',
        'title' => 'Portfolio Custom Options',
        'pages' => array( 'portfolio' ),
        'context' => 'normal',
        'priority' => 'high',
        'fields' => array(
            array(
                'name' => esc_html__( 'Select image link type', 'nt-landium' ),
                'id' => $prefix . "image_link_type",
                'type' => 'select',
                'desc' => esc_html__( 'The Default Lightbox option for to enable Lightbox and Custom Link option for your custom URL', 'nt-landium' ),
                'options' => array(
                    'default' => 'Default Lightbox',
                    'custom' => 'Custom Link'
                ),
                'multiple' => false,
                'std' => 'default'
            ),
            array(
                'name' => esc_html__( 'Custom external link', 'nt-landium' ),
                'id' => $prefix . "custom_link_url",
                'clone' => false,
                'desc' => esc_html__( 'This option is compatible only Custom Link option.Format : http://facebook.com', 'nt-landium' ),
                'type' => 'text',
                'std' => '#'
            ),
            array(
                'name' => esc_html__( 'Select target type', 'nt-landium' ),
                'id' => $prefix . "custom_target",
                'type' => 'select',
                'desc' => esc_html__( 'This option is compatible only Custom Link option', 'nt-landium' ),
                'multiple' => false,
                'std' => '_blank',
                'options' => array(
                    '_blank' => '_blank',
                    '_self' => '_self',
                    '_parent' => '_parent',
                    '_top' => '_top'
                )
            )
        )
    );

    /*-----------------------------------------------------------------------------------*/
    /*  Metaboxes for blog posts
    /*-----------------------------------------------------------------------------------*/

    /* Gallery Post Format ------------*/
    $meta_boxes[] = array(
        'title' => esc_html__('Gallery Settings', 'nt-landium'),
        'pages' => array('post'),
        'fields' => array(
            array(
                'name' => esc_html__('Select Images', 'nt-landium'),
                'desc' => esc_html__('Select the images from the media library or upload your new ones.', 'nt-landium'),
                'id' => $prefix . 'gallery_image',
                'type' => 'image_advanced',
            )
        )
    );

    /* Quote Post Format ------------*/
    $meta_boxes[] = array(
        'title' => esc_html__('Quote Settings', 'nt-landium'),
        'pages' => array('post'),
        'fields' => array(
            array(
                'name' => esc_html__('The Quote', 'nt-landium'),
                'desc' => esc_html__('Write your quote in this field.', 'nt-landium'),
                'id' => $prefix . 'quote_text',
                'type' => 'textarea',
                'rows' => 5
            ),
            array(
                'name' => esc_html__('The Author', 'nt-landium'),
                'desc' => esc_html__('Enter the name of the author of this quote.', 'nt-landium'),
                'id' => $prefix . 'quote_author',
                'type' => 'text'
            ),
            array(
                'name' => esc_html__('Background Color', 'nt-landium'),
                'desc' => esc_html__('Choose the background color for this quote.', 'nt-landium'),
                'id' => $prefix . 'quote_bg',
                'type' => 'color'
            ),
            array(
                'name' => esc_html__('Background Opacity', 'nt-landium'),
                'desc' => esc_html__('Choose the opacity of the background color.', 'nt-landium'),
                'id' => $prefix . 'quote_bg_opacity',
                'type' => 'text',
                'std' => 80
            )
        )
    );

    /* Audio Post Format ------------*/
    $meta_boxes[] 	= array(
        'title' => esc_html__('Audio Settings', 'nt-landium'),
        'pages' => array('post'),
        'fields' => array(
            array(
                'type' => 'heading',
                'name' => esc_html__( 'These settings enable you to embed audio in your posts. Note that for audio, you must supply both MP3 and OGG files to satisfy all browsers. For poster you can select a featured image.', 'nt-landium' ),
                'id' => 'audio_head'
            ),
            array(
                'name' => esc_html__('MP3 File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .mp3 audio file.', 'nt-landium'),
                'id' => $prefix . 'audio_mp3',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('OGA File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .oga, .ogg audio file.', 'nt-landium'),
                'id' => $prefix . 'audio_ogg',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Divider', 'nt-landium'),
                'desc' => esc_html__('divider.', 'nt-landium'),
                'id' => $prefix . 'audio_divider',
                'type' => 'divider'
            ),
            array(
                'name' => esc_html__('SoundCloud', 'nt-landium'),
                'desc' => esc_html__('Enter the url of the soundcloud audio.', 'nt-landium'),
                'id' => $prefix . 'audio_sc',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Color', 'nt-landium'),
                'desc' => esc_html__('Choose the color.', 'nt-landium'),
                'id' => $prefix . 'audio_sc_color',
                'type' => 'color',
                'std' => '#ff7700'
            )
        )
    );

    /* Video Post Format ------------*/
    $meta_boxes[] = array(
        'title' => esc_html__('Video Settings', 'nt-landium'),
        'pages' => array('post'),
        'fields' => array(
            array(
                'type' => 'heading',
                'name' => esc_html__( 'These settings enable you to embed videos into your posts. Note that for video, you must supply an M4V file to satisfy both HTML5 and Flash solutions. The optional OGV format is used to increase x-browser support for HTML5 browsers such as Firefox and Opera. For the poster, you can select a featured image.', 'nt-landium' ),
                'id' => 'video_head'
            ),
            array(
                'name' => esc_html__('M4V File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .m4v video file.', 'nt-landium'),
                'id' => $prefix . 'video_m4v',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('OGV File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .ogv video file.', 'nt-landium'),
                'id' => $prefix . 'video_ogv',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('WEBM File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .webm video file.', 'nt-landium'),
                'id' => $prefix . 'video_webm',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Embeded Code', 'nt-landium'),
                'desc' => esc_html__('Select the preview image for this video.', 'nt-landium'),
                'id' => $prefix . 'video_embed',
                'type' => 'textarea',
                'rows' => 8
            )
        )
    );
    //Social Share Settings
    $meta_boxes[] = array(
        'title' => esc_html__('Social Share Settings', 'nt-landium'),
        'pages' => array('post'),
        'fields' => array(
            array(
                'name' => esc_html__('Show Social Share Icons', 'nt-landium'),
                'desc' => esc_html__('Check this to show or hide all social share icons.', 'nt-landium'),
                'id' => $prefix . 'show_share',
                'type' => 'select',
                'options' => array(
                    'show' => esc_html__( 'Yes', 'nt-landium' ),
                    'hide' => esc_html__( 'No', 'nt-landium' ),
                ),
                'multiple' => false,
                'std' => 'Yes'
            ),
            array(
                'name' => esc_html__( 'Disable facebook ?', 'nt-landium' ),
                'id' => 'nt_sawmill_share_face_display',
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Disable twitter ?', 'nt-landium' ),
                'id' => 'nt_sawmill_share_twitter_display',
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Disable google-plus ?', 'nt-landium' ),
                'id' => 'nt_sawmill_share_google_display',
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Disable digg ?', 'nt-landium' ),
                'id' => 'nt_sawmill_share_digg_display',
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Disable reddit ?', 'nt-landium' ),
                'id' => 'nt_sawmill_share_reddit_display',
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Disable linkedin ?', 'nt-landium' ),
                'id' => 'nt_sawmill_share_linkedin_display',
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Disable stumbleupon ?', 'nt-landium' ),
                'id' => 'nt_sawmill_share_stumbleupon_display',
                'type' => 'checkbox',
                'std' => 0,
            ),
            array(
                'name' => esc_html__( 'Disable pinterest ?', 'nt-landium' ),
                'id' => 'nt_sawmill_share_pinterest_display',
                'type' => 'checkbox',
                'std' => 0,
            ),
        )
    );

    /*-----------------------------------------------------------------------------------*/
    /*  Metaboxes for portfolio
    /*-----------------------------------------------------------------------------------*/

    /* Gallery Post Format ------------*/
    $meta_boxes[] = array(
        'title' => esc_html__('Gallery Settings', 'nt-landium'),
        'pages' => array('portfolio'),
        'fields' => array(
            array(
                'name' => esc_html__('Select Images', 'nt-landium'),
                'desc' => esc_html__('Select the images from the media library or upload your new ones.', 'nt-landium'),
                'id' => $prefix . 'gallery_image',
                'type' => 'image_advanced',
            )
        )
    );

    /* Audio Post Format ------------*/
    $meta_boxes[] = array(
        'title' => esc_html__('Audio Settings', 'nt-landium'),
        'pages' => array('portfolio'),
        'fields' => array(
            array(
                'type' => 'heading',
                'name' => esc_html__( 'These settings enable you to embed audio in your posts. Note that for audio, you must supply both MP3 and OGG files to satisfy all browsers. For poster you can select a featured image.', 'nt-landium' ),
                'id' => 'audio_head'
            ),
            array(
                'name' => esc_html__('MP3 File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .mp3 audio file.', 'nt-landium'),
                'id' => $prefix . 'audio_mp3',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('OGA File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .oga, .ogg audio file.', 'nt-landium'),
                'id' => $prefix . 'audio_ogg',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Divider', 'nt-landium'),
                'desc' => esc_html__('divider.', 'nt-landium'),
                'id' => $prefix . 'audio_divider',
                'type' => 'divider'
            ),
            array(
                'name' => esc_html__('SoundCloud', 'nt-landium'),
                'desc' => esc_html__('Enter the url of the soundcloud audio.', 'nt-landium'),
                'id' => $prefix . 'audio_sc',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Color', 'nt-landium'),
                'desc' => esc_html__('Choose the color.', 'nt-landium'),
                'id' => $prefix . 'audio_sc_color',
                'type' => 'color',
                'std' => '#ff7700'
            )
        )
    );

    /* Video Post Format ------------*/
    $meta_boxes[] = array(
        'title' => esc_html__('Video Settings', 'nt-landium'),
        'pages' => array('portfolio'),
        'fields' => array(
            array(
                'type' => 'heading',
                'name' => esc_html__( 'These settings enable you to embed videos into your posts. Note that for video, you must supply an M4V file to satisfy both HTML5 and Flash solutions. The optional OGV format is used to increase x-browser support for HTML5 browsers such as Firefox and Opera. For the poster, you can select a featured image.', 'nt-landium' ),
                'id' => 'video_head'
            ),
            array(
                'name' => esc_html__('M4V File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .m4v video file.', 'nt-landium'),
                'id' => $prefix . 'video_m4v',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('OGV File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .ogv video file.', 'nt-landium'),
                'id' => $prefix . 'video_ogv',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('WEBM File URL', 'nt-landium'),
                'desc' => esc_html__('The URL to the .webm video file.', 'nt-landium'),
                'id' => $prefix . 'video_webm',
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Embeded Code', 'nt-landium'),
                'desc' => esc_html__('Select the preview image for this video.', 'nt-landium'),
                'id' => $prefix . 'video_embed',
                'type' => 'textarea',
                'rows' => 8
            )
        )
    );
    //end
    return $meta_boxes;
}

?>
