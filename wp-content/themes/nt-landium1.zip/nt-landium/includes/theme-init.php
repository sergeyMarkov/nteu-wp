<?php
/**
*
* @package WordPress
* @subpackage nt_landium
* @since nt_landium 1.0
*
*/


/*************************************************
## Google Font
*************************************************/

if ( ! function_exists( 'nt_landium_fonts_url' ) ) {
    function nt_landium_fonts_url()
    {
        $fonts_url = '';

        $raleway = _x( 'on', 'Raleway font: on or off', 'nt-landium' );
        $roboto = _x( 'on', 'Roboto font: on or off', 'nt-landium' );

        if ( 'off' !== $raleway || 'off' !== $roboto ) {
            $font_families = array();

            if ( 'off' !== $raleway )
            $font_families[] = 'Raleway:300,300i,400,400i,700,700i';

            if ( 'off' !== $roboto )
            $font_families[] = 'Roboto:300,300i,400,400i,700,700i';

            $query_args = array(
                'family' => urlencode( implode( '|', $font_families ) ),
                'subset' => urlencode( 'latin,latin-ext' ),
            );
            $fonts_url = add_query_arg( $query_args, "//fonts.googleapis.com/css" );
        }
        return $fonts_url;
    }
}

/*************************************************
## Styles and Scripts
*************************************************/

function nt_landium_scripts()
{
    $rtl = is_rtl() ? '-rtl' : '';

    if ( is_singular() ) wp_enqueue_script( 'comment-reply' );

    // general css file
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css', false, '1.0');
    wp_enqueue_style('animate', get_template_directory_uri() . '/css/animate.css', false, '1.0' );
    wp_enqueue_style('nt-landium-main-style', get_template_directory_uri() . '/css/main-style'.$rtl.'.css', false, '1.0');
    wp_enqueue_style('bootstrap', get_template_directory_uri() . '/css/bootstrap'.$rtl.'.min.css', false, '1.0');
    wp_enqueue_style('nt-landium-theme', get_template_directory_uri() . '/css/nt-landium-theme'.$rtl.'.css', false, '1.0');
    wp_enqueue_style('izimodal', get_template_directory_uri() . '/css/izimodal.css', false, '1.0');
    // visual composer css for homepage
    wp_enqueue_style('nt-landium-vc', get_template_directory_uri() . '/css/visual-composer.css', false, '1.0');
    // flexslider css file for blog post
    wp_enqueue_style('nt-landium-custom-flexslider', get_template_directory_uri() . '/js/flexslider/flexslider.css', false, '1.0');
    // wordpress css file for blog post
    wp_enqueue_style('nt-landium-wordpress', get_template_directory_uri() . '/css/wordpress'.$rtl.'.css', false, '1.0');
    // update css file
    wp_enqueue_style('nt-landium-update', get_template_directory_uri() . '/css/update'.$rtl.'.css', false, '1.0');
    // theme default google webfont loader
    wp_enqueue_style('nt-landium-fonts-load', nt_landium_fonts_url(), array(), '1.0.0' );

    // custom css
    wp_enqueue_style( 'nt-landium-custom-style', 		get_stylesheet_uri() );
    wp_enqueue_style('style', get_stylesheet_uri() );

    // JS files
    wp_register_script('particleground', get_template_directory_uri() . '/js/jquery.particleground.min.js', array('jquery'), '1.0', true);
    wp_enqueue_script('device', get_template_directory_uri() . '/js/device.js', array('jquery'), '1.0', true);
    wp_enqueue_script('nicescroll', get_template_directory_uri() . '/js/jquery.nicescroll.min.js', array('jquery'), '1.0', true);
    wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/js/owl.carousel.min.js', array('jquery'), '1.0', true);
    wp_enqueue_script('stellar', get_template_directory_uri() . '/js/jquery.stellar.min.js', array('jquery'), '1.0', true);
    wp_enqueue_script('matchHeight', get_template_directory_uri() . '/js/jquery.matchHeight-min.js',	array('jquery'), '1.0', true);
    wp_enqueue_script('fs-boxer', get_template_directory_uri() . '/js/jquery.fs.boxer.min.js', array('jquery'), '1.0', true);
    wp_enqueue_script('izimodal', get_template_directory_uri() . '/js/izimodal.min.js', array('jquery'), '1.0', true);
    wp_enqueue_script('bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), '1.0', true);
    wp_enqueue_script( 'wow', get_template_directory_uri() . '/js/wow.min.js', array('jquery'), '1.0', true );
    wp_enqueue_script('nt-landium-main', get_template_directory_uri() . '/js/main.js', array('jquery'), '1.0', true);
    wp_localize_script('nt-landium-main', 'prefix',array( 'showmenu' => ot_get_option( 'nt_landium_showmenu' ) ) );

    if ( ot_get_option('nt_landium_map_display') != 'off') {
        // Google maps api & customization
        $nt_landium_map_api_key = ot_get_option( 'nt_landium_map_api_key' );
        $nt_landium_map_api_key_out = ( $nt_landium_map_api_key != '') ? '' .  $nt_landium_map_api_key  . '' : '';
        wp_register_script( 'google-map-api',  'https://maps.googleapis.com/maps/api/js?key='. $nt_landium_map_api_key_out .'', '3.0.0', true);
        wp_register_script( 'nt-landium-google-map', get_template_directory_uri() . '/js/map.js', array('jquery'), '1.0', true);
    }

    // WP default scripts for theme
    wp_register_script('nt-landium-custom-flexslider', get_template_directory_uri() . '/js/jquery.flexslider.js', array('jquery'), '1.0', true);
    wp_register_script('fitvids', get_template_directory_uri() . '/js/jquery.fitvids.js', array('jquery'), '1.0', true);
    wp_register_script('nt-landium-blog-settings', get_template_directory_uri() . '/js/blog-settings.js', array('jquery'), '1.0', true);

    // HTML5, devices and browsers support
    wp_enqueue_script('nt-landium-device', get_template_directory_uri() . '/js/device.min.js', array('jquery'), '1.0', false);
    wp_enqueue_script('nt-landium-modernizr-custom', get_template_directory_uri() . '/js/modernizr.custom.min.js', 	array('jquery'), '2.7.1', false );
    wp_script_add_data('nt-landium-modernizr-custom', 'conditional', 'lt IE 9' );

    wp_enqueue_script('respond', get_template_directory_uri() . '/js/respond.min.js', array('jquery'), '1.4.2', false );
    wp_script_add_data('respond', 'conditional', 'lt IE 9' );
}
add_action( 'wp_enqueue_scripts', 'nt_landium_scripts' );



/*************************************************
## Admin style and scripts
*************************************************/

function nt_landium_admin_style() {

    // Update CSS within in Admin
    wp_enqueue_style('nt-landium-custom-admin', get_template_directory_uri().'/css/admin.css');
    wp_enqueue_script('nt-landium-custom-admin', get_template_directory_uri() . '/js/jquery.custom.admin.js');

}
add_action('admin_enqueue_scripts', 'nt_landium_admin_style');


/*************************************************
## Theme option & Metaboxes & shortcodes
*************************************************/

// theme homepage visual composer shortcodes settings
if ( function_exists( 'vc_set_as_theme' ) ) {
    require_once get_template_directory() . '/includes/visual-shortcodes.php';
}

// Metabox plugin check
if ( ! function_exists( 'rwmb_meta' ) ) {
    function rwmb_meta( $key, $args = '', $post_id = null )
    {
        return false;
    }
}
// Theme post and page meta plugin for customization and more features
require_once get_template_directory() . '/includes/page-metaboxes.php';

// Some theme functions
require_once get_template_directory() . '/includes/template-parts.php';

// Theme css setting file
require_once get_template_directory() . '/includes/custom-style.php';

// Theme navigation and pagination options
require_once get_template_directory() . '/includes/template-tags.php';

// Option tree controllers
if ( ! class_exists( 'OT_Loader' ) ) {

    function ot_get_option()
    {
        return false;
    }

}

// add filter for  options panel loader
add_filter( 'ot_show_pages', '__return_false' );
add_filter( 'ot_show_new_layout', '__return_false' );

// Theme options admin panel setings file
include_once get_template_directory() . '/includes/theme-options.php';

// Theme customize css setting file
require_once get_template_directory() . '/includes/custom-style.php';


/*************************************************
## Theme Setup
*************************************************/

if ( ! isset( $content_width ) ) $content_width = 960;

function nt_landium_theme_setup()
{

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    /*
    * Enable support for Post Thumbnails on posts and pages.
    *
    * See: https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
    */
    add_theme_support( 'post-thumbnails' );

    // Theme customizer and tag support
    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-background' );
    add_theme_support( 'custom-header' );

    // WooCommerce
    if ( class_exists( 'woocommerce' ) ) {
        add_theme_support( 'woocommerce' );
        add_theme_support( 'wc-product-gallery-zoom' );
        add_theme_support( 'wc-product-gallery-lightbox' );
        add_theme_support( 'wc-product-gallery-slider' );
    }

    /*
    * Enable support for Post Formats.
    *
    * See: https://codex.wordpress.org/Post_Formats
    */
    add_theme_support( 'post-formats', array('gallery', 'quote', 'video', 'audio'));
    add_post_type_support( 'portfolio', 'post-formats' );
    add_image_size( 'nt_landium_member_thumb', 650, 650, true);

    // Make theme available for translation
    // Translations can be filed in the /languages/ directory
    load_theme_textdomain( 'nt-landium', get_template_directory() . '/languages' );

    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'nt-landium' ),
        'primary-menu-2' => esc_html__( 'Secondary Header Menu', 'nt-landium' ),
    ) );
}
add_action( 'after_setup_theme', 'nt_landium_theme_setup' );

/*************************************************
## Widget columns
*************************************************/
if ( ! function_exists( 'nt_landium_widgets_init' ) ) {
    function nt_landium_widgets_init()
    {
        register_sidebar( array(
            'name' => esc_html__( 'Blog Sidebar Area', 'nt-landium' ),
            'id' => 'sidebar-1',
            'description' => esc_html__( 'These are widgets for the blog page.','nt-landium' ),
            'before_widget' => '<div class="widget  %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h4 class="widget-title"><span>',
            'after_title' => '</span></h4>'
        ) );
        register_sidebar( array(
            'name' => esc_html__( 'Footer Widgetize Area', 'nt-landium' ),
            'id' => 'nt-landium-footer-widgetize',
            'description' => esc_html__( 'Theme footer widgetize area','nt-landium' ),
            'before_widget' => '<div class="col-md-3"><div class="widget %2$s">',
            'after_widget' => '</div></div>',
            'before_title' => '<h3 class="widget-head">',
            'after_title' => '</h3>'
        ) );
        register_sidebar( array(
            'name' => esc_html__( 'Footer Newsletter Area', 'nt-landium' ),
            'id' => 'nt-landium-footer-news',
            'description' => esc_html__( 'Theme footer default area','nt-landium' ),
            'before_widget' => '<div class="foot-news">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-head">',
            'after_title' => '</h3>'
        ) );
    }
}
add_action( 'widgets_init', 'nt_landium_widgets_init' );

/*************************************************
## Include the TGM_Plugin_Activation class.
*************************************************/

require_once get_template_directory() . '/includes/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register', 'nt_landium_register_required_plugins' );

function nt_landium_register_required_plugins()
{
    $plugins = array(
        array(
            'name' => esc_html__('Breadcrumb NavXT', "nt-landium"),
            'slug' => 'breadcrumb-navxt',
        ),
        array(
            'name' => esc_html__('Contact Form 7', "nt-landium"),
            'slug' => 'contact-form-7',
        ),
        array(
            'name' => esc_html__('Meta Box', "nt-landium"),
            'slug' => 'meta-box',
            'required' => true,
        ),
        array(
            'name' => esc_html__('Theme Options Panel', "nt-landium"),
            'slug' => 'option-tree',
            'required' => true,
        ),
        array(
            'name' => esc_html__('Portfolio Posts', "nt-landium"),
            'slug' => 'portfolio-post-type',
        ),
        array(
            'name' => esc_html__('Team post type', 'nt-landium'),
            'slug' => 'team-post-type',
            'source' => 'https://ninetheme.com/documentation/plugins/team-post-type.zip',
            'required' => false,
        ),
        array(
            'name' => esc_html__('Price Tables', 'nt-landium'),
            'slug' => 'price-table-type',
            'source' => 'https://ninetheme.com/documentation/plugins/price-table-type.zip',
            'required' => false,
        ),
        array(
            'name' => esc_html__('Metabox Tabs', "nt-landium"),
            'slug' => 'meta-box-tabs',
            'source' => 'https://ninetheme.com/documentation/plugins/meta-box-tabs.zip',
            'required' => true,
            'version' => '1.1.5',
        ),
        array(
            'name' => esc_html__('Metabox Show/Hide', "nt-landium"),
            'slug' => 'meta-box-show-hide',
            'source' => 'https://ninetheme.com/documentation/plugins/meta-box-show-hide.zip',
            'required' => true,
            'version' => '1.3',
        ),
        array(
            'name' => esc_html__('Envato Auto Update Theme', "nt-landium"),
            'slug' => 'envato-market',
            'source' => 'https://ninetheme.com/documentation/plugins/envato-market.zip',
            'required' => false,
            'version' => '2.0.3',
        ),
        array(
            'name' => esc_html__('Page Builder', "nt-landium"),
            'slug' => 'js_composer',
            'source' => 'https://ninetheme.com/documentation/plugins/js_composer.zip',
            'required' => true,
        ),
        array(
            'name' => esc_html__('Revolution Slider', "nt-landium"),
            'slug' => 'revslider',
            'source' => 'https://ninetheme.com/documentation/plugins/revslider.zip',
            'required' => false,
        ),
        array(
            'name' => esc_html__('WP Landium Shortcodes', "nt-landium"),
            'slug' => 'nt-landium-shortcodes',
            'source' => get_template_directory() . '/plugins/nt-landium-shortcodes.zip',
            'required' => true,
            'version' => '1.5.7',
        ),
    );

    $config = array(
        'id' => 'tgmpa',
        'default_path' => '',
        'menu' => 'tgmpa-install-plugins',
        'parent_slug' => apply_filters( 'ninetheme_parent_slug', 'themes.php' ),
        'has_notices' => true,
        'dismissable' => true,
        'dismiss_msg' => '',
        'is_automatic' => true,
        'message' => '',
    );

    tgmpa( $plugins, $config );
}

if ( ! function_exists( 'nt_landium_custom_body_class' ) ) {
    function nt_landium_custom_body_class($classes)
    {

        $theme_name =  'ninetheme-theme-name-' . wp_get_theme();
        $theme_version =  'theme-version-' . wp_get_theme()->get( 'Version' );
        $classes[] = 'home';
        $classes[] =  $theme_name;
        $classes[] =  $theme_version;

        return $classes;

    }
}
add_filter('body_class','nt_landium_custom_body_class');


/*************************************************
## Register Menu
*************************************************/
if ( ! class_exists( 'Nt_Landium_Wp_Bootstrap_Navwalker' ) ) {
    class Nt_Landium_Wp_Bootstrap_Navwalker extends Walker_Nav_Menu
    {
        /**
        * @see Walker::start_lvl()
        * @since 3.0.0
        */
        public function start_lvl( &$output, $depth = 0, $args = array() )
        {
            $indent = str_repeat( "\t", $depth );
            $output .= "\n$indent<ul role=\"menu\" class=\"sub-menu dropdown-menu\">\n";
        }

        /**
        * @see Walker::start_el()
        * @since 3.0.0
        */
        public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 )
        {
            $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

            /**
            * Dividers, Headers or Disabled
            */
            if ( strcasecmp( $item->attr_title, 'divider' ) == 0 && $depth === 1 ) {
                $output .= $indent . '<li role="presentation" class="divider item-has-children">';
            } else if ( strcasecmp( $item->title, 'divider') == 0 && $depth === 1 ) {
                $output .= $indent . '<li role="presentation" class="divider item-has-children">';
            } else if ( strcasecmp( $item->attr_title, 'dropdown-header item-has-children') == 0 && $depth === 1 ) {
                $output .= $indent . '<li role="presentation" class="dropdown-header item-has-children">' . esc_attr( $item->title );
            } else if ( strcasecmp($item->attr_title, 'disabled' ) == 0 ) {
                $output .= $indent . '<li role="presentation" class="disabled"><a href="#">' . esc_attr( $item->title ) . '</a>';
            } else {

                $class_names = $value = '';

                $classes = empty( $item->classes ) ? array() : (array) $item->classes;
                $classes[] = 'menu-item-' . $item->ID;

                $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );

                if ( $args->has_children )
                $class_names .= 'sub item-has-children';

                if ( in_array( 'current-menu-item', $classes ) || in_array( 'current_page_parent', $classes ) )
                $class_names .= !is_page() ? ' active': '';

                $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

                $id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args );
                $id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

                $output .= $indent . '<li' . $id . $value . $class_names .'>';

                $atts = array();
                $atts['title']  = ! empty( $item->title )	? $item->title	: '';
                $atts['target'] = ! empty( $item->target )	? $item->target	: '';
                $atts['rel']    = ! empty( $item->xfn )		? $item->xfn	: '';

                // If item has_children add atts to a.
                if ( $args->has_children && $depth === 0 ) {
                    $atts['href']        = $item->url;
                    $atts['data-toggle'] = 'dropdown';
                    $atts['class']       = 'dropdown-toggle';
                } else {
                    $atts['href'] = ! empty( $item->url ) ? $item->url : '';
                }

                $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args );

                $attributes = '';
                foreach ( $atts as $attr => $value ) {
                    if ( ! empty( $value ) ) {
                        $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                        $attributes .= ' ' . $attr . '="' . $value . '"';
                    }
                }

                $item_output = $args->before;

                /*
                * Glyphicons
                **/
                if ( ! empty( $item->attr_title ) )
                $item_output .= '<a'. $attributes .'><span class=" ' . esc_attr( $item->attr_title ) . '"></span>&nbsp;';
                else
                $item_output .= '<a'. $attributes .'>';

                $item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
                $item_output .= ( $args->has_children && 0 === $depth ) ? ' <span class="caret"></span></a>' : '</a>';
                $item_output .= $args->after;

                $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
            }
        }

        /**
        * Traverse elements to create list from elements.
        **/
        public function display_element( $element, &$children_elements, $max_depth, $depth, $args, &$output )
        {
            if ( ! $element )
            return;

            $id_field = $this->db_fields['id'];

            // Display this element.
            if ( is_object( $args[0] ) )
            $args[0]->has_children = ! empty( $children_elements[ $element->$id_field ] );

            parent::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
        }

        /**
        * Menu Fallback
        **/
        public static function fallback( $args )
        {
            if ( current_user_can( 'manage_options' ) ) {

                extract( $args );

                $fb_output = null;

                if ( $container ) {
                    $fb_output = '<' . $container;

                    if ( $container_id )
                    $fb_output .= ' id="' . $container_id . '"';

                    if ( $container_class )
                    $fb_output .= ' class="' . $container_class . '"';

                    $fb_output .= '>';
                }

                $fb_output .= '<ul';

                if ( $menu_id )
                $fb_output .= ' id="' . $menu_id . '"';

                if ( $menu_class )
                $fb_output .= ' class="' . $menu_class . '"';

                $fb_output .= '>';
                $fb_output .= '<li><a href="' . admin_url( 'nav-menus.php' ) . '">' . esc_html__('Add a menu', 'nt-landium') .'</a></li>';
                $fb_output .= '</ul>';

                if ( $container )
                $fb_output .= '</' . $container . '>';

                echo wp_kses($fb_output,nt_landium_allowed_html());
            }
        }
    }
}


/*************************************************
## nt_landium Comment
*************************************************/

if ( ! function_exists( 'nt_landium_comment' ) ) {
    function nt_landium_comment( $comment, $args, $depth ) {
        $GLOBALS['comment'] = $comment;
        switch ( $comment->comment_type ) :
            case 'pingback' :
            case 'trackback' :
            ?>

            <article class="post pingback">
                <p><?php esc_html_e( 'Pingback:', 'nt-landium' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( esc_html__( '(Edit)', 'nt-landium' ), ' ' ); ?></p>
                <?php
                break;
                default :
                ?>
                <div class="comments">
                    <ul>
                        <li class="comment">
                            <span class="who">
                                <?php echo get_avatar( $comment, 80 ); ?>
                            </span>
                            <div class="who-comment">
                                <p class="name"><?php comment_author(); ?></p>
                                <?php comment_text(); ?>
                                <?php edit_comment_link( esc_html__( 'Edit', 'nt-landium' ), ' ' ); ?>
                                <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
                                <span class="meta-data"><time class="comment-date" pubdate datetime="<?php comment_time( 'c' ); ?>"><?php comment_date(); ?> <?php esc_html_e( 'at', 'nt-landium' ); ?> <?php comment_time(); ?></time></span>
                                <?php if ( $comment->comment_approved == '0' ) : ?>
                                    <em><?php esc_html_e( 'Your comment is awaiting moderation.', 'nt-landium' ); ?></em>
                                <?php endif; ?>
                            </div>
                        </li>
                    </ul>
                </div>
                <?php
            break;
        endswitch;
    }
}


/*************************************************
## OPTION TREE WEBFONTS API
*************************************************/

add_filter( 'ot_google_fonts_api_key', 'nt_landium_change_ot_google_fonts_api_key' );
if ( ! function_exists( 'nt_landium_change_ot_google_fonts_api_key' ) ) {
    function nt_landium_change_ot_google_fonts_api_key( $key ) {
        $api = ot_get_option( 'ot_font_api' );
        return "$api";
    }
}

add_filter( 'ot_recognized_font_families', 'nt_landium_filter_ot_recognized_font_families', 10, 2 );
function nt_landium_filter_ot_recognized_font_families( $array, $field_id ) {

    $array['helveticaneue'] = "'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif";

    ot_fetch_google_fonts( true, false );

    $ot_google_fonts = wp_list_pluck( get_theme_mod( 'ot_google_fonts', array() ), 'family' );

    $array = array_merge($array,$ot_google_fonts);

    if (ot_get_option('typekit_id')) {

        $typekit_fonts = trim( ot_get_option('typekit_fonts'), ' ');
        $typekit_fonts = explode( ',', $typekit_fonts );
        $array = array_merge( $array, $typekit_fonts );
    }

    foreach ($array as $font => $value) {
            $thb_font_array[$value] = $value;
    }

    return $thb_font_array;
}

/*************************************************
## ADMIN NOTICES
*************************************************/

function nt_landium_theme_activation_notice()
{
    global $current_user;

    $user_id = $current_user->ID;

    if (!get_user_meta($user_id, 'nt_landium_theme_activation_notice')) {
        ?>

        <div class="updated notice">
            <p>
                <?php
                echo sprintf(
                    esc_html__('If you need help about demodata installation, please read docs and %s', 'nt-landium'),
                    '<a target="_blank" href="' . esc_url('https://ninetheme.com/contact/') . '">
                    ' . esc_html__('Contact', 'nt-landium') . '
                    </a> ' . esc_html__(' - ', 'nt-landium') . ' <a href="?landium-ignore-notice">' . esc_html__('Dismiss', 'nt-landium') . '</a>');
                    ?>
            </p>
        </div>
        <?php
    }
}
add_action( 'admin_notices', 'nt_landium_theme_activation_notice' );


function nt_landium_theme_activation_notice_ignore()
{
    global $current_user;

    $user_id = $current_user->ID;

    if (isset($_GET['landium-ignore-notice'])) {
        add_user_meta($user_id, 'nt_landium_theme_activation_notice', 'true', true);
    }
}
add_action( 'admin_init', 'nt_landium_theme_activation_notice_ignore' );


/*************************************************
## SANITIZE MODIFIED VC-ELEMENTS OUTPUT
*************************************************/

if ( !function_exists( 'nt_landium_vc_sanitize_data' ) ) {
    function nt_landium_vc_sanitize_data($output)
    {
        return $output;
    }
}

/*************************************************
## VC COMPOSER PAGE CSS
*************************************************/
/*
*	get vc composer custom css from by page id
*	and add css to head by wp_head hook
*/
if( ! function_exists('landium_vc_inject_shortcode_css') )  {
    function landium_vc_inject_shortcode_css( $id ){
        $shortcodes_custom_css = get_post_meta( $id, '_wpb_shortcodes_custom_css', true );
        if ( ! empty( $shortcodes_custom_css ) ) {
            $shortcodes_custom_css = strip_tags( $shortcodes_custom_css );
            echo '<style type="text/css" data-type="nt-shortcodes-custom-css-page-'.$id.'">';
            echo esc_attr( $shortcodes_custom_css );
            echo '</style>';
        }
    }
    add_action('wp_head', 'landium_vc_inject_shortcode_css');
}

/**********************************
## THEME ALLOWED HTML TAG
/**********************************/

if ( !function_exists( 'nt_landium_allowed_html' ) ) {
    function nt_landium_allowed_html()
    {
        $allowed_tags = array(
            'a' => array(
                'id' => array(),
                'class' => array(),
                'href'  => array(),
                'rel'   => array(),
                'title' => array(),
                'target' => array(),
            ),
            'abbr' => array(
                'title' => array(),
            ),
            'iframe' => array(
                'id' => array(),
                'class' => array(),
                'src' => array(),
            ),
            'b' => array(),
            'br' => array(),
            'blockquote' => array(
                'cite'  => array(),
            ),
            'cite' => array(
                'title' => array(),
            ),
            'code' => array(),
            'del' => array(
                'datetime' => array(),
                'title' => array(),
            ),
            'dd' => array(),
            'div' => array(
                'id' => array(),
                'class' => array(),
                'title' => array(),
                'style' => array(),
            ),
            'dl' => array(),
            'dt' => array(),
            'em' => array(),
            'h1' => array(),
            'h2' => array(),
            'h3' => array(),
            'h4' => array(),
            'h5' => array(),
            'h6' => array(),
            'i' => array(
                'class'  => array(),
            ),
            'img' => array(
                'alt' => array(),
                'id' => array(),
                'class' => array(),
                'height' => array(),
                'src' => array(),
                'width'  => array(),
            ),
            'li' => array(
                'class' => array(),
            ),
            'ol' => array(
                'class' => array(),
            ),
            'p' => array(
                'class' => array(),
            ),
            'q' => array(
                'cite' => array(),
                'title' => array(),
            ),
            'span' => array(
                'class' => array(),
                'title' => array(),
                'style' => array(),
            ),
            'strike' => array(),
            'strong' => array(),
            'ul' => array(
                'class' => array(),
            ),
        );

        return $allowed_tags;
    }
}


/*************************************************
## THEME SETUP WIZARD
https://github.com/richtabor/MerlinWP
*************************************************/

require_once get_parent_theme_file_path( '/includes/merlin/admin-menu.php' );
require_once get_parent_theme_file_path( '/includes/merlin/class-merlin.php' );
require_once get_parent_theme_file_path( '/includes/demo-wizard-config.php' );

function landium_merlin_local_import_files() {
    return array(
        array(
            'import_file_name' => 'Demo Import',
            // xml data
            'local_import_file' => get_parent_theme_file_path( 'includes/merlin/demodata/data.xml' ),
            // widget data
            'local_import_widget_file' => get_parent_theme_file_path( 'includes/merlin/demodata/widgets.wie' ),
            // option tree -> theme options
            'local_import_option_tree_file' => get_parent_theme_file_path( '/includes/merlin/demodata/optiontree.txt' ),

            // revolution slider -> demodata
            'import_rev' => array(
                array(
                    'slider1' => trailingslashit( get_parent_theme_file_path() ) . 'includes/merlin/demodata/sliderbg.zip',
                    'slider2' => trailingslashit( get_parent_theme_file_path() ) . 'includes/merlin/demodata/vimeo-hero.zip',
                    'slider3' => trailingslashit( get_parent_theme_file_path() ) . 'includes/merlin/demodata/videobg1.zip'
                )
            )
        )
    );
}
add_filter( 'merlin_import_files', 'landium_merlin_local_import_files' );


/**
* Execute custom code after the whole import has finished.
*/
function landium_merlin_after_import_setup() {
    // Assign menus to their locations.
    $primary = get_term_by( 'name', 'primary', 'nav_menu' );

    set_theme_mod(
        'nav_menu_locations', array(
            'primary' => $primary->term_id,
        )
    );

    // Assign front page and posts page (blog page).
    $front_page_id = get_page_by_title( 'Home 1' );
    $blog_page_id  = get_page_by_title( 'Blog' );

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'page_for_posts', $blog_page_id->ID );

    // removes block widgets from sidebars after demodata install
    if ( is_active_sidebar( 'sidebar-1' ) ) {
        $sidebars_widgets = get_option( 'sidebars_widgets' );
        $sidebar_1_array  = $sidebars_widgets['sidebar-1'];
        foreach( $sidebar_1_array as $k => $v ) {
            if( substr( $v, 0, strlen("block-") ) === "block-" ) {
                unset($sidebars_widgets['sidebar-1'][$k]);
            }
        }
        update_option( 'sidebars_widgets', $sidebars_widgets);
    }

}
add_action( 'merlin_after_all_import', 'landium_merlin_after_import_setup' );

add_action( 'init', 'do_output_buffer' ); function do_output_buffer() { ob_start(); }

/*************************************************
## CUSTOM POST CLASS
*************************************************/


if ( !function_exists('nt_company_post_theme_class') ) {
    function nt_company_post_theme_class( $classes )
    {
        $animation = ot_get_option( 'nt_landium_post_animation' );
        $classes[] = $animation != '' ? 'wow '. $animation : '';
        if ( is_single() ) {

            $classes[] = has_blocks() ? 'nt-single-has-block' : '';
        }

        return $classes;
    }
}
add_filter( 'post_class', 'nt_company_post_theme_class' );
