<?php


if ( ! function_exists( 'nt_landium_all_post_content' ) ) {
    function nt_landium_all_post_content() {
        ?>
        <div class="post-container">
            <div class="content-container">

                <?php nt_landium_post_title(); ?>

                <?php nt_landium_post_meta(); ?>

            </div>

            <?php nt_landium_post_content(); ?>

        </div>
        <?php
    }
}

if ( ! function_exists( 'nt_landium_post_title' ) ) {
    function nt_landium_post_title() {
        if ( ! is_single() ) {
            the_title( sprintf( '<div class="entry-header"><h2 class="entry-title all-caps"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2></div>' );
        }
    }
}

if ( ! function_exists( 'nt_landium_post_meta' ) ) {
    function nt_landium_post_meta() {
        ?>
        <ul class="entry-meta">
            <li><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_time('F j, Y'); ?></a></li>
            <li><?php esc_html_e('in', 'nt-landium'); ?>  <?php the_category(', '); ?></li>
            <li><?php the_author(); ?></li>
            <?php the_tags( '<li>', ', ', '</li> '); ?>
        </ul>
        <?php
    }
}

if ( ! function_exists( 'nt_landium_post_content' ) ) {
    function nt_landium_post_content() {
        $nt_landium_post_readmore = ot_get_option( 'nt_landium_post_readmore' );
        $nt_landium_post_readmore = $nt_landium_post_readmore ? $nt_landium_post_readmore : esc_html__( 'Read More', 'nt-landium' );
        ?>
        <div class="entry-content">
            <?php
            if ( is_single() ) {
                /* translators: %s: Name of current post */
                the_content( sprintf(
                    esc_html__( 'Continue reading %s', 'nt-landium' ),
                    the_title( '<span class="screen-reader-text">', '</span>', false )
                    ) );

                } else {

                    if ( has_excerpt() ) {

                        the_excerpt();

                    } else {

                        echo wpautop( wp_trim_words( strip_tags( get_the_content() ), 80 ) );
                    }

                }

                wp_link_pages(
                    array(
                        'before' => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'nt-landium' ) . '</span>',
                        'after' => '</div>',
                        'link_before' => '<span>',
                        'link_after' => '</span>',
                        'pagelink' => '<span class="screen-reader-text">' . esc_html__( 'Page', 'nt-landium' ) . ' </span>%',
                        'separator' => '<span class="screen-reader-text">, </span>',
                    )
                );
                ?>
            </div>

            <?php if ( ! is_single() ) : ?>
                <a class="margin_30 btn" href="<?php echo esc_url( get_permalink() ); ?>" role="button"><?php echo esc_html( $nt_landium_post_readmore );?></a>
            <?php endif;?>

            <?php do_action('nt_landium_after_single_post_content' ); ?>

            <?php
        }
    }
