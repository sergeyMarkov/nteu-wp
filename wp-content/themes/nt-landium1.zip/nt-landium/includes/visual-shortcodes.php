<?php

/*-----------------------------------------------------------------------------------*/
/*	Shortcode Filter
/*-----------------------------------------------------------------------------------*/

vc_set_as_theme( $disable_updater = false );
vc_is_updater_disabled();


//FOR ROW EXTRA ATTR
$nt_landium_background_one_attributes = array(

    array(
        'type' => 'dropdown',
        'heading' => esc_html__('Background position Y-X axis', 'nt-landium' ),
        'param_name' => 'nt_landium_bg_position',
        'description' => esc_html__('Change position Y-X axis for bg image.', 'nt-landium'),
        'group' => esc_html__('Design Options','nt-landium'),
        'value' => array(
            esc_html__('Select Y-X position', 'nt-landium' ) => '',
            esc_html__('Left-Top', 'nt-landium' ) => 'left top',
            esc_html__('Left-Center', 'nt-landium' ) => 'left center',
            esc_html__('Left-Bottom', 'nt-landium' ) => 'left bottom',
            esc_html__('Right-Top', 'nt-landium' ) => 'right top',
            esc_html__('Right-Center', 'nt-landium' ) => 'right center',
            esc_html__('Right-Bottom', 'nt-landium' ) => 'right bottom',
            esc_html__('Center-Top', 'nt-landium' ) => 'center top',
            esc_html__('Center-Center', 'nt-landium' ) => 'center center',
            esc_html__('Center-Bottom', 'nt-landium' ) => 'center bottom',
            esc_html__('Custom', 'nt-landium' ) => 'custom',
        ),
    ),

    array(
        'type' => 'textfield',
        'heading' => esc_html__('Background position Y axis', 'nt-landium'),
        'param_name' => 'nt_landium_bg_positiony',
        'description' => esc_html__('Change position X axis offset for bg image.example: center or 40px or 25% ...etc', 'nt-landium'),
        'group' => esc_html__('Design Options','nt-landium'),
        'dependency' => array(
            'element' => 'nt_landium_bg_position',
            'value' => 'custom'
        )
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Background position X axis', 'nt-landium'),
        'param_name' => 'nt_landium_bg_positionx',
        'description' => esc_html__('Change position X axis offset for bg image.example: center or 40px or 25% ...etc', 'nt-landium'),
        'group' => esc_html__('Design Options','nt-landium'),
        'dependency' => array(
            'element' => 'nt_landium_bg_position',
            'value' => 'custom'
        )
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Background position X axis offset', 'nt-landium'),
        'param_name' => 'nt_landium_bg_xoffset',
        'description' => esc_html__('Change position X axis offset for bg image.example: 40px or 25% ...etc', 'nt-landium'),
        'group' => esc_html__('Design Options','nt-landium'),
        'dependency' => array(
            'element' => 'nt_landium_bg_position',
            'value' => 'custom'
        )
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Background size', 'nt-landium'),
        'param_name' => 'nt_landium_bg_size',
        'description' => esc_html__('Change size for bg image.example: 100px or 100% or 100vh', 'nt-landium'),
        'group' => esc_html__('Design Options','nt-landium'),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Background image display ( 992px )', 'nt-landium' ),
        'param_name' => 'nt_landium_bg_ontablet',
        'value' => array(
            'Hide background image'=>'hide',
        ), //value
        'std' => '',
        'description' => esc_html__('This option is for disabling the row background image when the screen width maximum 992px', 'nt-landium'),
        'group' => esc_html__('Design Options','nt-landium'),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Background image display ( 768px )', 'nt-landium' ),
        'param_name' => 'nt_landium_bg_onmobile',
        'value' => array(
            'Hide background image'=>'hide',
        ), //value
        'std' => '',
        'description' => esc_html__('This option is for disabling the row background image when the screen width maximum 768px', 'nt-landium'),
        'group' => esc_html__('Design Options','nt-landium'),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Background image display ( 480px )', 'nt-landium' ),
        'param_name' => 'nt_landium_bg_onphone',
        'value' => array(
            'Hide background image'=>'hide',
        ), //value
        'std' => '',
        'description' => esc_html__('This option is for disabling the row background image when the screen width maximum 480px', 'nt-landium'),
        'group' => esc_html__('Design Options','nt-landium'),
    ),
);
vc_add_params( 'vc_row', $nt_landium_background_one_attributes );


//FOR ROW 480 RESOLUTION
$nt_landium_vc_row_responsive_attributes = array(

    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Add container ?', 'nt-landium'),
        'param_name' => 'nt_landium_container_display',
        'weight' => 1,
        'value' => array(
            'Add container'=>'true',
        ), //value
        'std' => '',
        'description' => esc_html__('This option is only for Row stretch : Default and Row stretch : Stretch row.', 'nt-landium')
    ),

    array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Max width 992px resolution', 'nt-landium' ),
        'param_name' => 'nt_landium_vc_row_992_responsive',
        'description' => esc_html__( 'These options for 992px resolution - responsive medya', 'nt-landium' ),
        'group' => esc_html__('Responsive Extra','nt-landium'),
    ),
    array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Max width 768px resolution', 'nt-landium' ),
        'param_name' => 'nt_landium_vc_row_768_responsive',
        'description' => esc_html__( 'These options for 768px resolution - responsive medya', 'nt-landium' ),
        'group' => esc_html__('Responsive Extra','nt-landium'),
    ),
    array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Max width 480px resolution', 'nt-landium' ),
        'param_name' => 'nt_landium_vc_row_480_responsive',
        'description' => esc_html__( 'These options for 480px resolution - responsive medya', 'nt-landium' ),
        'group' => esc_html__('Responsive Extra','nt-landium'),
    ),

);
vc_add_params( 'vc_row', $nt_landium_vc_row_responsive_attributes );


//FOR ROW EXTRA 3 OVERLAY ATTR
$nt_landium_row_overlay_attributes = array(

    //OVERLAY 1
    array(
        'type' => 'colorpicker',
        'heading' => esc_html__('Overlay Color', 'nt-landium'),
        'param_name' => 'overlaybg',
        'description' => esc_html__('Add color.', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Width', 'nt-landium'),
        'param_name' => 'overlaywidth',
        'description' => esc_html__('Add width.example:100% or 75%....etc.', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Height', 'nt-landium'),
        'param_name' => 'overlayheight',
        'description' => esc_html__('Add width.example:100% or 75%....etc.', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Top offset', 'nt-landium'),
        'param_name' => 'overlaytop',
        'description' => esc_html__('Add Top offset for top position.example:10px or 10%.', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Left offset', 'nt-landium'),
        'param_name' => 'overlayleft',
        'description' => esc_html__('Add left offset for left position.example:10px or 10%.', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Right offset', 'nt-landium'),
        'param_name' => 'overlayright',
        'description' => esc_html__('Add right offset for right position.example:10px or 10%.', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Bottom offset', 'nt-landium'),
        'param_name' => 'overlaybottom',
        'description' => esc_html__('Add bottom offset for bottom position.example:10px or 10%.', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Display under 992px ?', 'nt-landium'),
        'param_name' => 'overlay992',
        'value' => array(
            'Hide overlay'=>'hide',
        ), //value
        'std' => '',
        'description' => esc_html__('This option is for disabling the overlay color when the screen width maximum 992px', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Display under 768px ?', 'nt-landium'),
        'param_name' => 'overlay768',
        'value' => array(
            'Hide overlay'=>'hide',
        ), //value
        'std' => '',
        'description' => esc_html__('This option is for disabling the overlay color when the screen width maximum 768px', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Display under overlay480px ?', 'nt-landium'),
        'param_name' => 'overlay480',
        'value' => array(
            'Hide overlay'=>'hide',
        ), //value
        'std' => '',
        'description' => esc_html__('This option is for disabling the overlay color when the screen width maximum overlay480px', 'nt-landium'),
        'group' => esc_html__('Overlay 1','nt-landium'),
    ),

    //OVERLAY 2
    array(
        'type' => 'colorpicker',
        'heading' => esc_html__('Overlay Color', 'nt-landium'),
        'param_name' => 'overlaybg2',
        'description' => esc_html__('Add color.', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Width', 'nt-landium'),
        'param_name' => 'overlaywidth2',
        'description' => esc_html__('Add width.example:100% or 75%....etc.', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Height', 'nt-landium'),
        'param_name' => 'overlayheight2',
        'description' => esc_html__('Add width.example:100% or 75%....etc.', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Top offset', 'nt-landium'),
        'param_name' => 'overlaytop2',
        'description' => esc_html__('Add Top offset for top position.example:10px or 10%.', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Left offset', 'nt-landium'),
        'param_name' => 'overlayleft2',
        'description' => esc_html__('Add left offset for left position.example:10px or 10%.', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Right offset', 'nt-landium'),
        'param_name' => 'overlayright2',
        'description' => esc_html__('Add right offset for right position.example:10px or 10%.', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Bottom offset', 'nt-landium'),
        'param_name' => 'overlaybottom2',
        'description' => esc_html__('Add bottom offset for bottom position.example:10px or 10%.', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Display under 992px ?', 'nt-landium'),
        'param_name' => 'overlay2_992',
        'value' => array(
            'Hide overlay'=>'hide',
        ), //value
        'std' => '',
        'description' => esc_html__('This option is for disabling the overlay color when the screen width maximum 992px', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Display under 768px ?', 'nt-landium'),
        'param_name' => 'overlay2_768',
        'value' => array(
            'Hide overlay'=>'hide',
        ), //value
        'std' => '',
        'description' => esc_html__('This option is for disabling the overlay color when the screen width maximum 768px', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Display under overlay480px ?', 'nt-landium'),
        'param_name' => 'overlay2_480',
        'value' => array('Hide overlay'=>'hide' ),
        'std' => '',
        'description' => esc_html__('This option is for disabling the overlay color when the screen width maximum 480px', 'nt-landium'),
        'group' => esc_html__('Overlay 2','nt-landium'),
    ),
);
vc_add_params( 'vc_row', $nt_landium_row_overlay_attributes );

//FOR COLUMN
$nt_landium_vc_column_responsive_attributes = array(

    array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Max width 992px resolution', 'nt-landium' ),
        'param_name' => 'nt_landium_vc_column_992',
        'description' => esc_html__( 'These options for 992px resolution - responsive medya', 'nt-landium' ),
        'group' => esc_html__('Responsive Extra','nt-landium'),
    ),
    array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Max width 768px resolution', 'nt-landium' ),
        'param_name' => 'nt_landium_vc_column_768',
        'description' => esc_html__( 'These options for 768px resolution - responsive medya', 'nt-landium' ),
        'group' => esc_html__('Responsive Extra','nt-landium'),
    ),
    array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Max width 480px resolution', 'nt-landium' ),
        'param_name' => 'nt_landium_vc_column_480',
        'description' => esc_html__( 'These options for 480px resolution - responsive medya', 'nt-landium' ),
        'group' => esc_html__('Responsive Extra','nt-landium'),
    ),

);
vc_add_params( 'vc_column', $nt_landium_vc_column_responsive_attributes );

//FOR COLUMN INNER
$nt_landium_vc_column_inner_responsive_attributes = array(

    array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Max width 992px resolution', 'nt-landium' ),
        'param_name' => 'nt_landium_vc_colinner_992',
        'description' => esc_html__( 'These options for 992px resolution - responsive medya', 'nt-landium' ),
        'group' => esc_html__('Responsive Extra','nt-landium'),
    ),
    array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Max width 768px resolution', 'nt-landium' ),
        'param_name' => 'nt_landium_vc_colinner_768',
        'description' => esc_html__( 'These options for 768px resolution - responsive medya', 'nt-landium' ),
        'group' => esc_html__('Responsive Extra','nt-landium'),
    ),
    array(
        'type' => 'css_editor',
        'heading' => esc_html__( 'Max width 480px resolution', 'nt-landium' ),
        'param_name' => 'nt_landium_vc_colinner_480',
        'description' => esc_html__( 'These options for 480px resolution - responsive medya', 'nt-landium' ),
        'group' => esc_html__('Responsive Extra','nt-landium'),
    ),

);
vc_add_params( 'vc_column_inner', $nt_landium_vc_column_inner_responsive_attributes );

/*-----------------------------------------------------------------------------------*/
/*	HERO 3 FORM landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_heroform_integrateWithVC' );
function NT_Landium_heroform_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Hero Form", "nt-landium" ),
            "base" => "nt_landium_section_heroform",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Background parallax image", "nt-landium"),
                    "param_name" => "herobgimg",
                    "description" => esc_html__("Add your BG parallax image", "nt-landium"),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Select particles effect hide or show', 'nt-landium' ),
                    'param_name' => 'particle',
                    'description' => esc_html__('You can select particles effect hide or show', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select particles effect', 'nt-landium' ) => '',
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Select overlay color hide or show', 'nt-landium' ),
                    'param_name' => 'overlay_display',
                    'description' => esc_html__('You can select overlay mask color hide or show', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select a style', 'nt-landium' ) => '',
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__('Overlay color', 'nt-landium' ),
                    'param_name' => 'overlaycolor',
                    "description" => esc_html__("Add/select an color", "nt-landium"),
                    'dependency' => array(
                        'element' => 'overlay_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),

                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__('Button (Link)', 'nt-landium' ),
                    'param_name' => 'herobtnlink',
                    'description' => esc_html__('Add custom link.', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Contact form animation', 'nt-landium'),
                    'param_name' => 'formanimation',
                    'description' => esc_html__('Add animation for contact form', 'nt-landium'),
                    'group' => esc_html__('Hero Form', 'nt-landium' ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Hero Contact Form heading', 'nt-landium' ),
                    'param_name' => 'heroform_title',
                    'description' => esc_html__("Add contact form 7 heading/title", "nt-landium"),
                    'group' => esc_html__('Hero Form', 'nt-landium' ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Hero Contact Form description', 'nt-landium' ),
                    'param_name' => 'heroform_desc',
                    'description' => esc_html__("Add contact form 7 description", "nt-landium"),
                    'group' => esc_html__('Hero Form', 'nt-landium' ),
                ),
                array(
                    'type' => 'textarea_html',
                    'heading' => esc_html__('Hero Contact Form', 'nt-landium' ),
                    'param_name' => 'content',
                    'description' => esc_html__("Add contact form 7 shortcode here", "nt-landium"),
                    'group' => esc_html__('Hero Form', 'nt-landium' ),
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Button', 'nt-landium' ) => '3',
                                esc_html__('Contact Form heading', 'nt-landium' ) => '4',
                                esc_html__('Contact Form description', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
            ),
        )
    );
} class NT_Landium_section_heroform extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	HERO PRODUCT landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_heroproduct_integrateWithVC' );
function NT_Landium_heroproduct_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Hero Product", "nt-landium" ),
            "base" => "nt_landium_section_heroproduct",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Background parallax image", "nt-landium"),
                    "param_name" => "herobgimg",
                    "description" => esc_html__("Add your BG parallax image", "nt-landium"),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Product image", "nt-landium"),
                    "param_name" => "hero_img",
                    "description" => esc_html__("Add your hero product image", "nt-landium"),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Product image animation', 'nt-landium'),
                    'param_name' => 'heroimganimation',
                    'description' => esc_html__('Add animation for product image', 'nt-landium'),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Select particles effect hide or show', 'nt-landium' ),
                    'param_name' => 'particle',
                    'description' => esc_html__('You can select particles effect hide or show', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select particles effect', 'nt-landium' ) => '',
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Select overlay color hide or show', 'nt-landium' ),
                    'param_name' => 'overlay_display',
                    'description' => esc_html__('You can select overlay mask color hide or show', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select a style', 'nt-landium' ) => '',
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__('Overlay color', 'nt-landium' ),
                    'param_name' => 'overlaycolor',
                    "description" => esc_html__("Add/select an color", "nt-landium"),
                    'dependency' => array(
                        'element' => 'overlay_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'checkbox',
                    'param_name' => 'custom_content',
                    'heading' => esc_html__('Use custom content?', 'nt-landium'),
                    'description' => esc_html__('Check this option if you want to use custom content.', 'nt-landium'),
                    'value' => array( esc_html__('Yes', 'nt-landium') => 'yes' ),
                    'group' => esc_html__('Heading', 'nt-landium' )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'custom_content',
                        'is_empty' => true
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'custom_content',
                        'is_empty' => true
                    )
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__('Button (Link)', 'nt-landium' ),
                    'param_name' => 'herobtnlink',
                    'description' => esc_html__('Add custom link.', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'custom_content',
                        'is_empty' => true
                    )
                ),
                array(
                    'type' => 'textarea_html',
                    'heading' => esc_html__('Custom Content Area', 'nt-landium' ),
                    'param_name' => 'content',
                    'description' => esc_html__("Add any content here", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'custom_content',
                        'not_empty' => true
                    )
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Button', 'nt-landium' ) => '3',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
            )
        )
    );
} class NT_Landium_section_heroproduct extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	SERVICES landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_services_integrateWithVC' );
function NT_Landium_services_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Services Section", "nt-landium" ),
            "base" => "nt_landium_section_services",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                //heading section
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Heading display ( hide or show )', 'nt-landium' ),
                    'param_name' => 'heading_display',
                    'description' => esc_html__('You can select hide or show for section heading and description', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                //services loop
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Item column size', 'nt-landium' ),
                    'param_name' => 'item_column',
                    'description' => esc_html__('You can select detail item column size', 'nt-landium' ),
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select column for all item', 'nt-landium' ) => '',
                        esc_html__('1 Column', 'nt-landium' ) => 'col-md-12',
                        esc_html__('2 Column', 'nt-landium' ) => 'col-md-6',
                        esc_html__('3 Column', 'nt-landium' ) => 'col-md-4',
                        esc_html__('4 Column', 'nt-landium' ) => 'col-md-3',
                        esc_html__('6 Column', 'nt-landium' ) => 'col-md-2',
                        esc_html__('Custom Column', 'nt-landium' ) => 'custom',
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Desktop column', 'nt-landium' ),
                    'param_name' => 'desk_column',
                    'description' => esc_html__('You can select desktop column size', 'nt-landium' ),
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select desktop column for all item', 'nt-landium' ) => '',
                        esc_html__('col-md-1', 'nt-landium' ) => 'col-md-1',
                        esc_html__('col-md-2', 'nt-landium' ) => 'col-md-2',
                        esc_html__('col-md-3', 'nt-landium' ) => 'col-md-3',
                        esc_html__('col-md-4', 'nt-landium' ) => 'col-md-4',
                        esc_html__('col-md-5', 'nt-landium' ) => 'col-md-5',
                        esc_html__('col-md-6', 'nt-landium' ) => 'col-md-6',
                        esc_html__('col-md-7', 'nt-landium' ) => 'col-md-7',
                        esc_html__('col-md-8', 'nt-landium' ) => 'col-md-8',
                        esc_html__('col-md-9', 'nt-landium' ) => 'col-md-9',
                        esc_html__('col-md-10', 'nt-landium' ) => 'col-md-10',
                        esc_html__('col-md-11', 'nt-landium' ) => 'col-md-11',
                        esc_html__('col-md-12', 'nt-landium' ) => 'col-md-12',
                    ),
                    'dependency' => array(
                        'element' => 'item_column',
                        'value' => 'custom'
                    )
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Desktop column offset', 'nt-landium' ),
                    'param_name' => 'desk_column_offset',
                    'description' => esc_html__('You can select desktop column offset size', 'nt-landium' ),
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select desktop column offset for all item', 'nt-landium' ) => '',
                        esc_html__('col-md-offset-1', 'nt-landium' ) => 'col-md-offset-1',
                        esc_html__('col-md-offset-2', 'nt-landium' ) => 'col-md-offset-2',
                        esc_html__('col-md-offset-3', 'nt-landium' ) => 'col-md-offset-3',
                        esc_html__('col-md-offset-4', 'nt-landium' ) => 'col-md-offset-4',
                        esc_html__('col-md-offset-5', 'nt-landium' ) => 'col-md-offset-5',
                        esc_html__('col-md-offset-6', 'nt-landium' ) => 'col-md-offset-6',
                        esc_html__('col-md-offset-7', 'nt-landium' ) => 'col-md-offset-7',
                        esc_html__('col-md-offset-8', 'nt-landium' ) => 'col-md-offset-8',
                        esc_html__('col-md-offset-9', 'nt-landium' ) => 'col-md-offset-9',
                        esc_html__('col-md-offset-10', 'nt-landium' ) => 'col-md-offset-10',
                        esc_html__('col-md-offset-11', 'nt-landium' ) => 'col-md-offset-11',
                        esc_html__('col-md-offset-12', 'nt-landium' ) => 'col-md-offset-12',
                    ),
                    'dependency' => array(
                        'element' => 'item_column',
                        'value' => 'custom'
                    )
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Mobile column', 'nt-landium' ),
                    'param_name' => 'mob_column',
                    'description' => esc_html__('You can select mobile device column size', 'nt-landium' ),
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select mobile column for all item', 'nt-landium' ) => '',
                        esc_html__('col-sm-1', 'nt-landium' ) => 'col-sm-1',
                        esc_html__('col-sm-2', 'nt-landium' ) => 'col-sm-2',
                        esc_html__('col-sm-3', 'nt-landium' ) => 'col-sm-3',
                        esc_html__('col-sm-4', 'nt-landium' ) => 'col-sm-4',
                        esc_html__('col-sm-5', 'nt-landium' ) => 'col-sm-5',
                        esc_html__('col-sm-6', 'nt-landium' ) => 'col-sm-6',
                        esc_html__('col-sm-7', 'nt-landium' ) => 'col-sm-7',
                        esc_html__('col-sm-8', 'nt-landium' ) => 'col-sm-8',
                        esc_html__('col-sm-9', 'nt-landium' ) => 'col-sm-9',
                        esc_html__('col-sm-10', 'nt-landium' ) => 'col-sm-10',
                        esc_html__('col-sm-11', 'nt-landium' ) => 'col-sm-11',
                        esc_html__('col-sm-12', 'nt-landium' ) => 'col-sm-12',
                    ),
                    'dependency' => array(
                        'element' => 'item_column',
                        'value' => 'custom'
                    )
                ),
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Services items', 'nt-landium' ),
                    'param_name' => 'servicesloop',
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Item icon type', 'nt-landium' ),
                            'param_name' => 'icon_type',
                            'description' => esc_html__('You can select icon type image or fonticon', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select icon type', 'nt-landium' ) => '',
                                esc_html__('Font icon', 'nt-landium' ) => 'fonticon',
                                esc_html__('Image icon', 'nt-landium' ) => 'imgicon',

                            ),
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Fonticon name", "nt-landium"),
                            "param_name" => "item_fonticon",
                            "description" => esc_html__("Add icon name(fonticon class name). example : fa fa-facebook", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'fonticon'
                            )
                        ),
                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("image icon", "nt-landium"),
                            "param_name" => "itemimg_icon",
                            "description" => esc_html__("Add your image icon", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'imgicon'
                            )
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Title", "nt-landium"),
                            "param_name" => "item_title",
                            "description" => esc_html__("Add title for item.", "nt-landium"),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Detail", "nt-landium"),
                            "param_name" => "item_desc",
                            "description" => esc_html__("Add detail for item.", "nt-landium"),
                        ),
                    )
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Item font icon', 'nt-landium' ) => '3',
                                esc_html__('Item title', 'nt-landium' ) => '4',
                                esc_html__('Item description', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                ),
            ),
        )
    );
} class NT_Landium_section_services extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	SERVICES landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_servicestwo_integrateWithVC' );
function NT_Landium_servicestwo_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Services 2 Section", "nt-landium" ),
            "base" => "nt_landium_section_servicestwo",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                //heading section
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Heading display ( hide or show )', 'nt-landium' ),
                    'param_name' => 'heading_display',
                    'description' => esc_html__('You can select hide or show for section heading and description', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                //services loop
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Item column size', 'nt-landium' ),
                    'param_name' => 'item_column',
                    'description' => esc_html__('You can select detail item column size', 'nt-landium' ),
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select column for all item', 'nt-landium' ) => '',
                        esc_html__('1 Column', 'nt-landium' ) => 'col-md-12',
                        esc_html__('2 Column', 'nt-landium' ) => 'col-md-6',
                        esc_html__('3 Column', 'nt-landium' ) => 'col-md-4',
                        esc_html__('4 Column', 'nt-landium' ) => 'col-md-3',
                        esc_html__('6 Column', 'nt-landium' ) => 'col-md-2',
                        esc_html__('Custom Column', 'nt-landium' ) => 'custom',
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Desktop column', 'nt-landium' ),
                    'param_name' => 'desk_column',
                    'description' => esc_html__('You can select desktop column size', 'nt-landium' ),
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select desktop column for all item', 'nt-landium' ) => '',
                        esc_html__('col-md-1', 'nt-landium' ) => 'col-md-1',
                        esc_html__('col-md-2', 'nt-landium' ) => 'col-md-2',
                        esc_html__('col-md-3', 'nt-landium' ) => 'col-md-3',
                        esc_html__('col-md-4', 'nt-landium' ) => 'col-md-4',
                        esc_html__('col-md-5', 'nt-landium' ) => 'col-md-5',
                        esc_html__('col-md-6', 'nt-landium' ) => 'col-md-6',
                        esc_html__('col-md-7', 'nt-landium' ) => 'col-md-7',
                        esc_html__('col-md-8', 'nt-landium' ) => 'col-md-8',
                        esc_html__('col-md-9', 'nt-landium' ) => 'col-md-9',
                        esc_html__('col-md-10', 'nt-landium' ) => 'col-md-10',
                        esc_html__('col-md-11', 'nt-landium' ) => 'col-md-11',
                        esc_html__('col-md-12', 'nt-landium' ) => 'col-md-12',
                    ),
                    'dependency' => array(
                        'element' => 'item_column',
                        'value' => 'custom'
                    )
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Desktop column offset', 'nt-landium' ),
                    'param_name' => 'desk_column_offset',
                    'description' => esc_html__('You can select desktop column offset size', 'nt-landium' ),
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select desktop column offset for all item', 'nt-landium' ) => '',
                        esc_html__('col-md-offset-1', 'nt-landium' ) => 'col-md-offset-1',
                        esc_html__('col-md-offset-2', 'nt-landium' ) => 'col-md-offset-2',
                        esc_html__('col-md-offset-3', 'nt-landium' ) => 'col-md-offset-3',
                        esc_html__('col-md-offset-4', 'nt-landium' ) => 'col-md-offset-4',
                        esc_html__('col-md-offset-5', 'nt-landium' ) => 'col-md-offset-5',
                        esc_html__('col-md-offset-6', 'nt-landium' ) => 'col-md-offset-6',
                        esc_html__('col-md-offset-7', 'nt-landium' ) => 'col-md-offset-7',
                        esc_html__('col-md-offset-8', 'nt-landium' ) => 'col-md-offset-8',
                        esc_html__('col-md-offset-9', 'nt-landium' ) => 'col-md-offset-9',
                        esc_html__('col-md-offset-10', 'nt-landium' ) => 'col-md-offset-10',
                        esc_html__('col-md-offset-11', 'nt-landium' ) => 'col-md-offset-11',
                        esc_html__('col-md-offset-12', 'nt-landium' ) => 'col-md-offset-12',
                    ),
                    'dependency' => array(
                        'element' => 'item_column',
                        'value' => 'custom'
                    )
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Mobile column', 'nt-landium' ),
                    'param_name' => 'mob_column',
                    'description' => esc_html__('You can select mobile device column size', 'nt-landium' ),
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Select mobile column for all item', 'nt-landium' ) => '',
                        esc_html__('col-sm-1', 'nt-landium' ) => 'col-sm-1',
                        esc_html__('col-sm-2', 'nt-landium' ) => 'col-sm-2',
                        esc_html__('col-sm-3', 'nt-landium' ) => 'col-sm-3',
                        esc_html__('col-sm-4', 'nt-landium' ) => 'col-sm-4',
                        esc_html__('col-sm-5', 'nt-landium' ) => 'col-sm-5',
                        esc_html__('col-sm-6', 'nt-landium' ) => 'col-sm-6',
                        esc_html__('col-sm-7', 'nt-landium' ) => 'col-sm-7',
                        esc_html__('col-sm-8', 'nt-landium' ) => 'col-sm-8',
                        esc_html__('col-sm-9', 'nt-landium' ) => 'col-sm-9',
                        esc_html__('col-sm-10', 'nt-landium' ) => 'col-sm-10',
                        esc_html__('col-sm-11', 'nt-landium' ) => 'col-sm-11',
                        esc_html__('col-sm-12', 'nt-landium' ) => 'col-sm-12',
                    ),
                    'dependency' => array(
                        'element' => 'item_column',
                        'value' => 'custom'
                    )
                ),
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Services items', 'nt-landium' ),
                    'param_name' => 'servicesloop',
                    'group' => esc_html__('Services', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Item icon type', 'nt-landium' ),
                            'param_name' => 'icon_type',
                            'description' => esc_html__('You can select icon type image or fonticon', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select icon type', 'nt-landium' ) => '',
                                esc_html__('Font icon', 'nt-landium' ) => 'fonticon',
                                esc_html__('Image icon', 'nt-landium' ) => 'imgicon',
                            ),
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Fonticon name", "nt-landium"),
                            "param_name" => "item_fonticon",
                            "description" => esc_html__("Add icon name(fonticon class name). example : fa fa-facebook", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'fonticon'
                            )
                        ),
                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("image icon", "nt-landium"),
                            "param_name" => "itemimg_icon",
                            "description" => esc_html__("Add your image icon", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'imgicon'
                            )
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Title", "nt-landium"),
                            "param_name" => "item_title",
                            "description" => esc_html__("Add title for item.", "nt-landium"),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Detail", "nt-landium"),
                            "param_name" => "item_desc",
                            "description" => esc_html__("Add detail for item.", "nt-landium"),
                        ),
                    )
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Button', 						'nt-landium' ) => '3',
                                esc_html__('Contact Form heading', 'nt-landium' ) => '4',
                                esc_html__('Contact Form description', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),

                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                ),
            ),
        )
    );
} class NT_Landium_section_servicestwo extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	ABOUTONE  landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_aboutone_integrateWithVC' );
function NT_Landium_aboutone_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "About Section", "nt-landium" ),
            "base" => "nt_landium_section_aboutone",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Section image", "nt-landium"),
                    "param_name" => "sec_img",
                    "description" => esc_html__("Add your custom left section image", "nt-landium"),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Image animation', 'nt-landium'),
                    'param_name' => 'imganimation',
                    'description' => esc_html__('Add animation for image', 'nt-landium'),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Subtitle', 'nt-landium' ),
                    'param_name' => 'section_subtitle',
                    'description' => esc_html__("Add subtitle for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__('Button (Link)', 'nt-landium' ),
                    'param_name' => 'btnlink',
                    'description' => esc_html__('Add custom link.', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section subtitle', 'nt-landium' ) => '2',
                                esc_html__('Section description', 'nt-landium' ) => '3',
                                esc_html__('Button', 						'nt-landium' ) => '4',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
            ),
        )
    );
} class NT_Landium_section_aboutone extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	ABOUT 2 landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_abouttwo_integrateWithVC' );
function NT_Landium_abouttwo_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "About 2 Section", "nt-landium" ),
            "base" => "nt_landium_section_abouttwo",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                //heading section
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for this section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Left image", "nt-landium"),
                    "param_name" => "about_img",
                    "description" => esc_html__("Add your left image", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Image animation', 'nt-landium'),
                    'param_name' => 'imganimation',
                    'description' => esc_html__('Add animation for image', 'nt-landium'),
                ),
                //services loop
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('About items', 'nt-landium' ),
                    'param_name' => 'abouttwoloop',
                    'group' => esc_html__('About', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Item icon type', 'nt-landium' ),
                            'param_name' => 'icon_type',
                            'description' => esc_html__('You can select icon type image or fonticon', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select icon type', 'nt-landium' ) => '',
                                esc_html__('Font icon', 'nt-landium' ) => 'fonticon',
                                esc_html__('Icon list', 'nt-landium' ) => 'iconlist',
                            ),
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Fonticon name", "nt-landium"),
                            "param_name" => "item_fonticon",
                            "description" => esc_html__("Add icon name(fonticon class name). example : fa fa-facebook", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => array('fonticon',''),
                            )
                        ),
                        array(
                            "type" => "iconpicker",
                            "heading" => esc_html__("Fonticon", "nt-landium"),
                            "param_name" => "i_icontwo",
                            "description" => esc_html__("Please select icon.", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'iconlist'
                            )
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Detail", "nt-landium"),
                            "param_name" => "item_desc",
                            "description" => esc_html__("Add detail for item.", "nt-landium"),
                        ),
                    )
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__('Button (Link)', 'nt-landium' ),
                    'param_name' => 'btnlink',
                    'description' => esc_html__('Add custom link.', 'nt-landium' ),
                    'group' => esc_html__('About', 'nt-landium' ),
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Item font icon', 'nt-landium' ) => '3',
                                esc_html__('Item description', 'nt-landium' ) => '4',
                                esc_html__('Button', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                ),
            ),
        )
    );
} class NT_Landium_section_abouttwo extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	TESTIMONIAL landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_testimonial_integrateWithVC' );
function NT_Landium_testimonial_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Testimonial Section", "nt-landium" ),
            "base" => "nt_landium_section_testimonial",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                //Section Heading
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Heading display ( hide or show )', 'nt-landium' ),
                    'param_name' => 'heading_display',
                    'description' => esc_html__('You can select hide or show for section heading and description', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),

                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                //Testimonial loop
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Testimonial Style', 'nt-landium' ),
                    'param_name' => 'testistyle',
                    'description' => esc_html__('You can select testimonial style', 'nt-landium' ),
                    'group' => esc_html__('Testimonial', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Style 1', 'nt-landium' ) => '1',
                        esc_html__('Style 2', 'nt-landium' ) => '2',
                    ),
                ),
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Testimonial items', 'nt-landium' ),
                    'param_name' => 'testiloop',
                    'group' => esc_html__('Testimonial', 'nt-landium' ),
                    'params' => array(

                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("Testimonial image", "nt-landium"),
                            "param_name" => "testi_img",
                            "description" => esc_html__("Add your client image", "nt-landium"),
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Testimonial name", "nt-landium"),
                            "param_name" => "testi_name",
                            "description" => esc_html__("Add your testimonial name", "nt-landium"),
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Testimonial job", "nt-landium"),
                            "param_name" => "testi_job",
                            "description" => esc_html__("Add your testimonial job or detail", "nt-landium"),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Testimonial quote", "nt-landium"),
                            "param_name" => "testi_quote",
                            "description" => esc_html__("Add your testimonial quote text", "nt-landium"),
                        ),

                    )
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Testimonial quote', 'nt-landium' ) => '3',
                                esc_html__('Testimonial name', 'nt-landium' ) => '4',
                                esc_html__('Testimonial job', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                            'dependency' => array(
                                'element' => 'currentitem',
                                'value' => array('1','2')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                ),
            ),
        )
    );
} class NT_Landium_section_testimonial extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	CLIENTS landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_clients_integrateWithVC' );
function NT_Landium_clients_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Clients Section", "nt-landium" ),
            "base" => "nt_landium_section_clients",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Client item', 'nt-landium' ),
                    'param_name' => 'clientloop',
                    'group' => esc_html__('Client', 'nt-landium' ),
                    'params' => array(

                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("Client image", "nt-landium"),
                            "param_name" => "client_img",
                            "description" => esc_html__("Add your client image", "nt-landium"),
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                )
            )
        )
    );
} class NT_Landium_section_clients extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	FEATURES ICON landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_featuresicon_integrateWithVC' );
function NT_Landium_featuresicon_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Features Section", "nt-landium" ),
            "base" => "nt_landium_section_featuresicon",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Heading display ( hide or show )', 'nt-landium' ),
                    'param_name' => 'heading_display',
                    'description' => esc_html__('You can select hide or show for section heading and description', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Center image", "nt-landium"),
                    "param_name" => "centerimg",
                    "description" => esc_html__("Add your center image", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Image animation', 'nt-landium'),
                    'param_name' => 'imganimation',
                    'description' => esc_html__('Add animation for image', 'nt-landium'),
                ),
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Features item', 'nt-landium' ),
                    'param_name' => 'featuresiconloop',
                    'group' => esc_html__('Features', 'nt-landium' ),
                    'params' => array(

                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Item icon type', 'nt-landium' ),
                            'param_name' => 'icon_type',
                            'description' => esc_html__('You can select icon type image or fonticon', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select icon type', 'nt-landium' ) => '',
                                esc_html__('Font icon', 'nt-landium' ) => 'fonticon',
                                esc_html__('Image icon', 'nt-landium' ) => 'imgicon',
                            ),
                        ),
                        //left section
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Fonticon name", "nt-landium"),
                            "param_name" => "l_item_fonticon",
                            "description" => esc_html__("Add left icon name(fonticon class name). example : fa fa-facebook", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'fonticon'
                            )
                        ),
                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("Left image icon", "nt-landium"),
                            "param_name" => "l_itemimg_icon",
                            "description" => esc_html__("Add your left image icon", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'imgicon'
                            )
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Left title", "nt-landium"),
                            "param_name" => "l_item_title",
                            "description" => esc_html__("Add left title for item.", "nt-landium"),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Left detail", "nt-landium"),
                            "param_name" => "l_item_desc",
                            "description" => esc_html__("Add left detail for item.", "nt-landium"),
                        ),
                        //right section
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Right fonticon name", "nt-landium"),
                            "param_name" => "r_item_fonticon",
                            "description" => esc_html__("Add right icon name(fonticon class name). example : fa fa-facebook", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'fonticon'
                            )
                        ),
                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("Right image icon", "nt-landium"),
                            "param_name" => "r_itemimg_icon",
                            "description" => esc_html__("Add your right image icon", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'imgicon'
                            )
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Right title", "nt-landium"),
                            "param_name" => "r_item_title",
                            "description" => esc_html__("Add right title for item.", "nt-landium"),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Right detail", "nt-landium"),
                            "param_name" => "r_item_desc",
                            "description" => esc_html__("Add right detail for item.", "nt-landium"),
                        ),
                    )
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Item font icon', 'nt-landium' ) => '3',
                                esc_html__('Item title', 'nt-landium' ) => '4',
                                esc_html__('Item description', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                )
            )
        )
    );
} class NT_Landium_section_featuresicon extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	FEATURES ICON 2 landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_featuresicontwo_integrateWithVC' );
function NT_Landium_featuresicontwo_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Features 2 Section", "nt-landium" ),
            "base" => "nt_landium_section_featuresicontwo",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Heading display ( hide or show )', 'nt-landium' ),
                    'param_name' => 'heading_display',
                    'description' => esc_html__('You can select hide or show for section heading and description', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Center image", "nt-landium"),
                    "param_name" => "centerimg",
                    "description" => esc_html__("Add your center image", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Center image animation', 'nt-landium'),
                    'param_name' => 'imganimation',
                    'description' => esc_html__('Add animation for center image', 'nt-landium'),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                ),
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Features item', 'nt-landium' ),
                    'param_name' => 'featuresiconloop',
                    'group' => esc_html__('Features', 'nt-landium' ),
                    'params' => array(

                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Item icon type', 'nt-landium' ),
                            'param_name' => 'icon_type',
                            'description' => esc_html__('You can select icon type image or fonticon', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select icon type', 'nt-landium' ) => '',
                                esc_html__('Font icon', 'nt-landium' ) => 'fonticon',
                                esc_html__('Image icon', 'nt-landium' ) => 'imgicon',
                                esc_html__('Icon List', 'nt-landium' ) => 'iconlist',
                            ),
                        ),
                        //left section
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Fonticon name", "nt-landium"),
                            "param_name" => "l_item_fonticon",
                            "description" => esc_html__("Add left icon name(fonticon class name). example : fa fa-facebook", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'fonticon'
                            )
                        ),
                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("Left image icon", "nt-landium"),
                            "param_name" => "l_itemimg_icon",
                            "description" => esc_html__("Add your left image icon", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'imgicon'
                            )
                        ),
                        array(
                            "type" => "iconpicker",
                            "heading" => esc_html__("Fonticon", "nt-landium"),
                            "param_name" => "i_icontwo",
                            "description" => esc_html__("Please select icon.", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'iconlist'
                            )
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Left title", "nt-landium"),
                            "param_name" => "l_item_title",
                            "description" => esc_html__("Add left title for item.", "nt-landium"),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Left detail", "nt-landium"),
                            "param_name" => "l_item_desc",
                            "description" => esc_html__("Add left detail for item.", "nt-landium"),
                        ),
                        //right section
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Right fonticon name", "nt-landium"),
                            "param_name" => "r_item_fonticon",
                            "description" => esc_html__("Add right icon name(fonticon class name). example : fa fa-facebook", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'fonticon'
                            )
                        ),
                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("Right image icon", "nt-landium"),
                            "param_name" => "r_itemimg_icon",
                            "description" => esc_html__("Add your right image icon", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'imgicon'
                            )
                        ),
                        array(
                            "type" => "iconpicker",
                            "heading" => esc_html__("Fonticon", "nt-landium"),
                            "param_name" => "r_icontwo",
                            "description" => esc_html__("Please select icon.", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'iconlist'
                            )
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Right title", "nt-landium"),
                            "param_name" => "r_item_title",
                            "description" => esc_html__("Add right title for item.", "nt-landium"),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Right detail", "nt-landium"),
                            "param_name" => "r_item_desc",
                            "description" => esc_html__("Add right detail for item.", "nt-landium"),
                        ),
                    )
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Item font icon', 'nt-landium' ) => '3',
                                esc_html__('Item title', 'nt-landium' ) => '4',
                                esc_html__('Item description', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                )
            )
        )
    );
} class NT_Landium_section_featuresicontwo extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	HOW IT WORKS landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_howitworks_integrateWithVC' );
function NT_Landium_howitworks_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "How It Works Section", "nt-landium" ),
            "base" => "nt_landium_section_howitworks",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Heading display ( hide or show )', 'nt-landium' ),
                    'param_name' => 'heading_display',
                    'description' => esc_html__('You can select hide or show for section heading and description', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Features item', 'nt-landium' ),
                    'param_name' => 'featuresiconloop',
                    'group' => esc_html__('Features', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Item icon type', 'nt-landium' ),
                            'param_name' => 'icon_type',
                            'description' => esc_html__('You can select icon type image or fonticon', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select icon type', 'nt-landium' ) => '',
                                esc_html__('Font icon', 'nt-landium' ) => 'fonticon',
                                esc_html__('Image icon', 'nt-landium' ) => 'imgicon',
                                esc_html__('Icon list', 'nt-landium' ) => 'iconlist',
                            ),
                        ),
                        //left section
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Fonticon name", "nt-landium"),
                            "param_name" => "item_fonticon",
                            "description" => esc_html__("Add icon name(fonticon class name). example : fa fa-facebook", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'fonticon'
                            )
                        ),
                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("image icon", "nt-landium"),
                            "param_name" => "itemimg_icon",
                            "description" => esc_html__("Add your image icon", "nt-landium"),
                            'dependency' => array(
                                'element' => 'icon_type',
                                'value' => 'imgicon'
                            )
                        ),
                        array(
                            "type"            => "iconpicker",
                            "heading"         => esc_html__("Fonticon", "nt-landium"),
                            "param_name"      => "i_icontwo",
                            "description" => esc_html__("Please select icon.", "nt-landium"),
                            'dependency'      => array(
                                'element' => 'icon_type',
                                'value' => 'iconlist'
                            )
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Title", "nt-landium"),
                            "param_name" => "item_title",
                            "description" => esc_html__("Add title for item.", "nt-landium"),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Detail", "nt-landium"),
                            "param_name" => "item_desc",
                            "description" => esc_html__("Add detail for item.", "nt-landium"),
                        )
                    )
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Item font icon', 'nt-landium' ) => '3',
                                esc_html__('Item title', 'nt-landium' ) => '4',
                                esc_html__('Item description', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                )
            )
        )
    );
} class NT_Landium_section_howitworks extends WPBakeryShortCode {}


/*-----------------------------------------------------------------------------------*/
/*	GALLERY landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_gallery_integrateWithVC' );
function NT_Landium_gallery_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Gallery Section", "nt-landium" ),
            "base" => "nt_landium_section_gallery",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),

                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Gallery item', 'nt-landium' ),
                    'param_name' => 'galleryloop',
                    'group' => esc_html__('Gallery', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('BG image position', 'nt-landium' ),
                            'param_name' => 'bgimg_pos',
                            'description' => esc_html__('You can select gallery bg image position', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select bg image position', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            "type" => "attach_image",
                            "heading" => esc_html__("Background image", "nt-landium"),
                            "param_name" => "gallerybg_img",
                            "description" => esc_html__("Add your background image", "nt-landium"),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Image animation', 'nt-landium'),
                            'param_name' => 'imganimation',
                            'description' => esc_html__('Add animation for image', 'nt-landium'),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Title", "nt-landium"),
                            "param_name" => "item_title",
                            "description" => esc_html__("Add title for item.", "nt-landium"),
                        ),
                        array(
                            "type" => "textarea",
                            "heading" => esc_html__("Detail", "nt-landium"),
                            "param_name" => "item_desc",
                            "description" => esc_html__("Add detail for item.", "nt-landium"),
                        )
                    )
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Item title', 'nt-landium' ) => '1',
                                esc_html__('Item description', 'nt-landium' ) => '2',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                )
            )
        )
    );
} class NT_Landium_section_gallery extends WPBakeryShortCode {}


/*-----------------------------------------------------------------------------------*/
/*	VIDEO  landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_video_integrateWithVC' );
function NT_Landium_video_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "Video Section", "nt-landium" ),
            "base" => "nt_landium_section_video",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add section ID for scrolling", "nt-landium"),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("BG image", "nt-landium"),
                    "param_name" => "video_bgimg",
                    "description" => esc_html__("Add background image for video section", "nt-landium"),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Video(Youtube) URL', 'nt-landium' ),
                    'param_name' => 'youtubeurl',
                    'description' => esc_html__("Add youtube video URL example: https://www.youtube.com/embed/1zG1iq9LZ2U", "nt-landium"),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for this section", "nt-landium"),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for this section", "nt-landium"),
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium'),
                    'param_name' => 'sectionbgcss',
                    'group' => esc_html__('Background options', 'nt-landium'),
                )
            )
        )
    );
} class NT_Landium_section_video extends WPBakeryShortCode {}


/*-----------------------------------------------------------------------------------*/
/*	PRICING landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_section_pricing_integrateWithVC' );
function NT_Landium_section_pricing_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__("Pricing ( Plugin )", "nt-landium"),
            "base" => "nt_landium_section_pricing",
            "icon" => "icon-wpb-row",
            "category" => esc_html__("NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium'),
                    'param_name' => 'section_id',
                    'description' => esc_html__('Add your Section ID', 'nt-landium'),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Heading display ( hide or show )', 'nt-landium' ),
                    'param_name' => 'heading_display',
                    'description' => esc_html__('You can select hide or show for section heading and description', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Price pack animation', 'nt-landium'),
                    'param_name' => 'priceanimation',
                    'description' => esc_html__('Add animation for price item', 'nt-landium'),
                    'group' 	    => esc_html__('Post Options', 'nt-landium' ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Pack Style', 'nt-landium' ),
                    'param_name' => 'pack_style',
                    'description' => esc_html__('You can select pricing pack color style', 'nt-landium' ),
                    'group' => esc_html__('Post Options', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Style 1 ( Different Color )', 'nt-landium' ) => '1',
                        esc_html__('Style 2 ( Simple color )', 'nt-landium' ) => '2',
                    ),
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Price Table Count', 'nt-landium' ),
                    'param_name' => 'post_number',
                    'group' => esc_html__('Post Options', 'nt-landium'),
                    'description' => esc_html__('You can control with number your price tables.Please enter a number', 'nt-landium'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Category', 'nt-landium' ),
                    'param_name' => 'price_category',
                    'group' => esc_html__('Post Options', 'nt-landium'),
                    'description' => esc_html__('Enter Price table category or write all', 'nt-landium'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Order', 'nt-landium' ),
                    'param_name' => 'order',
                    'group' => esc_html__('Post Options', 'nt-landium'),
                    'description' => esc_html__('Enter Price table order. DESC or ASC', 'nt-landium'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Orderby', 'nt-landium' ),
                    'param_name' => 'orderby',
                    'group' => esc_html__('Post Options', 'nt-landium'),
                    'description' => esc_html__('Enter Price table orderby. Default is : date', 'nt-landium'),
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium'),
                    'param_name' => 'sectionbgcss',
                    'group' => esc_html__('Background options', 'nt-landium'),
                ),
            ),
        )
    );
} class NT_Landium_section_pricing extends WPBakeryShortCode {}


/*-----------------------------------------------------------------------------------*/
/*	PRICING ITEM landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_section_pricingitem_integrateWithVC' );
function NT_Landium_section_pricingitem_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__("PRICING ITEM( Plugin )", "nt-landium"),
            "base" => "nt_landium_section_pricingitem",
            "icon" => "icon-wpb-row",
            "category" => esc_html__("NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Post slug name', 'nt-landium' ),
                    'param_name' => 'post_name',
                    'description' => esc_html__('Enter your pricing post slug name', 'nt-landium'),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Pack Style', 'nt-landium' ),
                    'param_name' => 'pack_style',
                    'description' => esc_html__('You can select pricing pack color style', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Style 1 ( Different Color )', 'nt-landium' ) => '1',
                        esc_html__('Style 2 ( Simple color )', 'nt-landium' ) => '2',
                    ),
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__('Price Button URL', 'nt-landium'),
                    'param_name' => 'pricelink',
                    'description' => esc_html__('Add link for price button.', 'nt-landium'),
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium'),
                    'param_name' => 'sectionbgcss',
                    'group' => esc_html__('Background options', 'nt-landium'),
                ),
            ),
        )
    );
}
class NT_Landium_section_pricingitem extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	TEAM Landium
/*-----------------------------------------------------------------------------------*/

add_action( 'vc_before_init', 'NT_Landium_section_team_integrateWithVC' );
function NT_Landium_section_team_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__("TEAM ( Plugin )", "nt-landium"),
            "base" => "nt_landium_section_team",
            "icon" => "icon-wpb-row",
            "category" => esc_html__("NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium'),
                    'param_name' => 'section_id',
                    'description' => esc_html__('Add your section ID for scrolling', 'nt-landium'),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Heading display ( hide or show )', 'nt-landium' ),
                    'param_name' => 'heading_display',
                    'description' => esc_html__('You can select hide or show for section heading and description', 'nt-landium' ),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'value' => array(
                        esc_html__('Show', 'nt-landium' ) => 'show',
                        esc_html__('Hide', 'nt-landium' ) => 'hide',
                    ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Section description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for pricing section", "nt-landium"),
                    'group' => esc_html__('Heading', 'nt-landium' ),
                    'dependency' => array(
                        'element' => 'heading_display',
                        'value' => 'show'
                    )
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Team item animation', 'nt-landium'),
                    'param_name' => 'teamanimation',
                    'description' => esc_html__('Add animation for team item', 'nt-landium'),
                    'group' => esc_html__('Post Options', 'nt-landium'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Team post count', 'nt-landium' ),
                    'param_name' => 'post_number',
                    'group' => esc_html__('Post Options', 'nt-landium'),
                    'description' => esc_html__('You can control with number your team members post.Please enter a number', 'nt-landium'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Category', 'nt-landium' ),
                    'param_name' => 'team_category',
                    'group' => esc_html__('Post Options', 'nt-landium'),
                    'description' => esc_html__('Enter Team category or write all', 'nt-landium'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('order', 'nt-landium' ),
                    'param_name' => 'order',
                    'group' => esc_html__('Post Options', 'nt-landium'),
                    'description' => esc_html__('Enter Team order. DESC or ASC', 'nt-landium'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('orderby', 'nt-landium' ),
                    'param_name' => 'orderby',
                    'group' => esc_html__('Post Options', 'nt-landium'),
                    'description' => esc_html__('Enter Team orderby. Default is : date', 'nt-landium'),
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Team name', 'nt-landium' ) => '3',
                                esc_html__('Team job', 'nt-landium' ) => '4',
                                esc_html__('Team social', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                )
            )
        )
    );
}
class NT_Landium_section_team extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	TEAM ITEM Landium
/*-----------------------------------------------------------------------------------*/

add_action( 'vc_before_init', 'NT_Landium_section_teamitem_integrateWithVC' );
function NT_Landium_section_teamitem_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__("TEAM ITEM ( Plugin )", "nt-landium"),
            "base" => "nt_landium_section_teamitem",
            "icon" => "icon-wpb-row",
            "category" => esc_html__("NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Team slug name', 'nt-landium' ),
                    'param_name' => 'post_name',
                    'description' => esc_html__('Enter your team slug name', 'nt-landium'),
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Team name', 'nt-landium' ) => '3',
                                esc_html__('Team job', 'nt-landium' ) => '4',
                                esc_html__('Team social', 'nt-landium' ) => '5',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Background CSS', 'nt-landium' ),
                    'param_name' => 'sectionbgcss',
                    'group' 	    => esc_html__('Background options', 'nt-landium' ),
                )
            )
        )
    );
}
class NT_Landium_section_teamitem extends WPBakeryShortCode {}

/*-----------------------------------------------------------------------------------*/
/*	APP STORE landium
/*-----------------------------------------------------------------------------------*/
add_action( 'vc_before_init', 'NT_Landium_appstore_integrateWithVC' );
function NT_Landium_appstore_integrateWithVC() {
    vc_map(
        array(
            "name" => esc_html__( "App store Section", "nt-landium" ),
            "base" => "nt_landium_section_appstore",
            "category" => esc_html__( "NT Landium", "nt-landium"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Section ID', 'nt-landium' ),
                    'param_name' => 'section_id',
                    'description' => esc_html__("Add Your Section ID for scroll", "nt-landium"),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("BG parallax image", "nt-landium"),
                    "param_name" => "appbgimg",
                    "description" => esc_html__("Add background parallax image", "nt-landium"),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Left image", "nt-landium"),
                    "param_name" => "leftimg",
                    "description" => esc_html__("Add left image", "nt-landium"),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Left image animation', 'nt-landium'),
                    'param_name' => 'btn2animation',
                    'description' => esc_html__('Add animation for left image', 'nt-landium'),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Heading', 'nt-landium' ),
                    'param_name' => 'section_heading',
                    'description' => esc_html__("Add heading for this section", "nt-landium"),
                    'group' => esc_html__('Right Section', 'nt-landium' ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Description', 'nt-landium' ),
                    'param_name' => 'section_desc',
                    'description' => esc_html__("Add description for this section", "nt-landium"),
                    'group' => esc_html__('Right Section', 'nt-landium' ),
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__('Description 2', 'nt-landium' ),
                    'param_name' => 'section_desc2',
                    'description' => esc_html__("Add description second for this section", "nt-landium"),
                    'group' => esc_html__('Right Section', 'nt-landium' ),
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__('Button 1(Link)', 'nt-landium' ),
                    'param_name' => 'herobtnlink1',
                    'description' => esc_html__('Add custom link.', 'nt-landium' ),
                    'group' => esc_html__('Button', 'nt-landium' ),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Appstore image", "nt-landium"),
                    "param_name" => "appstoreimg",
                    "description" => esc_html__("Add your custom button image", "nt-landium"),
                    'group' => esc_html__('Button', 'nt-landium' ),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Button 1 animation', 'nt-landium'),
                    'param_name' => 'btn1animation',
                    'description' => esc_html__('Add animation for button 1', 'nt-landium'),
                    'group' => esc_html__('Button', 'nt-landium'),
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__('Button 2(Link)', 'nt-landium' ),
                    'param_name' => 'herobtnlink2',
                    'description' => esc_html__('Add custom link.', 'nt-landium' ),
                    'group' => esc_html__('Button', 'nt-landium' ),
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__("Playstore image", "nt-landium"),
                    "param_name" => "playstoreimg",
                    "description" => esc_html__("Add your custom button image", "nt-landium"),
                    'group' => esc_html__('Button', 'nt-landium' ),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__('Button 2 animation', 'nt-landium'),
                    'param_name' => 'btn2animation',
                    'description' => esc_html__('Add animation for button 2', 'nt-landium'),
                    'group' => esc_html__('Button', 'nt-landium'),
                ),
                // custom style
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Select item and change style', 'nt-landium' ),
                    'param_name' => 'customstyle',
                    'group' => esc_html__('Custom Style', 'nt-landium' ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Current', 'nt-landium' ),
                            'param_name' => 'currentitem',
                            'admin_label' => true,
                            'description' => esc_html__('You can select element for custom style', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select item for custom style', 'nt-landium' ) => '',
                                esc_html__('Section heading', 'nt-landium' ) => '1',
                                esc_html__('Section description', 'nt-landium' ) => '2',
                                esc_html__('Section description 2', 'nt-landium' ) => '3',
                            ),
                        ),
                        array(
                            'type' => 'animation_style',
                            'heading' => esc_html__('Current item animation', 'nt-landium'),
                            'param_name' => 'animation',
                            'description' => esc_html__('Add animation for current item', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Font-size', 'nt-landium'),
                            'param_name' => 'size',
                            'description' => esc_html__('Change fontsize.use number in ( px or unit )', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Line-height', 'nt-landium'),
                            'param_name' => 'lineh',
                            'description' => esc_html__('Change line-height.use number in ( px or unit ).example line-height: 1.1 or 24px or 1.4rem', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font-weight', 'nt-landium' ),
                            'param_name' => 'weight',
                            'description' => esc_html__('Change font-weight.', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select font-weight', 'nt-landium' ) => '',
                                esc_html__('100', 'nt-landium' ) => '100',
                                esc_html__('200', 'nt-landium' ) => '200',
                                esc_html__('300', 'nt-landium' ) => '300',
                                esc_html__('400', 'nt-landium' ) => '400',
                                esc_html__('500', 'nt-landium' ) => '500',
                                esc_html__('600', 'nt-landium' ) => '600',
                                esc_html__('700', 'nt-landium' ) => '700',
                                esc_html__('800', 'nt-landium' ) => '900',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Color', 'nt-landium'),
                            'param_name' => 'color',
                            'description' => esc_html__('Change color.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Text align( position )', 'nt-landium' ),
                            'param_name' => 'position',
                            'description' => esc_html__('You can select position for current item', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select text align', 'nt-landium' ) => '',
                                esc_html__('Left', 'nt-landium' ) => 'left',
                                esc_html__('Center', 'nt-landium' ) => 'center',
                                esc_html__('Right', 'nt-landium' ) => 'right',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Font style', 'nt-landium' ),
                            'param_name' => 'fstyle',
                            'value' => array(
                                esc_html__('Select font style', 'nt-landium' ) => '',
                                esc_html__('normal', 'nt-landium' ) => 'normal',
                                esc_html__('italic', 'nt-landium' ) => 'italic',
                                esc_html__('oblique', 'nt-landium' ) => 'oblique',
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Background color', 'nt-landium'),
                            'param_name' => 'bgcolor',
                            'description' => esc_html__('Change background.', 'nt-landium'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding top', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padtop',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding right', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padright',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding bottom', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Padding left', 'nt-landium'),
                            'description' => esc_html__('Use number in px.', 'nt-landium'),
                            'param_name' => 'padleft',
                            'edit_field_class' => 'vc_col-sm-3',
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Border', 'nt-landium' ),
                            'param_name' => 'borderstyl',
                            'description' => esc_html__('Select border style and enter border width in ( px or unit ).example:5px', 'nt-landium' ),
                            'value' => array(
                                esc_html__('Select border style', 'nt-landium' ) => '',
                                esc_html__('solid', 'nt-landium' ) => 'solid',
                                esc_html__('dotted', 'nt-landium' ) => 'dotted',
                                esc_html__('dashed', 'nt-landium' ) => 'dashed',
                                esc_html__('double', 'nt-landium' ) => 'double',
                                esc_html__('groove', 'nt-landium' ) => 'groove',
                                esc_html__('inset', 'nt-landium' ) => 'inset',
                                esc_html__('outset', 'nt-landium' ) => 'outset',
                                esc_html__('ridge', 'nt-landium' ) => 'ridge',
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border top', 'nt-landium'),
                            'description' => esc_html__('example:5px', 'nt-landium' ),
                            'param_name' => 'brdtop',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border right', 'nt-landium'),
                            'description' => esc_html__('example:10px', 'nt-landium' ),
                            'param_name' => 'brdright',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border bottom', 'nt-landium'),
                            'description' => esc_html__('example:3px', 'nt-landium' ),
                            'param_name' => 'brdbottom',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border left', 'nt-landium'),
                            'description' => esc_html__('example:1px', 'nt-landium' ),
                            'param_name' => 'brdleft',
                            'edit_field_class' => 'vc_col-sm-3',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'heading' => esc_html__('Border color', 'nt-landium'),
                            'param_name' => 'bordercolor',
                            'description' => esc_html__('Change border color.', 'nt-landium'),
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Border radius', 'nt-landium'),
                            'description' => esc_html__('Example:30px or 30%', 'nt-landium' ),
                            'param_name' => 'borderradius',
                            'edit_field_class' => 'vc_col-sm-6',
                            'dependency' => array(
                                'element' => 'borderstyl',
                                'value' => array('solid','dotted','dashed','double','groove','inset','outset','ridge')
                            )
                        ),
                    )
                ),
            )
        )
    );
} class NT_Landium_section_appstore extends WPBakeryShortCode {}

// Filter to replace default css class names for vc_row shortcode and vc_column
add_filter( 'vc_shortcodes_css_class', 'nt_landium_custom_css_classes_for_vc_row_and_vc_column', 10, 2 );
function nt_landium_custom_css_classes_for_vc_row_and_vc_column( $class_string, $tag ) {
    if (  $tag == 'vc_row_inner' ) {
        $class_string = str_replace( 'vc_row-fluid', 'container bootstrap', $class_string ); // This will replace "vc_row-fluid" with "my_row-fluid"
    }
    return $class_string; // Important: you should always return modified or original $class_string
}
